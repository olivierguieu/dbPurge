package io.patchjar.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import io.patchjar.compiler.CompileOptions;
import io.patchjar.compiler.Problem;
import io.patchjar.decompiler.DecompileResult;
import io.patchjar.decompiler.DecompilerKind;

class PatchSessionTest {

    private static final ClassRef GREETER = new ClassRef("", "demo/Greeter");

    private static final String GREETER_SOURCE = """
            package demo;

            import java.util.function.Supplier;

            public class Greeter {
                private final String name;

                public Greeter(String name) {
                    this.name = name;
                }

                public String greet() {
                    Supplier<String> message = () -> "Hello, " + name;
                    return message.get();
                }

                static class Counter {
                    int count;

                    void increment() {
                        count++;
                    }
                }

                public static void main(String[] args) {
                    Counter counter = new Counter();
                    counter.increment();
                    Runnable report = new Runnable() {
                        @Override
                        public void run() {
                            System.out.println("count=" + counter.count);
                        }
                    };
                    report.run();
                    System.out.println(new Greeter(args.length > 0 ? args[0] : "world").greet());
                }
            }
            """;

    private static final String UTIL_SOURCE = """
            package demo;

            public final class Util {
                private Util() {
                }

                public static String shout(String text) {
                    return text.toUpperCase() + "!";
                }
            }
            """;

    @TempDir
    Path tmp;

    private Path greeterJar(int release) throws IOException {
        Map<String, byte[]> classes = TestJars.compile(tmp, release,
                Map.of("demo/Greeter", GREETER_SOURCE, "demo/Util", UTIL_SOURCE), List.of());
        return TestJars.jar(tmp.resolve("greeter.jar"), "demo.Greeter", "", classes);
    }

    @Test
    void indexesTopLevelClassesAndTheirNestedClasses() throws IOException {
        try (PatchSession session = PatchSession.open(greeterJar(8), List.of())) {
            JarModel model = session.model();
            assertEquals(List.of(""), model.roots());
            assertEquals(List.of("demo/Greeter", "demo/Util"),
                    model.topLevelClasses("").stream().map(ClassInfo::name).toList());
            assertEquals(List.of("demo/Greeter", "demo/Greeter$1", "demo/Greeter$Counter"), model.family(GREETER));
            assertEquals(8, session.release(GREETER, null).release());
            assertNull(session.release(GREETER, null).note());
        }
    }

    @ParameterizedTest
    @EnumSource(DecompilerKind.class)
    void decompiledSourceCanBeEditedRecompiledAndSaved(DecompilerKind decompiler) throws Exception {
        try (PatchSession session = PatchSession.open(greeterJar(8), List.of())) {
            DecompileResult decompiled = session.decompile(GREETER, decompiler);
            String source = decompiled.source();
            assertTrue(source.contains("class Greeter"), source);
            assertTrue(source.contains("\"Hello, \""), source);

            String edited = source.replace("\"Hello, \"", "Util.shout(\"Patched\") + \" \"");
            CompileOutcome outcome = session.compileAndPatch(GREETER, edited, CompileOptions.defaults());
            assertTrue(outcome.success(), () -> "compilation failed: " + outcome.problems() + "\n" + edited);
            assertEquals(8, outcome.release().release());
            assertTrue(outcome.summary().replaced().contains("demo/Greeter"));
            assertTrue(session.model().isPatched(GREETER));
            assertFalse(session.model().isPatched(new ClassRef("", "demo/Util")));
            assertEquals(52, Bytecode.majorVersion(session.model().classBytes("", "demo/Greeter")));
            assertEquals(edited, session.editedSource(GREETER));
            assertTrue(session.hasUnsavedChanges());

            Path patched = tmp.resolve("greeter-patched.jar");
            SaveReport report = session.save(patched);
            assertNull(report.backup());
            assertFalse(session.hasUnsavedChanges());

            String output = TestJars.run(patched, "demo.Greeter", "Olivier");
            assertTrue(output.contains("PATCHED! Olivier"), output);
            assertTrue(output.contains("count=1"), output);
        }
    }

    @Test
    void compileErrorsAreReportedWithTheirLineAndNothingIsPatched() throws IOException {
        try (PatchSession session = PatchSession.open(greeterJar(8), List.of())) {
            String broken = GREETER_SOURCE.replace("return message.get();", "return message.get() + undefinedVariable;");
            CompileOutcome outcome = session.compileAndPatch(GREETER, broken, CompileOptions.defaults());
            assertFalse(outcome.success());
            Problem error = outcome.problems().stream().filter(Problem::isError).findFirst().orElseThrow();
            assertEquals(14, error.line());
            assertTrue(error.message().contains("undefinedVariable"), error.message());
            assertTrue(error.startOffset() > 0 && error.endOffset() > error.startOffset());
            assertFalse(session.model().hasChanges());
            assertFalse(session.hasUnsavedChanges());
        }
    }

    @Test
    void sourceMustDeclareTheEditedClass() throws IOException {
        try (PatchSession session = PatchSession.open(greeterJar(8), List.of())) {
            String renamed = GREETER_SOURCE.replace("package demo;", "package other;")
                    .replace("public class Greeter", "class Greeter");
            CompileOutcome outcome = session.compileAndPatch(GREETER, renamed, CompileOptions.defaults());
            assertFalse(outcome.success());
            assertTrue(outcome.problems().get(0).message().contains("must declare class demo.Greeter"));
            assertFalse(session.model().hasChanges());
        }
    }

    @Test
    void nestedClassesThatNoLongerExistAreRemovedAndRevertRestoresThem() throws Exception {
        Path jar = greeterJar(11);
        try (PatchSession session = PatchSession.open(jar, List.of())) {
            String simplified = """
                    package demo;

                    public class Greeter {
                        public static void main(String[] args) {
                            System.out.println("simplified " + Util.shout("ok"));
                        }
                    }
                    """;
            CompileOutcome outcome = session.compileAndPatch(GREETER, simplified, CompileOptions.defaults());
            assertTrue(outcome.success(), () -> outcome.problems().toString());
            assertEquals(11, outcome.release().release());
            assertEquals(List.of("demo/Greeter$1", "demo/Greeter$Counter"), outcome.summary().removed());
            assertEquals(List.of("demo/Greeter"), session.model().family(GREETER));
            assertTrue(session.bytecode(GREETER, true).contains("demo/Greeter$Counter"));
            assertFalse(session.bytecode(GREETER, false).contains("demo/Greeter$Counter"));

            Path patched = tmp.resolve("simplified.jar");
            session.save(patched);
            try (ZipFile zip = new ZipFile(patched.toFile())) {
                assertNull(zip.getEntry("demo/Greeter$1.class"));
                assertNull(zip.getEntry("demo/Greeter$Counter.class"));
            }
            assertTrue(TestJars.run(patched, "demo.Greeter").contains("simplified OK!"));

            session.revert(GREETER);
            assertFalse(session.model().hasChanges());
            assertNull(session.editedSource(GREETER));
            assertEquals(List.of("demo/Greeter", "demo/Greeter$1", "demo/Greeter$Counter"), session.model().family(GREETER));
        }
    }

    @Test
    void patchedClassesAreVisibleWhenCompilingOtherClasses() throws IOException {
        try (PatchSession session = PatchSession.open(greeterJar(17), List.of())) {
            String utilWithNewMethod = UTIL_SOURCE.replace("private Util()", """
                    public static String whisper(String text) {
                            return text.toLowerCase();
                        }

                        private Util()""");
            ClassRef util = new ClassRef("", "demo/Util");
            assertTrue(session.compileAndPatch(util, utilWithNewMethod, CompileOptions.defaults()).success());

            String greeterUsingIt = GREETER_SOURCE.replace("\"Hello, \"", "Util.whisper(\"HI \")");
            CompileOutcome outcome = session.compileAndPatch(GREETER, greeterUsingIt, CompileOptions.defaults());
            assertTrue(outcome.success(), () -> outcome.problems().toString());
            assertEquals(List.of(GREETER, util), session.model().patchedClasses());
        }
    }

    @Test
    void signaturesAreStrippedWhenASignedJarIsPatched() throws Exception {
        Map<String, byte[]> classes = TestJars.compile(tmp, 8, Map.of("demo/Greeter", GREETER_SOURCE, "demo/Util", UTIL_SOURCE), List.of());
        Manifest manifest = TestJars.manifest("demo.Greeter");
        Attributes digest = new Attributes();
        digest.putValue("SHA-256-Digest", "bm90IGEgcmVhbCBkaWdlc3Q=");
        manifest.getEntries().put("demo/Greeter.class", digest);

        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put(JarModel.MANIFEST, TestJars.bytes(manifest));
        entries.put("META-INF/SIGNER.SF", "Signature-Version: 1.0\n".getBytes(StandardCharsets.UTF_8));
        entries.put("META-INF/SIGNER.RSA", new byte[] {1, 2, 3});
        classes.forEach((name, bytes) -> entries.put(name + ".class", bytes));
        Path jar = TestJars.zip(tmp.resolve("signed.jar"), entries, Set.of());

        try (PatchSession session = PatchSession.open(jar, List.of())) {
            assertTrue(session.model().isSigned());
            assertTrue(session.compileAndPatch(GREETER, GREETER_SOURCE.replace("Hello", "Bye"), CompileOptions.defaults()).success());
            SaveReport report = session.save(tmp.resolve("unsigned.jar"));
            assertEquals(List.of("META-INF/SIGNER.SF", "META-INF/SIGNER.RSA"), report.strippedSignatureFiles());
        }
        try (ZipFile zip = new ZipFile(tmp.resolve("unsigned.jar").toFile())) {
            assertNull(zip.getEntry("META-INF/SIGNER.SF"));
            assertNull(zip.getEntry("META-INF/SIGNER.RSA"));
            Manifest saved = new Manifest(zip.getInputStream(zip.getEntry(JarModel.MANIFEST)));
            assertEquals("demo.Greeter", saved.getMainAttributes().getValue(Attributes.Name.MAIN_CLASS));
            assertTrue(saved.getEntries().isEmpty());
        }
        assertTrue(TestJars.run(tmp.resolve("unsigned.jar"), "demo.Greeter").contains("Bye, world"));
    }

    @Test
    void overwritingTheOpenedJarKeepsABackup() throws IOException {
        Path jar = greeterJar(8);
        byte[] original = Files.readAllBytes(jar);
        try (PatchSession session = PatchSession.open(jar, List.of())) {
            assertTrue(session.compileAndPatch(GREETER, GREETER_SOURCE.replace("Hello", "Hi"), CompileOptions.defaults()).success());
            SaveReport report = session.save(jar);
            assertEquals(jar.resolveSibling("greeter.jar.bak"), report.backup());
            assertTrue(java.util.Arrays.equals(original, Files.readAllBytes(report.backup())));
        }
    }

    @ParameterizedTest
    @EnumSource(DecompilerKind.class)
    void springBootLayoutCompilesAgainstNestedLibraries(DecompilerKind decompiler) throws Exception {
        Map<String, byte[]> libClasses = TestJars.compile(tmp, 17, Map.of("lib/Helper", """
                package lib;

                public class Helper {
                    public static String help(String who) {
                        return "helping " + who;
                    }
                }
                """), List.of());
        Path libJar = TestJars.jar(tmp.resolve("helper.jar"), null, "", libClasses);
        Map<String, byte[]> appClasses = TestJars.compile(tmp, 17, Map.of("app/Main", """
                package app;

                import lib.Helper;

                public record Main(String who) {
                    public static void main(String[] args) {
                        System.out.println(Helper.help(new Main("Spring").who()));
                    }
                }
                """), List.of(libJar));

        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put(JarModel.MANIFEST, TestJars.bytes(TestJars.manifest(null)));
        entries.put("BOOT-INF/classes/app/Main.class", appClasses.get("app/Main"));
        entries.put("BOOT-INF/lib/helper.jar", Files.readAllBytes(libJar));
        Path fatJar = TestJars.zip(tmp.resolve("app.jar"), entries, Set.of("BOOT-INF/lib/helper.jar"));

        ClassRef main = new ClassRef("BOOT-INF/classes/", "app/Main");
        try (PatchSession session = PatchSession.open(fatJar, List.of())) {
            assertEquals(List.of("BOOT-INF/classes/"), session.model().roots());
            assertEquals(17, session.release(main, null).release());
            String source = session.decompile(main, decompiler).source();
            assertTrue(source.contains("Helper.help"), source);

            String edited = source.replace("\"Spring\"", "\"Boot\"");
            CompileOutcome outcome = session.compileAndPatch(main, edited, CompileOptions.defaults());
            assertTrue(outcome.success(), () -> outcome.problems() + "\n" + edited);
            session.save(tmp.resolve("app-patched.jar"));
        }
        try (ZipFile zip = new ZipFile(tmp.resolve("app-patched.jar").toFile())) {
            ZipEntry nested = zip.getEntry("BOOT-INF/lib/helper.jar");
            assertNotNull(nested);
            assertEquals(ZipEntry.STORED, nested.getMethod());
            byte[] patched = zip.getInputStream(zip.getEntry("BOOT-INF/classes/app/Main.class")).readAllBytes();
            assertEquals(61, Bytecode.majorVersion(patched));
            ClassInfo info = ClassInfo.read(patched);
            assertEquals(ClassInfo.Kind.RECORD, info.kind());
            assertTrue(new String(patched, StandardCharsets.ISO_8859_1).contains("Boot"));
        }
    }

    @Test
    void manifestClassPathIsResolvedNextToTheJar() throws IOException {
        Files.createDirectories(tmp.resolve("lib"));
        Path dependency = TestJars.jar(tmp.resolve("lib/dep.jar"), null, "", Map.of());
        Manifest manifest = TestJars.manifest(null);
        manifest.getMainAttributes().put(Attributes.Name.CLASS_PATH, "lib/dep.jar lib/missing.jar");
        Path jar = TestJars.zip(tmp.resolve("with-cp.jar"),
                Map.of(JarModel.MANIFEST, TestJars.bytes(manifest)), Set.of());
        try (PatchSession session = PatchSession.open(jar, List.of())) {
            assertEquals(List.of(dependency.toAbsolutePath()), session.manifestLibraries());
        }
    }
}
