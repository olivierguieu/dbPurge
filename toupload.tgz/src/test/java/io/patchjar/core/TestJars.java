package io.patchjar.core;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.tools.ToolProvider;

/** Builds small JARs for tests. */
final class TestJars {

    private TestJars() {
    }

    /** Compiles sources (keyed by internal class name) and returns the class files by internal name. */
    static Map<String, byte[]> compile(Path work, int release, Map<String, String> sources, List<Path> classpath)
            throws IOException {
        Path src = Files.createTempDirectory(work, "src");
        Path out = Files.createTempDirectory(work, "out");
        List<String> args = new ArrayList<>(List.of("--release", Integer.toString(release), "-d", out.toString()));
        if (!classpath.isEmpty()) {
            args.add("-cp");
            args.add(classpath.stream().map(Path::toString).collect(Collectors.joining(File.pathSeparator)));
        }
        for (Map.Entry<String, String> source : sources.entrySet()) {
            Path file = src.resolve(source.getKey() + ".java");
            Files.createDirectories(file.getParent());
            Files.writeString(file, source.getValue());
            args.add(file.toString());
        }
        ByteArrayOutputStream errors = new ByteArrayOutputStream();
        int status = ToolProvider.getSystemJavaCompiler().run(null, null, errors, args.toArray(String[]::new));
        assertEquals(0, status, errors.toString(StandardCharsets.UTF_8));

        Map<String, byte[]> classes = new TreeMap<>();
        try (Stream<Path> files = Files.walk(out)) {
            for (Path file : files.filter(p -> p.toString().endsWith(".class")).toList()) {
                String name = out.relativize(file).toString().replace(File.separatorChar, '/');
                classes.put(name.substring(0, name.length() - ".class".length()), Files.readAllBytes(file));
            }
        }
        return classes;
    }

    static Manifest manifest(String mainClass) {
        Manifest manifest = new Manifest();
        manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
        if (mainClass != null) {
            manifest.getMainAttributes().put(Attributes.Name.MAIN_CLASS, mainClass);
        }
        return manifest;
    }

    static byte[] bytes(Manifest manifest) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        manifest.write(out);
        return out.toByteArray();
    }

    /** Entries keyed by path, written in order; entries named in {@code stored} are not compressed. */
    static Path zip(Path file, Map<String, byte[]> entries, Set<String> stored) throws IOException {
        try (OutputStream fileOut = Files.newOutputStream(file); ZipOutputStream out = new ZipOutputStream(fileOut)) {
            for (Map.Entry<String, byte[]> entry : entries.entrySet()) {
                ZipEntry zipEntry = new ZipEntry(entry.getKey());
                if (stored.contains(entry.getKey())) {
                    CRC32 crc = new CRC32();
                    crc.update(entry.getValue());
                    zipEntry.setMethod(ZipEntry.STORED);
                    zipEntry.setSize(entry.getValue().length);
                    zipEntry.setCompressedSize(entry.getValue().length);
                    zipEntry.setCrc(crc.getValue());
                }
                out.putNextEntry(zipEntry);
                out.write(entry.getValue());
                out.closeEntry();
            }
        }
        return file;
    }

    /** A JAR with a manifest followed by the given classes at their package paths (under {@code prefix}). */
    static Path jar(Path file, String mainClass, String prefix, Map<String, byte[]> classes) throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        entries.put(JarModel.MANIFEST, bytes(manifest(mainClass)));
        classes.forEach((name, bytes) -> entries.put(prefix + name + ".class", bytes));
        return zip(file, entries, Set.of());
    }

    /** Runs {@code mainClass} from {@code classpath} with the current JVM and returns its standard output. */
    static String run(Path classpath, String mainClass, String... args) throws IOException, InterruptedException {
        List<String> command = new ArrayList<>(List.of(
                Path.of(System.getProperty("java.home"), "bin", "java").toString(), "-cp", classpath.toString(), mainClass));
        command.addAll(List.of(args));
        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        String output;
        try (InputStream in = process.getInputStream()) {
            output = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
        process.waitFor(30, TimeUnit.SECONDS);
        assertEquals(0, process.exitValue(), output);
        return output;
    }
}
