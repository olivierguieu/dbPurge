package io.patchjar;

import java.nio.file.Path;
import java.util.List;

import javafx.application.Application;
import javafx.stage.Stage;

import io.patchjar.ui.MainWindow;

/** JavaFX application. Pass a JAR path as first argument to open it on startup. */
public final class PatchJarApp extends Application {

    private MainWindow window;

    @Override
    public void start(Stage stage) {
        window = new MainWindow(stage);
        window.show();
        List<String> arguments = getParameters().getUnnamed();
        if (!arguments.isEmpty()) {
            window.openJar(Path.of(arguments.get(0)));
        }
    }

    @Override
    public void stop() {
        if (window != null) {
            window.dispose();
        }
    }

    public static void main(String[] args) {
        launch(PatchJarApp.class, args);
    }
}
