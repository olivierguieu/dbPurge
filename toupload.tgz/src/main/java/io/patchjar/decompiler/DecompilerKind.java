package io.patchjar.decompiler;

public enum DecompilerKind {
    CFR("CFR"),
    VINEFLOWER("Vineflower");

    private final String label;

    DecompilerKind(String label) {
        this.label = label;
    }

    public Decompiler create() {
        return switch (this) {
            case CFR -> new CfrDecompiler();
            case VINEFLOWER -> new VineflowerDecompiler();
        };
    }

    @Override
    public String toString() {
        return label;
    }
}
