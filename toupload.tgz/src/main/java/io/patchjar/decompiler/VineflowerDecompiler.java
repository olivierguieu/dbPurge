package io.patchjar.decompiler;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.jar.Manifest;

import org.jetbrains.java.decompiler.main.decompiler.BaseDecompiler;
import org.jetbrains.java.decompiler.main.extern.IContextSource;
import org.jetbrains.java.decompiler.main.extern.IFernflowerLogger;
import org.jetbrains.java.decompiler.main.extern.IFernflowerPreferences;
import org.jetbrains.java.decompiler.main.extern.IResultSaver;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.commons.ClassRemapper;
import org.objectweb.asm.commons.Remapper;

import io.patchjar.core.ClassInfo;
import io.patchjar.core.ClassLookup;

/** Adapter for the Vineflower decompiler (maintained Fernflower fork), reading every class from memory. */
final class VineflowerDecompiler implements Decompiler {

    @Override
    public DecompileResult decompile(String className, List<String> family, ClassLookup classpath) {
        Map<String, String> output = Collections.synchronizedMap(new LinkedHashMap<>());
        List<String> messages = Collections.synchronizedList(new ArrayList<>());

        Map<String, Object> options = new HashMap<>();
        options.put(IFernflowerPreferences.INDENT_STRING, "    ");
        options.put(IFernflowerPreferences.THREADS, "1");
        options.put(IFernflowerPreferences.INCLUDE_JAVA_RUNTIME, "0"); // JDK classes come from the classpath lookup
        options.put(IFernflowerPreferences.MAX_PROCESSING_METHOD, "30"); // seconds, guards against pathological methods

        List<String> unit = new ArrayList<>(family);
        unit.addAll(dollarNamedDependencies(family, classpath));

        BaseDecompiler decompiler = new BaseDecompiler(NoOpSaver.INSTANCE, options, new Logger(messages));
        decompiler.addSource(new OwnSource(unit, classpath, output));
        decompiler.addLibrary(new LibrarySource(classpath));
        decompiler.decompileContext();

        String source = output.getOrDefault(className, output.values().stream().findFirst().orElse(""));
        if (source.isEmpty()) {
            messages.add("Vineflower produced no output for " + className);
        }
        return new DecompileResult(source, messages);
    }

    /**
     * Vineflower names every class outside the decompiled unit by turning each {@code $} into {@code .}, which is
     * wrong for classes such as Gson's {@code $Gson$Types} ({@code import ..Gson.Types}). The classes referenced
     * by {@code family} whose source name cannot be derived that way are returned so they can join the unit.
     */
    private static List<String> dollarNamedDependencies(List<String> family, ClassLookup classpath) {
        Set<String> referenced = new TreeSet<>();
        for (String member : family) {
            byte[] bytes = classpath.find(member);
            if (bytes != null) {
                referenced.addAll(referencedTypes(bytes));
            }
        }
        Set<String> dependencies = new LinkedHashSet<>();
        for (String name : referenced) {
            if (name.indexOf('$') < 0 || family.contains(name)) {
                continue;
            }
            List<String> chain = new ArrayList<>(); // name, its outer class, ... up to the top-level class
            for (String current = name; current != null && chain.size() < 32 && !chain.contains(current); ) {
                byte[] bytes = classpath.find(current);
                if (bytes == null) {
                    break;
                }
                chain.add(current);
                current = parentOf(bytes);
            }
            if (!chain.isEmpty() && !hasNaiveSourceName(chain)) {
                dependencies.addAll(chain);
            }
        }
        family.forEach(dependencies::remove);
        return List.copyOf(dependencies);
    }

    /** Whether replacing {@code $} by {@code .} in each name of the outer-class chain yields its source name. */
    private static boolean hasNaiveSourceName(List<String> chain) {
        String topLevel = chain.get(chain.size() - 1);
        if (topLevel.indexOf('$', topLevel.lastIndexOf('/') + 1) >= 0) {
            return false;
        }
        for (int i = 0; i < chain.size() - 1; i++) {
            String nested = chain.get(i);
            String outer = chain.get(i + 1);
            if (!nested.startsWith(outer + "$") || nested.indexOf('$', outer.length() + 1) >= 0) {
                return false;
            }
        }
        return true;
    }

    private static String parentOf(byte[] classFile) {
        try {
            return ClassInfo.read(classFile).parent();
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static Set<String> referencedTypes(byte[] classFile) {
        Set<String> types = new HashSet<>();
        Remapper collector = new Remapper(Opcodes.ASM9) {
            @Override
            public String map(String internalName) {
                types.add(internalName);
                return internalName;
            }
        };
        ClassVisitor visitAllMethods = new ClassVisitor(Opcodes.ASM9) {
            @Override
            public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
                return new MethodVisitor(Opcodes.ASM9) { }; // makes ClassRemapper visit instructions too
            }
        };
        try {
            new ClassReader(classFile).accept(new ClassRemapper(visitAllMethods, collector), 0);
        } catch (RuntimeException ignored) {
            // unreadable class: nothing to add
        }
        return types;
    }

    /** The classes being decompiled: the top-level class and its nested classes. */
    private record OwnSource(List<String> family, ClassLookup classpath, Map<String, String> output)
            implements IContextSource {

        @Override
        public String getName() {
            return "patchjar";
        }

        @Override
        public Entries getEntries() {
            return new Entries(family.stream().map(Entry::atBase).toList(), List.of(), List.of());
        }

        @Override
        public boolean hasClass(String className) {
            return family.contains(className);
        }

        @Override
        public byte[] getClassBytes(String className) {
            return family.contains(className) ? classpath.find(className) : null;
        }

        @Override
        public InputStream getInputStream(String resource) {
            if (resource.endsWith(CLASS_SUFFIX)) {
                byte[] bytes = getClassBytes(resource.substring(0, resource.length() - CLASS_SUFFIX.length()));
                return bytes == null ? null : new ByteArrayInputStream(bytes);
            }
            return null;
        }

        @Override
        public IOutputSink createOutputSink(IResultSaver saver) {
            return new IOutputSink() {
                @Override
                public void begin() {
                }

                @Override
                public void acceptClass(String qualifiedName, String fileName, String content, int[] mapping) {
                    output.put(qualifiedName, content);
                }

                @Override
                public void acceptDirectory(String directory) {
                }

                @Override
                public void acceptOther(String path) {
                }

                @Override
                public void close() {
                }
            };
        }
    }

    /** Every other class (JAR, libraries, JDK), loaded lazily on demand. */
    private static final class LibrarySource implements IContextSource {
        private final ClassLookup classpath;
        private final Map<String, Optional<byte[]>> cache = new HashMap<>();

        LibrarySource(ClassLookup classpath) {
            this.classpath = classpath;
        }

        @Override
        public String getName() {
            return "patchjar-classpath";
        }

        @Override
        public Entries getEntries() {
            return Entries.EMPTY;
        }

        @Override
        public boolean isLazy() {
            return true;
        }

        @Override
        public boolean hasClass(String className) {
            return getClassBytes(className) != null;
        }

        @Override
        public synchronized byte[] getClassBytes(String className) {
            return cache.computeIfAbsent(className, name -> Optional.ofNullable(classpath.find(name))).orElse(null);
        }

        @Override
        public InputStream getInputStream(String resource) {
            return null;
        }
    }

    private static final class Logger extends IFernflowerLogger {
        private final List<String> messages;

        Logger(List<String> messages) {
            this.messages = messages;
        }

        @Override
        public void writeMessage(String message, Severity severity) {
            if (severity.ordinal() >= Severity.WARN.ordinal()) {
                messages.add("Vineflower: " + message);
            }
        }

        @Override
        public void writeMessage(String message, Severity severity, Throwable t) {
            if (severity.ordinal() >= Severity.WARN.ordinal()) {
                messages.add("Vineflower: " + message + (t == null ? "" : " (" + t + ")"));
            }
        }
    }

    private enum NoOpSaver implements IResultSaver {
        INSTANCE;

        @Override
        public void saveFolder(String path) {
        }

        @Override
        public void copyFile(String source, String path, String entryName) {
        }

        @Override
        public void saveClassFile(String path, String qualifiedName, String entryName, String content, int[] mapping) {
        }

        @Override
        public void createArchive(String path, String archiveName, Manifest manifest) {
        }

        @Override
        public void saveDirEntry(String path, String archiveName, String entryName) {
        }

        @Override
        public void copyEntry(String source, String path, String archiveName, String entry) {
        }

        @Override
        public void saveClassEntry(String path, String archiveName, String qualifiedName, String entryName, String content) {
        }

        @Override
        public void closeArchive(String path, String archiveName) {
        }
    }
}
