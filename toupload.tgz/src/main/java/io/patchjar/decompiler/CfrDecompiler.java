package io.patchjar.decompiler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.benf.cfr.reader.api.CfrDriver;
import org.benf.cfr.reader.api.ClassFileSource;
import org.benf.cfr.reader.api.OutputSinkFactory;
import org.benf.cfr.reader.bytecode.analysis.parse.utils.Pair;

import io.patchjar.core.ClassLookup;

/** Adapter for the CFR decompiler, reading every class from memory. */
final class CfrDecompiler implements Decompiler {

    private static final Map<String, String> OPTIONS = Map.of(
            "showversion", "false",
            "hideutf", "false");

    @Override
    public DecompileResult decompile(String className, List<String> family, ClassLookup classpath) {
        StringBuilder java = new StringBuilder();
        List<String> messages = new ArrayList<>();

        OutputSinkFactory sinks = new OutputSinkFactory() {
            @Override
            public List<SinkClass> getSupportedSinks(SinkType sinkType, Collection<SinkClass> available) {
                return available.contains(SinkClass.STRING) ? List.of(SinkClass.STRING) : List.of();
            }

            @Override
            public <T> Sink<T> getSink(SinkType sinkType, SinkClass sinkClass) {
                return switch (sinkType) {
                    case JAVA -> java::append;
                    case EXCEPTION -> value -> messages.add("CFR: " + value);
                    default -> value -> { };
                };
            }
        };

        ClassFileSource source = new ClassFileSource() {
            @Override
            public void informAnalysisRelativePathDetail(String usePath, String classFilePath) {
            }

            @Override
            public Collection<String> addJar(String jarPath) {
                return List.of();
            }

            @Override
            public String getPossiblyRenamedPath(String path) {
                return path;
            }

            @Override
            public Pair<byte[], String> getClassFileContent(String path) throws IOException {
                String name = path.endsWith(".class") ? path.substring(0, path.length() - ".class".length()) : path;
                byte[] bytes = classpath.find(name);
                if (bytes == null) {
                    throw new IOException("Class not found: " + name);
                }
                return Pair.make(bytes, path);
            }
        };

        CfrDriver driver = new CfrDriver.Builder()
                .withOverrideClassFileSource(source)
                .withOutputSink(sinks)
                .withOptions(OPTIONS)
                .build();
        driver.analyse(List.of(className + ".class"));
        return new DecompileResult(java.toString(), messages);
    }
}
