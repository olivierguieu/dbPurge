package io.patchjar.decompiler;

import java.util.List;

/**
 * @param source   the Java source, with {@code \n} line separators
 * @param messages warnings reported by the decompiler
 */
public record DecompileResult(String source, List<String> messages) {

    public DecompileResult {
        source = source.replace("\r\n", "\n");
        messages = List.copyOf(messages);
    }
}
