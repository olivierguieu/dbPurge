package io.patchjar.decompiler;

import java.util.List;

import io.patchjar.core.ClassLookup;

public interface Decompiler {

    /**
     * Decompiles a top-level class into a single compilation unit.
     *
     * @param className internal name of the top-level class
     * @param family    the class followed by its nested, local and anonymous classes
     * @param classpath resolves the class, its family and every referenced type
     */
    DecompileResult decompile(String className, List<String> family, ClassLookup classpath);
}
