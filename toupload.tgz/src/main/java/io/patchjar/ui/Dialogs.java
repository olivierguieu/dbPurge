package io.patchjar.ui;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Window;

/** Modal dialogs. */
final class Dialogs {

    private Dialogs() {
    }

    static boolean confirm(Window owner, String title, String message, String confirmLabel) {
        ButtonType confirm = new ButtonType(confirmLabel, ButtonBar.ButtonData.OK_DONE);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, message, confirm, ButtonType.CANCEL);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(title);
        return alert.showAndWait().filter(confirm::equals).isPresent();
    }

    static void error(Window owner, String title, Throwable error) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.setContentText(String.valueOf(error.getMessage() != null ? error.getMessage() : error));
        StringWriter trace = new StringWriter();
        error.printStackTrace(new PrintWriter(trace));
        TextArea details = new TextArea(trace.toString());
        details.setEditable(false);
        details.setPrefRowCount(14);
        alert.getDialogPane().setExpandableContent(details);
        alert.showAndWait();
    }

    static void info(Window owner, String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.showAndWait();
    }

    /** Edits the user libraries used to decompile and compile. Returns the new list, or empty if cancelled. */
    static Optional<List<Path>> libraries(Window owner, List<Path> current, int automatic, Settings settings) {
        Dialog<List<Path>> dialog = new Dialog<>();
        dialog.initOwner(owner);
        dialog.setTitle("Classpath Libraries");
        dialog.setHeaderText("Libraries the JAR depends on");

        Label help = new Label("Classes are decompiled and compiled against these JARs or class folders. "
                + "JARs nested in the opened archive (Spring Boot, WAR) and its manifest Class-Path are added automatically"
                + (automatic == 0 ? "." : " (" + automatic + " for the current JAR)."));
        help.setWrapText(true);

        ListView<Path> list = new ListView<>(FXCollections.observableArrayList(current));
        list.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        list.setPlaceholder(new Label("No libraries"));
        list.setPrefSize(640, 280);

        Button addJars = new Button("Add JARs…");
        addJars.setOnAction(e -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Add Library JARs");
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Java archives", "*.jar", "*.zip"));
            if (settings.lastDirectory() != null) {
                chooser.setInitialDirectory(settings.lastDirectory().toFile());
            }
            List<File> files = chooser.showOpenMultipleDialog(dialog.getOwner());
            if (files != null) {
                files.stream().map(File::toPath).filter(p -> !list.getItems().contains(p)).forEach(list.getItems()::add);
            }
        });
        Button addFolder = new Button("Add Folder…");
        addFolder.setOnAction(e -> {
            DirectoryChooser chooser = new DirectoryChooser();
            chooser.setTitle("Add a folder of JARs or classes");
            File folder = chooser.showDialog(dialog.getOwner());
            if (folder != null) {
                jarsIn(folder.toPath()).stream().filter(p -> !list.getItems().contains(p)).forEach(list.getItems()::add);
            }
        });
        Button remove = new Button("Remove");
        remove.disableProperty().bind(list.getSelectionModel().selectedItemProperty().isNull());
        remove.setOnAction(e -> list.getItems().removeAll(List.copyOf(list.getSelectionModel().getSelectedItems())));
        Button clear = new Button("Remove All");
        clear.setOnAction(e -> list.getItems().clear());

        Label folderHint = new Label("Add Folder adds every JAR it contains, or the folder itself if it holds class files.");
        folderHint.getStyleClass().add("hint");
        HBox buttons = new HBox(8, addJars, addFolder, remove, clear);
        VBox content = new VBox(10, help, list, buttons, folderHint);
        VBox.setVgrow(list, Priority.ALWAYS);
        content.setPadding(new Insets(4, 0, 0, 0));
        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.setResizable(true);
        dialog.setResultConverter(button -> button == ButtonType.OK ? List.copyOf(list.getItems()) : null);
        return dialog.showAndWait();
    }

    /** Edits the javac options. Returns true if the settings were changed. */
    static boolean compilerOptions(Window owner, Settings settings) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(owner);
        dialog.setTitle("Compiler Options");
        dialog.setHeaderText("How edited classes are compiled");

        CheckBox useRelease = new CheckBox("Compile with --release (recommended)");
        useRelease.setSelected(settings.useRelease.get());
        Label releaseHelp = new Label("Checks the code against the API of the target Java version. Turn it off to use "
                + "-source/-target against the running JDK, e.g. for code calling JDK internals.");
        releaseHelp.setWrapText(true);
        releaseHelp.getStyleClass().add("hint");

        TextField extra = new TextField(settings.extraOptions.get());
        extra.setPromptText("e.g. -parameters   --add-exports java.base/sun.nio.ch=ALL-UNNAMED");
        Label extraHelp = new Label("Additional javac options, separated by spaces. Always used: -g -proc:none");
        extraHelp.getStyleClass().add("hint");

        VBox content = new VBox(8, useRelease, releaseHelp, new Label("Extra javac options:"), extra, extraHelp);
        content.setPrefWidth(560);
        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        if (dialog.showAndWait().filter(ButtonType.OK::equals).isEmpty()) {
            return false;
        }
        settings.useRelease.set(useRelease.isSelected());
        settings.extraOptions.set(extra.getText().trim());
        return true;
    }

    /** The JARs in {@code folder} (up to 3 levels deep), or the folder itself if it has none. */
    private static List<Path> jarsIn(Path folder) {
        List<Path> jars = new ArrayList<>();
        try (Stream<Path> files = Files.walk(folder, 3)) {
            files.filter(p -> p.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(".jar"))
                    .filter(Files::isRegularFile)
                    .sorted()
                    .forEach(jars::add);
        } catch (IOException ignored) {
            // fall back to the folder itself
        }
        return jars.isEmpty() ? List.of(folder) : jars;
    }
}
