package io.patchjar.ui;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import javafx.beans.binding.Bindings;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;

import io.patchjar.compiler.Problem;
import io.patchjar.core.ClassRef;

/** Compiler problems of all classes; activating a row navigates to it. */
final class ProblemsPane extends BorderPane {

    record Row(ClassRef ref, Problem problem) {
    }

    private static final Comparator<Row> ORDER = Comparator
            .comparing((Row row) -> row.problem().severity())
            .thenComparing(row -> row.ref().qualifiedName())
            .thenComparingLong(row -> row.problem().line());

    private final ObservableList<Row> rows = FXCollections.observableArrayList();
    private final TableView<Row> table = new TableView<>(rows);
    private final IntegerBinding count = Bindings.size(rows);
    private Consumer<Row> onNavigate = row -> { };

    ProblemsPane() {
        TableColumn<Row, Problem.Severity> severity = new TableColumn<>("");
        severity.setCellValueFactory(cell -> new ReadOnlyObjectWrapper<>(cell.getValue().problem().severity()));
        severity.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(Problem.Severity item, boolean empty) {
                super.updateItem(item, empty);
                getStyleClass().removeAll("severity-error", "severity-warning", "severity-note");
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(switch (item) {
                        case ERROR -> "Error";
                        case WARNING -> "Warning";
                        case NOTE -> "Note";
                    });
                    getStyleClass().add("severity-" + item.name().toLowerCase(java.util.Locale.ROOT));
                }
            }
        });
        severity.setPrefWidth(72);

        TableColumn<Row, String> message = new TableColumn<>("Description");
        message.setCellValueFactory(cell -> new ReadOnlyStringWrapper(oneLine(cell.getValue().problem().message())));
        message.setPrefWidth(640);

        TableColumn<Row, String> location = new TableColumn<>("Location");
        location.setCellValueFactory(cell -> {
            Row row = cell.getValue();
            long line = row.problem().line();
            return new ReadOnlyStringWrapper(row.ref().simpleName() + ".java" + (line > 0 ? ":" + line : ""));
        });
        location.setPrefWidth(200);

        table.getColumns().add(severity);
        table.getColumns().add(location);
        table.getColumns().add(message);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.setPlaceholder(new Label("No problems"));
        table.setRowFactory(view -> {
            TableRow<Row> row = new TableRow<>() {
                @Override
                protected void updateItem(Row item, boolean empty) {
                    super.updateItem(item, empty);
                    setTooltip(empty || item == null ? null : new Tooltip(item.problem().message()));
                }
            };
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && row.getItem() != null) {
                    onNavigate.accept(row.getItem());
                }
            });
            return row;
        });
        table.setOnKeyPressed(event -> {
            Row selected = table.getSelectionModel().getSelectedItem();
            if (event.getCode() == KeyCode.ENTER && selected != null) {
                onNavigate.accept(selected);
            }
        });
        setCenter(table);
    }

    void setOnNavigate(Consumer<Row> onNavigate) {
        this.onNavigate = onNavigate;
    }

    /** Replaces the problems of {@code ref}. */
    void setProblems(ClassRef ref, List<Problem> problems) {
        rows.removeIf(row -> row.ref().equals(ref));
        problems.forEach(problem -> rows.add(new Row(ref, problem)));
        FXCollections.sort(rows, ORDER);
    }

    void clear(ClassRef ref) {
        rows.removeIf(row -> row.ref().equals(ref));
    }

    void clearAll() {
        rows.clear();
    }

    IntegerBinding count() {
        return count;
    }

    private static String oneLine(String message) {
        return message.lines().map(String::strip).filter(line -> !line.isEmpty()).collect(Collectors.joining("  —  "));
    }
}
