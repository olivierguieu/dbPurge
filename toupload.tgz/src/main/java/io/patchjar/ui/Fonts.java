package io.patchjar.ui;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import javafx.scene.text.Font;

/** Picks an installed monospaced font for code (JavaFX CSS has no font fallback lists). */
final class Fonts {

    private static final List<String> MONOSPACED = List.of(
            "JetBrains Mono", "Menlo", "SF Mono", "Cascadia Mono", "Consolas", "DejaVu Sans Mono", "Liberation Mono",
            "Ubuntu Mono", "Monospaced");

    private Fonts() {
    }

    /** A stylesheet applying the monospaced font to code and log views. */
    static String stylesheet() {
        List<String> installed = Font.getFamilies();
        String family = MONOSPACED.stream().filter(installed::contains).findFirst().orElse("Monospaced");
        String css = ".code-area, .code-area .text, .code-area .lineno, .log-area { -fx-font-family: \"" + family + "\"; }";
        return "data:text/css;base64," + Base64.getEncoder().encodeToString(css.getBytes(StandardCharsets.UTF_8));
    }
}
