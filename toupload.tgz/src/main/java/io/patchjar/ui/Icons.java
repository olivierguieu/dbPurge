package io.patchjar.ui;

import java.util.Locale;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.shape.SVGPath;

import io.patchjar.core.ClassInfo;

/** Small vector icons, colored by CSS. */
final class Icons {

    private Icons() {
    }

    static Node forClass(ClassInfo.Kind kind) {
        Label icon = new Label(switch (kind) {
            case INTERFACE -> "I";
            case ENUM -> "E";
            case ANNOTATION -> "@";
            case RECORD -> "R";
            case ABSTRACT_CLASS -> "A";
            case CLASS -> "C";
        });
        icon.setAlignment(Pos.CENTER);
        icon.getStyleClass().addAll("class-icon", "class-icon-" + kind.name().toLowerCase(Locale.ROOT).replace('_', '-'));
        return icon;
    }

    static Node forPackage() {
        return shape("M1 3.5 L6 3.5 L7.5 5 L15 5 L15 13.5 L1 13.5 Z", "package-icon");
    }

    static Node forClassRoot() {
        return shape("M2 2 L14 2 L14 14 L2 14 Z M7 2 L7 5 L9 5 L9 2 Z M7 6 L9 6 L9 8 L7 8 Z", "root-icon");
    }

    private static Node shape(String path, String styleClass) {
        SVGPath shape = new SVGPath();
        shape.setContent(path);
        shape.getStyleClass().add(styleClass);
        return shape;
    }
}
