package io.patchjar.ui;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.stream.Collectors;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;

import org.fxmisc.flowless.VirtualizedScrollPane;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;
import org.fxmisc.wellbehaved.event.EventPattern;
import org.fxmisc.wellbehaved.event.InputMap;
import org.fxmisc.wellbehaved.event.Nodes;

import io.patchjar.compiler.Problem;

/** A code area with syntax highlighting, line numbers, problem markers and a find bar. */
final class CodeEditor extends BorderPane {

    private static final String INDENT = "    ";

    private final CodeArea area = new CodeArea();
    private final Function<String, StyleSpans<Collection<String>>> highlighter;
    private final IntFunction<Node> lineNumbers = LineNumberFactory.get(area);
    private final FindBar findBar = new FindBar(area);
    private List<Problem> problems = List.of();
    private boolean replacingText;

    CodeEditor(Function<String, StyleSpans<Collection<String>>> highlighter, boolean editable) {
        this.highlighter = highlighter;
        getStyleClass().add("code-editor");
        area.setEditable(editable);
        refreshGutter();

        area.multiPlainChanges()
                .successionEnds(Duration.ofMillis(120))
                .subscribe(changes -> highlight());
        area.plainTextChanges().subscribe(change -> {
            if (!replacingText && !problems.isEmpty()) {
                problems = List.of(); // positions no longer match the text
                refreshGutter();
            }
        });
        if (editable) {
            installEditingKeys();
        }
        setTop(findBar);
        setCenter(new VirtualizedScrollPane<>(area));
    }

    CodeArea area() {
        return area;
    }

    String getText() {
        return area.getText();
    }

    /** Replaces the whole text, clearing undo history and problem markers. */
    void setText(String text) {
        replacingText = true;
        try {
            area.replaceText(text);
            problems = List.of();
        } finally {
            replacingText = false;
        }
        area.getUndoManager().forgetHistory();
        area.moveTo(0);
        area.requestFollowCaret();
        highlight();
        refreshGutter();
    }

    /** Shows problems whose offsets refer to the current text. */
    void setProblems(List<Problem> problems) {
        this.problems = problems.stream().filter(p -> p.line() > 0 && p.severity() != Problem.Severity.NOTE).toList();
        highlight();
        refreshGutter();
    }

    void goTo(long line, long column) {
        int paragraph = (int) Math.max(0, Math.min(line - 1, area.getParagraphs().size() - 1));
        int offset = (int) Math.max(0, Math.min(column - 1, area.getParagraphLength(paragraph)));
        area.moveTo(paragraph, offset);
        area.requestFocus();
        Platform.runLater(() -> area.showParagraphAtCenter(paragraph));
    }

    int currentLine() {
        return area.getCurrentParagraph() + 1;
    }

    int lineCount() {
        return area.getParagraphs().size();
    }

    void showFind() {
        String selection = area.getSelectedText();
        findBar.open(selection.isEmpty() || selection.contains("\n") ? null : selection);
    }

    void findNext() {
        findBar.find(FindBar.Direction.NEXT);
    }

    void findPrevious() {
        findBar.find(FindBar.Direction.PREVIOUS);
    }

    private void highlight() {
        String text = area.getText();
        if (text.isEmpty()) {
            return;
        }
        StyleSpans<Collection<String>> spans = highlighter.apply(text);
        if (!problems.isEmpty()) {
            spans = spans.overlay(problemSpans(text.length()), CodeEditor::union);
        }
        area.setStyleSpans(0, spans);
    }

    private StyleSpans<Collection<String>> problemSpans(int length) {
        record Range(int start, int end, String styleClass) {
        }
        List<Range> ranges = new ArrayList<>();
        for (Problem problem : problems) {
            int start = (int) problem.startOffset();
            int end = (int) problem.endOffset();
            if (start < 0 || start > length) { // no position: mark the whole line
                int paragraph = (int) problem.line() - 1;
                if (paragraph >= area.getParagraphs().size()) {
                    continue;
                }
                start = area.getAbsolutePosition(paragraph, 0);
                end = start + area.getParagraphLength(paragraph);
            }
            end = Math.min(length, Math.max(end, start + 1)); // zero-width positions underline one character
            if (end > start) {
                ranges.add(new Range(start, end, problem.isError() ? "problem-error" : "problem-warning"));
            }
        }
        ranges.sort(Comparator.comparingInt(Range::start));

        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        int position = 0;
        for (Range range : ranges) {
            int start = Math.max(range.start(), position);
            if (start >= range.end()) {
                continue;
            }
            spans.add(List.of(), start - position);
            spans.add(List.of(range.styleClass()), range.end() - start);
            position = range.end();
        }
        spans.add(List.of(), length - position);
        return spans.create();
    }

    private static Collection<String> union(Collection<String> a, Collection<String> b) {
        if (b.isEmpty()) {
            return a;
        }
        if (a.isEmpty()) {
            return b;
        }
        List<String> merged = new ArrayList<>(a);
        merged.addAll(b);
        return merged;
    }

    private void refreshGutter() {
        Map<Integer, List<Problem>> problemsByParagraph = problems.stream()
                .collect(Collectors.groupingBy(p -> (int) p.line() - 1));
        area.setParagraphGraphicFactory(paragraph -> {
            Region marker = new Region();
            marker.getStyleClass().add("gutter-marker");
            List<Problem> here = problemsByParagraph.get(paragraph);
            if (here != null) {
                marker.getStyleClass().add(here.stream().anyMatch(Problem::isError) ? "gutter-error" : "gutter-warning");
                Tooltip.install(marker, new Tooltip(here.stream().map(Problem::message).collect(Collectors.joining("\n\n"))));
            }
            HBox gutter = new HBox(marker, lineNumbers.apply(paragraph));
            gutter.setAlignment(Pos.CENTER_LEFT);
            gutter.getStyleClass().add("gutter");
            return gutter;
        });
    }

    private void installEditingKeys() {
        Nodes.addInputMap(area, InputMap.sequence(
                InputMap.consume(EventPattern.keyPressed(KeyCode.ENTER), e -> newLine()),
                InputMap.consume(EventPattern.keyPressed(KeyCode.TAB), e -> area.replaceSelection(INDENT)),
                InputMap.consume(EventPattern.keyPressed(KeyCode.TAB, KeyCombination.SHIFT_DOWN), e -> outdent())));
    }

    /** Keeps the indentation of the current line, one level deeper after an opening brace. */
    private void newLine() {
        String line = area.getParagraph(area.getCurrentParagraph()).getText();
        int column = area.getCaretColumn();
        String indent = line.substring(0, line.length() - line.stripLeading().length());
        if (indent.length() > column) {
            indent = indent.substring(0, column);
        }
        if (line.substring(0, column).stripTrailing().endsWith("{")) {
            indent += INDENT;
        }
        area.replaceSelection("\n" + indent);
        area.requestFollowCaret();
    }

    private void outdent() {
        int paragraph = area.getCurrentParagraph();
        String line = area.getParagraph(paragraph).getText();
        int spaces = 0;
        while (spaces < INDENT.length() && spaces < line.length() && line.charAt(spaces) == ' ') {
            spaces++;
        }
        if (spaces > 0) {
            int start = area.getAbsolutePosition(paragraph, 0);
            area.deleteText(start, start + spaces);
        }
    }
}
