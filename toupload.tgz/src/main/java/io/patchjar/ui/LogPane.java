package io.patchjar.ui;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;

/** Timestamped activity log. */
final class LogPane extends BorderPane {

    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final int MAX_LENGTH = 1_000_000;

    private final TextArea text = new TextArea();

    LogPane() {
        text.setEditable(false);
        text.setWrapText(true);
        text.getStyleClass().add("log-area");
        setCenter(text);
    }

    void info(String message) {
        append("", message);
    }

    void warn(String message) {
        append("WARNING  ", message);
    }

    void error(String message) {
        append("ERROR  ", message);
    }

    private void append(String level, String message) {
        text.appendText(LocalTime.now().format(TIME) + "  " + level + message + "\n");
        if (text.getLength() > MAX_LENGTH) {
            text.deleteText(0, text.getLength() - MAX_LENGTH * 4 / 5);
        }
    }
}
