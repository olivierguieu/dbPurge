package io.patchjar.ui;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Consumer;

import javafx.animation.PauseTransition;
import javafx.geometry.Pos;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Tooltip;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.util.Duration;

import io.patchjar.core.ClassInfo;
import io.patchjar.core.ClassRef;
import io.patchjar.core.JarModel;

/** Tree of the top-level classes of a JAR, grouped by class root and package, with a filter. */
final class ClassTreePane extends BorderPane {

    /** Small JARs open with every package expanded. */
    private static final int AUTO_EXPAND_PACKAGES = 12;

    sealed interface Item permits RootItem, PackageItem, ClassItem {
    }

    record RootItem(String prefix) implements Item {
    }

    record PackageItem(String root, String name) implements Item {
    }

    record ClassItem(ClassRef ref, ClassInfo info) implements Item {
    }

    private final TextField filter = new TextField();
    private final ToggleButton patchedOnly = new ToggleButton("Patched");
    private final TreeView<Item> tree = new TreeView<>();
    private final PauseTransition filterDelay = new PauseTransition(Duration.millis(180));
    private final Set<String> expandedPackages = new HashSet<>();
    private Set<ClassRef> patched = Set.of();
    private JarModel model;
    private Consumer<ClassRef> onOpen = ref -> { };
    private Consumer<ClassRef> onRevert = ref -> { };

    ClassTreePane() {
        getStyleClass().add("class-tree");
        filter.setPromptText("Filter classes");
        filter.textProperty().addListener((obs, old, text) -> filterDelay.playFromStart());
        filterDelay.setOnFinished(e -> rebuild());
        filter.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                filter.clear();
            } else if (event.getCode() == KeyCode.DOWN || event.getCode() == KeyCode.ENTER) {
                filterDelay.stop();
                rebuild();
                selectFirstClass(event.getCode() == KeyCode.ENTER);
            }
        });
        patchedOnly.setTooltip(new Tooltip("Show only the classes you patched"));
        patchedOnly.selectedProperty().addListener((obs, old, selected) -> rebuild());
        HBox.setHgrow(filter, Priority.ALWAYS);
        HBox filterBar = new HBox(6, filter, patchedOnly);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.getStyleClass().add("filter-bar");

        tree.setShowRoot(false);
        tree.setCellFactory(view -> new ItemCell());
        tree.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                openSelected();
            }
        });
        setTop(filterBar);
        setCenter(tree);
    }

    void setOnOpen(Consumer<ClassRef> onOpen) {
        this.onOpen = onOpen;
    }

    void setOnRevert(Consumer<ClassRef> onRevert) {
        this.onRevert = onRevert;
    }

    void setModel(JarModel model) {
        this.model = model;
        expandedPackages.clear();
        if (model != null) {
            List<String> packages = new ArrayList<>();
            for (String root : model.roots()) {
                model.topLevelClasses(root).stream()
                        .map(info -> root + "|" + new ClassRef(root, info.name()).packageName())
                        .distinct()
                        .forEach(packages::add);
            }
            if (packages.size() <= AUTO_EXPAND_PACKAGES) {
                expandedPackages.addAll(packages);
            }
        }
        filter.clear();
        patchedOnly.setSelected(false);
        rebuild();
    }

    /** Re-reads the model, e.g. after a patch added, removed or modified classes. */
    void refresh() {
        rebuild();
    }

    void focusFilter() {
        filter.requestFocus();
        filter.selectAll();
    }

    private void rebuild() {
        TreeItem<Item> hiddenRoot = new TreeItem<>();
        ClassRef selected = selectedClass();
        TreeItem<Item> toSelect = null;
        if (model != null) {
            patched = new HashSet<>(model.patchedClasses());
            String query = filter.getText().trim().toLowerCase(Locale.ROOT);
            boolean filtering = !query.isEmpty() || patchedOnly.isSelected();
            List<String> roots = model.roots();
            boolean showRoots = roots.size() > 1 || (roots.size() == 1 && !roots.get(0).isEmpty());
            for (String prefix : roots) {
                Map<String, List<ClassInfo>> byPackage = new TreeMap<>();
                for (ClassInfo info : model.topLevelClasses(prefix)) {
                    ClassRef ref = new ClassRef(prefix, info.name());
                    if ((query.isEmpty() || ref.qualifiedName().toLowerCase(Locale.ROOT).contains(query))
                            && (!patchedOnly.isSelected() || patched.contains(ref))) {
                        byPackage.computeIfAbsent(ref.packageName(), k -> new ArrayList<>()).add(info);
                    }
                }
                if (byPackage.isEmpty()) {
                    continue;
                }
                TreeItem<Item> parent = hiddenRoot;
                if (showRoots) {
                    parent = new TreeItem<>(new RootItem(prefix));
                    parent.setExpanded(true);
                    hiddenRoot.getChildren().add(parent);
                }
                for (Map.Entry<String, List<ClassInfo>> pkg : byPackage.entrySet()) {
                    String key = prefix + "|" + pkg.getKey();
                    TreeItem<Item> packageItem = new TreeItem<>(new PackageItem(prefix, pkg.getKey()));
                    packageItem.setExpanded(filtering || expandedPackages.contains(key));
                    packageItem.expandedProperty().addListener((obs, old, expanded) -> {
                        if (filter.getText().isBlank() && !patchedOnly.isSelected()) {
                            if (expanded) {
                                expandedPackages.add(key);
                            } else {
                                expandedPackages.remove(key);
                            }
                        }
                    });
                    for (ClassInfo info : pkg.getValue()) {
                        ClassRef ref = new ClassRef(prefix, info.name());
                        TreeItem<Item> classItem = new TreeItem<>(new ClassItem(ref, info));
                        packageItem.getChildren().add(classItem);
                        if (ref.equals(selected)) {
                            toSelect = classItem;
                        }
                    }
                    parent.getChildren().add(packageItem);
                }
            }
        }
        tree.setRoot(hiddenRoot);
        if (toSelect != null) {
            toSelect.getParent().setExpanded(true);
            tree.getSelectionModel().select(toSelect);
        }
    }

    private ClassRef selectedClass() {
        TreeItem<Item> item = tree.getSelectionModel().getSelectedItem();
        return item != null && item.getValue() instanceof ClassItem c ? c.ref() : null;
    }

    private void selectFirstClass(boolean open) {
        TreeItem<Item> first = firstClass(tree.getRoot());
        if (first != null) {
            tree.getSelectionModel().select(first);
            tree.scrollTo(tree.getSelectionModel().getSelectedIndex());
            tree.requestFocus();
            if (open) {
                openSelected();
            }
        }
    }

    private static TreeItem<Item> firstClass(TreeItem<Item> item) {
        if (item == null) {
            return null;
        }
        if (item.getValue() instanceof ClassItem) {
            return item;
        }
        for (TreeItem<Item> child : item.getChildren()) {
            TreeItem<Item> found = firstClass(child);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    private void openSelected() {
        ClassRef ref = selectedClass();
        if (ref != null) {
            onOpen.accept(ref);
        }
    }

    private final class ItemCell extends TreeCell<Item> {

        ItemCell() {
            setOnMouseClicked(event -> {
                if (event.getButton() == MouseButton.PRIMARY && event.getClickCount() == 2
                        && getItem() instanceof ClassItem item) {
                    onOpen.accept(item.ref());
                }
            });
        }

        @Override
        protected void updateItem(Item item, boolean empty) {
            super.updateItem(item, empty);
            getStyleClass().remove("patched");
            setContextMenu(null);
            if (empty || item == null) {
                setText(null);
                setGraphic(null);
                return;
            }
            switch (item) {
                case RootItem root -> {
                    setText(root.prefix().isEmpty() ? "(JAR root)" : root.prefix());
                    setGraphic(Icons.forClassRoot());
                }
                case PackageItem pkg -> {
                    setText(pkg.name().isEmpty() ? "(default package)" : pkg.name());
                    setGraphic(Icons.forPackage());
                }
                case ClassItem cls -> {
                    boolean isPatched = patched.contains(cls.ref());
                    setText(cls.ref().simpleName());
                    setGraphic(Icons.forClass(cls.info().kind()));
                    if (isPatched) {
                        getStyleClass().add("patched");
                    }
                    setContextMenu(classMenu(cls.ref(), isPatched));
                }
            }
        }

        private ContextMenu classMenu(ClassRef ref, boolean isPatched) {
            MenuItem open = new MenuItem("Open");
            open.setOnAction(e -> onOpen.accept(ref));
            MenuItem revert = new MenuItem("Revert to Original…");
            revert.setDisable(!isPatched);
            revert.setOnAction(e -> onRevert.accept(ref));
            MenuItem copy = new MenuItem("Copy Qualified Name");
            copy.setOnAction(e -> {
                ClipboardContent content = new ClipboardContent();
                content.putString(ref.qualifiedName());
                Clipboard.getSystemClipboard().setContent(content);
            });
            return new ContextMenu(open, revert, new SeparatorMenuItem(), copy);
        }
    }
}
