package io.patchjar.ui;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.prefs.BackingStoreException;
import java.util.prefs.Preferences;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import io.patchjar.compiler.CompileOptions;
import io.patchjar.decompiler.DecompilerKind;

/** User preferences, persisted with {@link Preferences}. */
final class Settings {

    private static final String DECOMPILER = "decompiler";
    private static final String TARGET_RELEASE = "targetRelease";
    private static final String USE_RELEASE = "useRelease";
    private static final String EXTRA_OPTIONS = "extraJavacOptions";
    private static final String DARK_THEME = "darkTheme";
    private static final String LAST_DIRECTORY = "lastDirectory";
    private static final String LIBRARY_COUNT = "libraryCount";
    private static final String LIBRARY = "library.";

    final ObjectProperty<DecompilerKind> decompiler = new SimpleObjectProperty<>();
    /** Null means: the version of the original class file. */
    final ObjectProperty<Integer> targetRelease = new SimpleObjectProperty<>();
    final BooleanProperty useRelease = new SimpleBooleanProperty();
    final StringProperty extraOptions = new SimpleStringProperty();
    final BooleanProperty darkTheme = new SimpleBooleanProperty();
    final ObservableList<Path> libraries = FXCollections.observableArrayList();

    private final Preferences preferences;

    Settings() {
        this(Preferences.userNodeForPackage(Settings.class));
    }

    Settings(Preferences preferences) {
        this.preferences = preferences;
        decompiler.set(parseDecompiler(preferences.get(DECOMPILER, DecompilerKind.VINEFLOWER.name())));
        int release = preferences.getInt(TARGET_RELEASE, 0);
        targetRelease.set(release > 0 ? release : null);
        useRelease.set(preferences.getBoolean(USE_RELEASE, true));
        extraOptions.set(preferences.get(EXTRA_OPTIONS, ""));
        darkTheme.set(preferences.getBoolean(DARK_THEME, false));
        int libraryCount = preferences.getInt(LIBRARY_COUNT, 0);
        for (int i = 0; i < libraryCount; i++) {
            String library = preferences.get(LIBRARY + i, null);
            if (library != null) {
                libraries.add(Path.of(library));
            }
        }

        decompiler.addListener((obs, old, kind) -> preferences.put(DECOMPILER, kind.name()));
        targetRelease.addListener((obs, old, value) -> preferences.putInt(TARGET_RELEASE, value == null ? 0 : value));
        useRelease.addListener((obs, old, value) -> preferences.putBoolean(USE_RELEASE, value));
        extraOptions.addListener((obs, old, value) -> preferences.put(EXTRA_OPTIONS, value));
        darkTheme.addListener((obs, old, value) -> preferences.putBoolean(DARK_THEME, value));
        libraries.addListener((ListChangeListener<Path>) change -> saveLibraries());
    }

    CompileOptions compileOptions() {
        String extra = extraOptions.get().trim();
        List<String> options = extra.isEmpty() ? List.of() : Arrays.asList(extra.split("\\s+"));
        return new CompileOptions(targetRelease.get(), useRelease.get(), options);
    }

    Path lastDirectory() {
        String directory = preferences.get(LAST_DIRECTORY, null);
        Path path = directory == null ? null : Path.of(directory);
        return path != null && Files.isDirectory(path) ? path : null;
    }

    void setLastDirectory(Path directory) {
        if (directory != null) {
            preferences.put(LAST_DIRECTORY, directory.toAbsolutePath().toString());
        }
    }

    void flush() {
        try {
            preferences.flush();
        } catch (BackingStoreException ignored) {
            // preferences are a convenience only
        }
    }

    private void saveLibraries() {
        int previous = preferences.getInt(LIBRARY_COUNT, 0);
        List<Path> current = new ArrayList<>(libraries);
        for (int i = 0; i < current.size(); i++) {
            preferences.put(LIBRARY + i, current.get(i).toString());
        }
        for (int i = current.size(); i < previous; i++) {
            preferences.remove(LIBRARY + i);
        }
        preferences.putInt(LIBRARY_COUNT, current.size());
    }

    private static DecompilerKind parseDecompiler(String name) {
        try {
            return DecompilerKind.valueOf(name);
        } catch (IllegalArgumentException e) {
            return DecompilerKind.VINEFLOWER;
        }
    }
}
