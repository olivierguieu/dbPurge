package io.patchjar.ui;

import java.util.List;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import io.patchjar.compiler.Problem;
import io.patchjar.core.ClassInfo;
import io.patchjar.core.ClassRef;

/** Editor tab of one class: its (editable) Java source and a read-only bytecode listing. */
final class ClassEditorTab extends Tab {

    private final ClassRef ref;
    private final CodeEditor source = new CodeEditor(Highlighters::java, true);
    private final CodeEditor bytecode = new CodeEditor(Highlighters::bytecode, false);
    private final Label sourceInfo = new Label();
    private final Label patchedBadge = new Label("PATCHED");
    private final Label bytecodeInfo = new Label();
    private final ToggleButton showCurrent = new ToggleButton("Current");
    private final ToggleButton showOriginal = new ToggleButton("Original");
    private final VBox loadingOverlay;
    private final Label loadingLabel = new Label("Decompiling…");
    private final TabPane views = new TabPane();
    private final Tab sourceView = new Tab("Java Source");
    private final Tab bytecodeView = new Tab("Bytecode");
    private final BooleanProperty dirty = new SimpleBooleanProperty();
    private boolean loaded;
    private boolean decompilerOutput;
    private String origin = "";
    private String baseline = "";
    private String currentBytecode = "";
    private String originalBytecode = "";

    ClassEditorTab(ClassRef ref, ClassInfo.Kind kind) {
        this.ref = ref;
        setGraphic(Icons.forClass(kind));
        setTooltip(new Tooltip(ref.qualifiedName() + (ref.root().isEmpty() ? "" : "\nin " + ref.root())));
        updateTitle();
        dirty.addListener((obs, old, value) -> updateTitle());
        source.area().textProperty().addListener((obs, old, text) -> dirty.set(loaded && !text.equals(baseline)));

        patchedBadge.getStyleClass().add("badge");
        patchedBadge.managedProperty().bind(patchedBadge.visibleProperty());
        patchedBadge.setVisible(false);
        ProgressIndicator progress = new ProgressIndicator();
        progress.setMaxSize(42, 42);
        loadingOverlay = new VBox(10, progress, loadingLabel);
        loadingOverlay.setAlignment(Pos.CENTER);
        loadingOverlay.getStyleClass().add("loading-overlay");
        StackPane sourceStack = new StackPane(source, loadingOverlay);
        sourceView.setContent(new BorderPane(sourceStack, header(sourceInfo, patchedBadge), null, null, null));

        ToggleGroup bytecodeMode = new ToggleGroup();
        showCurrent.setToggleGroup(bytecodeMode);
        showOriginal.setToggleGroup(bytecodeMode);
        showCurrent.setSelected(true);
        showCurrent.setTooltip(new Tooltip("Bytecode currently in the JAR, including your patches"));
        showOriginal.setTooltip(new Tooltip("Bytecode of the JAR as it was opened"));
        bytecodeMode.selectedToggleProperty().addListener((obs, old, selected) -> {
            if (selected == null) {
                old.setSelected(true); // keep one mode selected
            } else {
                showBytecode();
            }
        });
        Label show = new Label("Show:");
        sourceView.setClosable(false);
        bytecodeView.setClosable(false);
        bytecodeView.setContent(new BorderPane(bytecode, header(show, showCurrent, showOriginal, bytecodeInfo), null, null, null));

        views.getTabs().addAll(sourceView, bytecodeView);
        views.setSide(Side.BOTTOM);
        views.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        views.getStyleClass().add("editor-views");
        setContent(views);
        setPatched(false);
    }

    ClassRef ref() {
        return ref;
    }

    boolean isLoaded() {
        return loaded;
    }

    boolean isDirty() {
        return dirty.get();
    }

    /** True while the editor shows unmodified decompiler output, which can be regenerated at will. */
    boolean showsDecompilerOutput() {
        return loaded && decompilerOutput && !isDirty();
    }

    String sourceText() {
        return source.getText();
    }

    CodeEditor sourceEditor() {
        return source;
    }

    /** The editor of the view currently shown (source or bytecode). */
    CodeEditor activeEditor() {
        return views.getSelectionModel().getSelectedItem() == bytecodeView ? bytecode : source;
    }

    void showSource() {
        views.getSelectionModel().select(sourceView);
    }

    void setLoading(String message) {
        loadingLabel.setText(message);
        loadingOverlay.setVisible(true);
    }

    /**
     * Shows a decompilation failure. The editor stays usable: the class can be decompiled again (e.g. with the
     * other decompiler) or its source written by hand.
     */
    void showFailure(String message) {
        loadingOverlay.setVisible(false);
        if (!loaded) {
            String text = "// " + message.replace("\n", "\n// ") + "\n";
            baseline = text;
            decompilerOutput = true; // regenerated when the decompiler is switched
            loaded = true;
            source.setText(text);
            dirty.set(false);
            origin = "Decompilation failed: switch the decompiler in the toolbar, or write the class source here";
            sourceInfo.setText(origin);
        }
    }

    /**
     * Shows freshly loaded content.
     *
     * @param origin           where the source comes from, e.g. "Decompiled with CFR"
     * @param decompilerOutput whether {@code text} is unmodified decompiler output
     */
    void showLoaded(String text, String origin, boolean decompilerOutput, int release,
                    String currentBytecode, String originalBytecode, boolean patched) {
        this.baseline = text;
        this.decompilerOutput = decompilerOutput;
        this.loaded = true;
        source.setText(text);
        dirty.set(false);
        this.currentBytecode = currentBytecode;
        this.originalBytecode = originalBytecode;
        this.origin = origin;
        setRelease(release);
        setPatched(patched);
        showBytecode();
        loadingOverlay.setVisible(false);
    }

    /** Records that {@code compiledSource} was compiled and patched into the JAR. */
    void markCompiled(String compiledSource, String currentBytecode, int release) {
        baseline = compiledSource;
        decompilerOutput = false;
        dirty.set(!source.getText().equals(baseline));
        this.currentBytecode = currentBytecode;
        this.origin = "Your source, patched into the JAR";
        setRelease(release);
        setPatched(true);
        showBytecode();
    }

    /** The Java release the class is compiled for. */
    void setRelease(int release) {
        sourceInfo.setText(origin + "   ·   compiles for Java " + release);
    }

    void showProblems(List<Problem> problems) {
        source.setProblems(problems);
    }

    private void setPatched(boolean patched) {
        patchedBadge.setVisible(patched);
        showOriginal.setDisable(!patched);
        if (!patched) {
            showCurrent.setSelected(true);
        }
        if (patched) {
            if (!getStyleClass().contains("patched-tab")) {
                getStyleClass().add("patched-tab");
            }
        } else {
            getStyleClass().remove("patched-tab");
        }
    }

    private void showBytecode() {
        boolean original = showOriginal.isSelected();
        bytecode.setText(original ? originalBytecode : currentBytecode);
        bytecodeInfo.setText(original ? "as in the original JAR" : "as currently in the JAR");
    }

    private void updateTitle() {
        setText((dirty.get() ? "*" : "") + ref.simpleName());
    }

    private static HBox header(Node... nodes) {
        HBox header = new HBox(8, nodes);
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        header.getChildren().add(spacer);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("editor-header");
        return header;
    }
}
