package io.patchjar.ui;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ReadOnlyStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * Runs work off the JavaFX thread, one task at a time so that tasks touching the same JAR never overlap.
 * Callbacks are invoked on the JavaFX thread.
 */
final class Background {

    /** Decompilers recurse deeply on complex methods: give them a large stack. */
    private static final long STACK_SIZE = 256L * 1024 * 1024;

    private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(null, runnable, "patchjar-worker", STACK_SIZE);
        thread.setDaemon(true);
        return thread;
    });
    private final IntegerProperty pending = new SimpleIntegerProperty();
    private final StringProperty message = new SimpleStringProperty("");
    private final BooleanBinding busy = pending.greaterThan(0);

    <T> void run(String description, Callable<T> work, Consumer<T> onSuccess, Consumer<Throwable> onFailure) {
        pending.set(pending.get() + 1);
        message.set(description);
        executor.execute(() -> {
            T result = null;
            Throwable failure = null;
            try {
                result = work.call();
            } catch (Throwable t) { // includes StackOverflowError thrown by decompilers
                failure = t;
            }
            T value = result;
            Throwable error = failure;
            Platform.runLater(() -> {
                pending.set(pending.get() - 1);
                if (error == null) {
                    onSuccess.accept(value);
                } else {
                    onFailure.accept(error);
                }
            });
        });
    }

    BooleanBinding busy() {
        return busy;
    }

    ReadOnlyStringProperty message() {
        return message;
    }

    void shutdown() {
        executor.shutdownNow();
    }
}
