package io.patchjar.ui;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Separator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import io.patchjar.compiler.CompileOptions;
import io.patchjar.compiler.JavaSourceCompiler;
import io.patchjar.compiler.Problem;
import io.patchjar.core.ClassInfo;
import io.patchjar.core.ClassRef;
import io.patchjar.core.CompileOutcome;
import io.patchjar.core.JarModel;
import io.patchjar.core.PatchSession;
import io.patchjar.core.PatchSummary;
import io.patchjar.decompiler.DecompileResult;
import io.patchjar.decompiler.DecompilerKind;

/** The PatchJar window: class tree, editor tabs, problems and log, and every user action. */
public final class MainWindow {

    private static final String APP_NAME = "PatchJar";
    private static final boolean MAC = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("mac");
    private static final String NO_COMPILER = "PatchJar is running on a Java runtime without a compiler (a JRE). "
            + "Classes can be decompiled but not compiled. Run PatchJar with a JDK 21 or newer.";

    private final Stage stage;
    private final Settings settings;
    private final Background background = new Background();
    private final ClassTreePane classTree = new ClassTreePane();
    private final TabPane editors = new TabPane();
    private final ProblemsPane problems = new ProblemsPane();
    private final LogPane log = new LogPane();
    private final TabPane bottomTabs = new TabPane();
    private final Tab problemsTab = new Tab("Problems", problems);
    private final Tab logTab = new Tab("Log", log);
    private final StringProperty status = new SimpleStringProperty("Open a JAR to start.");
    private final Label jarInfo = new Label();
    private final ObjectProperty<PatchSession> session = new SimpleObjectProperty<>();
    private final Scene scene;
    private Path saveTarget;

    private record Target(Integer release) {
    }

    private record Loaded(String source, boolean edited, List<String> messages, String bytecode,
                          String originalBytecode, boolean patched, int release) {
    }

    private record Compiled(CompileOutcome outcome, String bytecode) {
    }

    public MainWindow(Stage stage) {
        this(stage, new Settings());
    }

    MainWindow(Stage stage, Settings settings) {
        this.stage = stage;
        this.settings = settings;

        classTree.setOnOpen(this::openClass);
        classTree.setOnRevert(this::revert);
        problems.setOnNavigate(this::navigateTo);

        editors.setTabClosingPolicy(TabPane.TabClosingPolicy.ALL_TABS);
        editors.getStyleClass().add("editors");
        Node welcome = buildWelcome();
        welcome.visibleProperty().bind(Bindings.isEmpty(editors.getTabs()));
        StackPane editorArea = new StackPane(editors, welcome);

        IntegerBinding problemCount = problems.count();
        problemsTab.textProperty().bind(Bindings.createStringBinding(
                () -> problemCount.get() == 0 ? "Problems" : "Problems (" + problemCount.get() + ")", problemCount));
        problemsTab.setClosable(false);
        logTab.setClosable(false);
        bottomTabs.getTabs().addAll(problemsTab, logTab);
        bottomTabs.getStyleClass().add("bottom-tabs");

        SplitPane right = new SplitPane(editorArea, bottomTabs);
        right.setOrientation(Orientation.VERTICAL);
        right.setDividerPositions(0.74);
        SplitPane.setResizableWithParent(bottomTabs, false);
        SplitPane main = new SplitPane(classTree, right);
        main.setDividerPositions(0.24);
        SplitPane.setResizableWithParent(classTree, false);

        BorderPane root = new BorderPane(main);
        root.setTop(new VBox(buildMenuBar(), buildToolBar()));
        root.setBottom(buildStatusBar());

        Rectangle2D screen = Screen.getPrimary().getVisualBounds();
        scene = new Scene(root, Math.min(1320, screen.getWidth() * 0.92), Math.min(860, screen.getHeight() * 0.92));
        scene.getStylesheets().addAll(stylesheet("app.css"), Fonts.stylesheet());
        applyTheme(settings.darkTheme.get());
        settings.darkTheme.addListener((obs, old, dark) -> applyTheme(dark));
        settings.decompiler.addListener((obs, old, decompiler) -> redecompileIfUnedited());
        settings.targetRelease.addListener((obs, old, release) -> refreshReleases());
        installDragAndDrop();

        stage.setScene(scene);
        stage.setTitle(APP_NAME);
        stage.getIcons().add(appIcon());
        stage.setOnCloseRequest(event -> {
            if (!confirmDiscard("quit")) {
                event.consume();
            }
        });
        log.info("PatchJar started on Java " + Runtime.version() + " (" + System.getProperty("java.vendor") + ")");
    }

    public void show() {
        stage.show();
        if (!JavaSourceCompiler.isAvailable()) {
            log.error(NO_COMPILER);
            Platform.runLater(() -> Dialogs.info(stage, "No Java compiler", NO_COMPILER));
        }
    }

    /** Called when the application exits. */
    public void dispose() {
        PatchSession current = session.get();
        if (current != null) {
            current.close();
        }
        background.shutdown();
        settings.flush();
    }

    // ------------------------------------------------------------------ layout

    private MenuBar buildMenuBar() {
        BooleanBinding noSession = session.isNull();
        BooleanBinding noEditor = editors.getSelectionModel().selectedItemProperty().isNull();

        MenuItem open = menuItem("Open JAR…", "Shortcut+O", this::chooseJar);
        MenuItem save = menuItem("Save Patched JAR", "Shortcut+S", () -> save(false));
        MenuItem saveAs = menuItem("Save Patched JAR As…", "Shortcut+Shift+S", () -> save(true));
        MenuItem closeTab = menuItem("Close Tab", "Shortcut+W", () -> closeTab(currentTab()));
        MenuItem closeJar = menuItem("Close JAR", null, this::closeJar);
        disableWhen(noSession, save, saveAs, closeJar);
        disableWhen(noEditor, closeTab);
        Menu file = new Menu("File", null, open, new SeparatorMenuItem(), save, saveAs, new SeparatorMenuItem(), closeTab, closeJar);
        if (!MAC) {
            file.getItems().addAll(new SeparatorMenuItem(), menuItem("Exit", null, this::quit));
        }

        MenuItem find = menuItem("Find…", "Shortcut+F", () -> withEditor(CodeEditor::showFind));
        MenuItem findNext = menuItem("Find Next", MAC ? "Shortcut+G" : "F3", () -> withEditor(CodeEditor::findNext));
        MenuItem findPrevious = menuItem("Find Previous", MAC ? "Shortcut+Shift+G" : "Shift+F3", () -> withEditor(CodeEditor::findPrevious));
        MenuItem goToLine = menuItem("Go to Line…", "Shortcut+L", this::goToLine);
        MenuItem goToClass = menuItem("Go to Class…", "Shortcut+P", classTree::focusFilter);
        disableWhen(noEditor, find, findNext, findPrevious, goToLine);
        disableWhen(noSession, goToClass);
        Menu edit = new Menu("Edit", null, find, findNext, findPrevious, goToLine, new SeparatorMenuItem(), goToClass);

        MenuItem compile = menuItem("Compile & Patch", "Shortcut+B", this::compileCurrent);
        MenuItem revert = menuItem("Revert to Original…", null, () -> withTab(tab -> revert(tab.ref())));
        MenuItem decompileAgain = menuItem("Decompile Again", "Shortcut+Shift+D", this::decompileAgain);
        disableWhen(noEditor, compile, revert, decompileAgain);
        Menu classMenu = new Menu("Class", null, compile, revert, new SeparatorMenuItem(), decompileAgain);

        MenuItem libraries = menuItem("Classpath Libraries…", null, this::editLibraries);
        MenuItem compilerOptions = menuItem("Compiler Options…", null, () -> Dialogs.compilerOptions(stage, settings));
        CheckMenuItem darkTheme = new CheckMenuItem("Dark Theme");
        darkTheme.selectedProperty().bindBidirectional(settings.darkTheme);
        Menu settingsMenu = new Menu("Settings", null, libraries, compilerOptions, new SeparatorMenuItem(), darkTheme);

        Menu help = new Menu("Help", null,
                menuItem("How to Patch a JAR", null, this::showHelp),
                menuItem("About PatchJar", null, this::showAbout));

        MenuBar bar = new MenuBar(file, edit, classMenu, settingsMenu, help);
        bar.setUseSystemMenuBar(true);
        return bar;
    }

    private ToolBar buildToolBar() {
        BooleanBinding noEditor = editors.getSelectionModel().selectedItemProperty().isNull();

        Button open = toolButton("Open JAR", "Open a JAR, WAR or ZIP (" + keys("Shortcut+O") + ")", this::chooseJar);
        Button save = toolButton("Save JAR", "Save the patched JAR (" + keys("Shortcut+S") + ")", () -> save(false));
        save.disableProperty().bind(session.isNull());
        Button compile = toolButton("Compile & Patch",
                "Compile the edited class and replace its bytecode in the JAR (" + keys("Shortcut+B") + ")", this::compileCurrent);
        compile.getStyleClass().add("accent");
        compile.disableProperty().bind(noEditor);
        Button revert = toolButton("Revert", "Restore the original bytecode of the class", () -> withTab(tab -> revert(tab.ref())));
        revert.disableProperty().bind(noEditor);

        ComboBox<DecompilerKind> decompiler = new ComboBox<>(FXCollections.observableArrayList(DecompilerKind.values()));
        decompiler.valueProperty().bindBidirectional(settings.decompiler);
        decompiler.setTooltip(new Tooltip("Decompiler used to open classes.\n"
                + "Switching re-decompiles the current class if you have not edited it."));

        List<Target> targets = new ArrayList<>();
        targets.add(new Target(null));
        IntStream.iterate(Runtime.version().feature(), release -> release >= PatchSession.MIN_RELEASE, release -> release - 1)
                .forEach(release -> targets.add(new Target(release)));
        ComboBox<Target> target = new ComboBox<>(FXCollections.observableArrayList(targets));
        target.setConverter(new StringConverter<>() {
            @Override
            public String toString(Target value) {
                return value == null || value.release() == null ? "Same as original" : "Java " + value.release();
            }

            @Override
            public Target fromString(String text) {
                return null;
            }
        });
        target.setValue(new Target(settings.targetRelease.get()));
        target.valueProperty().addListener((obs, old, value) -> settings.targetRelease.set(value == null ? null : value.release()));
        target.setTooltip(new Tooltip("Java version of the recompiled classes.\n"
                + "\"Same as original\" keeps the class file version of the class you patch."));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        return new ToolBar(open, save, new Separator(), compile, revert, spacer,
                new Label("Decompiler"), decompiler, new Label("Target"), target);
    }

    private Node buildStatusBar() {
        ProgressIndicator progress = new ProgressIndicator();
        progress.setPrefSize(14, 14);
        progress.setMaxSize(14, 14);
        progress.visibleProperty().bind(background.busy());
        progress.managedProperty().bind(background.busy());
        Label message = new Label();
        message.textProperty().bind(Bindings.when(background.busy()).then(background.message()).otherwise(status));
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox bar = new HBox(8, progress, message, spacer, jarInfo);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.getStyleClass().add("status-bar");
        return bar;
    }

    private Node buildWelcome() {
        Label title = new Label(APP_NAME);
        title.getStyleClass().add("welcome-title");
        Label subtitle = new Label("Patch the bytecode of a JAR by editing decompiled Java source");
        subtitle.getStyleClass().add("welcome-subtitle");
        VBox steps = new VBox(10,
                step("1", "Open a JAR, WAR or ZIP (" + keys("Shortcut+O") + ", or drop it on this window)"),
                step("2", "Double-click a class: it is decompiled to Java"),
                step("3", "Edit the source, then Compile & Patch (" + keys("Shortcut+B") + ")"),
                step("4", "Save the patched JAR (" + keys("Shortcut+S") + ")"));
        steps.setMaxWidth(Region.USE_PREF_SIZE);
        Button open = new Button("Open JAR…");
        open.getStyleClass().add("accent");
        open.setOnAction(e -> chooseJar());
        open.visibleProperty().bind(session.isNull());
        VBox box = new VBox(18, title, subtitle, steps, open);
        box.setAlignment(Pos.CENTER);
        StackPane pane = new StackPane(box);
        pane.getStyleClass().add("welcome");
        return pane;
    }

    private static Node step(String number, String text) {
        Label badge = new Label(number);
        badge.getStyleClass().add("step-number");
        HBox step = new HBox(10, badge, new Label(text));
        step.setAlignment(Pos.CENTER_LEFT);
        return step;
    }

    private void installDragAndDrop() {
        scene.setOnDragOver(event -> {
            if (event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY);
            }
            event.consume();
        });
        scene.setOnDragDropped(event -> {
            List<File> files = event.getDragboard().getFiles();
            boolean accepted = files != null && !files.isEmpty();
            if (accepted) {
                Path dropped = files.get(0).toPath();
                Platform.runLater(() -> {
                    if (confirmDiscard("open another JAR")) {
                        openJar(dropped);
                    }
                });
            }
            event.setDropCompleted(accepted);
            event.consume();
        });
    }

    // ------------------------------------------------------------------ opening

    private void chooseJar() {
        if (!confirmDiscard("open another JAR")) {
            return;
        }
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open JAR");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Java archives (*.jar, *.war, *.ear, *.zip)", "*.jar", "*.war", "*.ear", "*.zip"),
                new FileChooser.ExtensionFilter("All files", "*.*"));
        Path directory = settings.lastDirectory();
        if (directory != null) {
            chooser.setInitialDirectory(directory.toFile());
        }
        File file = chooser.showOpenDialog(stage);
        if (file != null) {
            openJar(file.toPath());
        }
    }

    /** Opens {@code path}, replacing the current JAR without asking. */
    public void openJar(Path path) {
        Path jar = path.toAbsolutePath();
        settings.setLastDirectory(jar.getParent());
        List<Path> libraries = List.copyOf(settings.libraries);
        background.run("Opening " + jar.getFileName() + "…", () -> PatchSession.open(jar, libraries), opened -> {
            replaceSession(opened);
            JarModel model = opened.model();
            List<String> roots = model.roots();
            boolean plain = roots.equals(List.of("")) || roots.isEmpty();
            log.info("Opened " + jar + ": " + model.classCount() + " classes"
                    + (plain ? "" : " in " + roots.stream().map(r -> r.isEmpty() ? "(root)" : r).collect(Collectors.joining(", "))));
            List<String> nested = model.nestedJars();
            if (!nested.isEmpty()) {
                log.info(nested.size() + " nested JAR" + (nested.size() == 1 ? " is" : "s are") + " used as compile libraries");
            }
            if (!opened.manifestLibraries().isEmpty()) {
                log.info("Manifest Class-Path libraries: " + opened.manifestLibraries());
            }
            if (model.isSigned()) {
                log.warn("This JAR is signed. Its signature is removed when a patched version is saved, "
                        + "because patched classes would fail verification.");
            }
            status.set("Opened " + jar.getFileName() + ". Double-click a class to decompile it.");
        }, error -> fail("Could not open " + jar.getFileName(), error));
    }

    private void replaceSession(PatchSession opened) {
        editors.getTabs().clear();
        problems.clearAll();
        PatchSession previous = session.get();
        session.set(opened);
        saveTarget = null;
        classTree.setModel(opened == null ? null : opened.model());
        stage.setTitle(opened == null ? APP_NAME : opened.jarPath().getFileName() + " — " + APP_NAME);
        if (previous != null) {
            background.run("Closing " + previous.jarPath().getFileName() + "…", () -> {
                previous.close();
                return null;
            }, ignored -> { }, error -> log.warn("Could not clean up: " + error));
        }
        refreshJarInfo();
    }

    private void closeJar() {
        if (confirmDiscard("close the JAR")) {
            replaceSession(null);
            status.set("Open a JAR to start.");
        }
    }

    private void quit() {
        if (confirmDiscard("quit")) {
            Platform.exit();
        }
    }

    // ------------------------------------------------------------------ classes

    private void openClass(ClassRef ref) {
        PatchSession current = session.get();
        if (current == null) {
            return;
        }
        ClassEditorTab existing = findTab(ref);
        if (existing != null) {
            editors.getSelectionModel().select(existing);
            return;
        }
        ClassInfo info = current.model().classInfo(ref);
        ClassEditorTab tab = new ClassEditorTab(ref, info == null ? ClassInfo.Kind.CLASS : info.kind());
        tab.setOnCloseRequest(event -> {
            if (!confirmCloseTab(tab)) {
                event.consume();
            }
        });
        tab.setOnClosed(event -> problems.clear(ref));
        tab.setContextMenu(tabMenu(tab));
        editors.getTabs().add(tab);
        editors.getSelectionModel().select(tab);
        load(tab, false);
    }

    /**
     * Fills {@code tab} with the source last compiled for its class or, if there is none or
     * {@code discardEdits} is set, with freshly decompiled source.
     */
    private void load(ClassEditorTab tab, boolean discardEdits) {
        PatchSession current = session.get();
        ClassRef ref = tab.ref();
        DecompilerKind decompiler = settings.decompiler.get();
        Integer targetRelease = settings.targetRelease.get();
        tab.setLoading("Decompiling with " + decompiler + "…");
        background.run("Decompiling " + ref.simpleName() + " with " + decompiler + "…", () -> {
            String edited = discardEdits ? null : current.editedSource(ref);
            DecompileResult decompiled = edited == null ? current.decompile(ref, decompiler) : null;
            return new Loaded(edited != null ? edited : decompiled.source(), edited != null,
                    decompiled == null ? List.of() : decompiled.messages(),
                    current.bytecode(ref, false), current.bytecode(ref, true),
                    current.model().isPatched(ref), current.release(ref, targetRelease).release());
        }, loaded -> {
            if (session.get() != current || !editors.getTabs().contains(tab)) {
                return;
            }
            String origin = loaded.edited() ? "Your last compiled source" : "Decompiled with " + decompiler;
            tab.showLoaded(loaded.source(), origin, !loaded.edited(), loaded.release(),
                    loaded.bytecode(), loaded.originalBytecode(), loaded.patched());
            loaded.messages().forEach(log::warn);
            status.set(loaded.edited() ? "Restored your compiled source of " + ref.simpleName()
                    : "Decompiled " + ref.qualifiedName() + " with " + decompiler);
        }, error -> {
            tab.showFailure("Could not decompile " + ref.qualifiedName() + ": " + error);
            log.error("Decompiling " + ref.qualifiedName() + " with " + decompiler + " failed: " + error);
            status.set("Decompilation failed. Try the other decompiler.");
        });
    }

    private void compileCurrent() {
        ClassEditorTab tab = currentTab();
        PatchSession current = session.get();
        if (tab == null || current == null) {
            return;
        }
        if (!tab.isLoaded()) {
            status.set("Wait until the class is decompiled.");
            return;
        }
        if (!JavaSourceCompiler.isAvailable()) {
            Dialogs.info(stage, "No Java compiler", NO_COMPILER);
            return;
        }
        ClassRef ref = tab.ref();
        String source = tab.sourceText();
        CompileOptions options = settings.compileOptions();
        background.run("Compiling " + ref.simpleName() + "…", () -> {
            CompileOutcome outcome = current.compileAndPatch(ref, source, options);
            return new Compiled(outcome, outcome.success() ? current.bytecode(ref, false) : null);
        }, compiled -> {
            if (session.get() != current) {
                return;
            }
            CompileOutcome outcome = compiled.outcome();
            problems.setProblems(ref, outcome.problems());
            if (outcome.release().note() != null) {
                log.warn(outcome.release().note());
            }
            boolean open = editors.getTabs().contains(tab);
            if (open && tab.sourceText().equals(source)) {
                tab.showProblems(outcome.problems());
            }
            if (outcome.success()) {
                if (open) {
                    tab.markCompiled(source, compiled.bytecode(), outcome.release().release());
                }
                classTree.refresh();
                refreshJarInfo();
                log.info("Patched " + ref.qualifiedName() + " (Java " + outcome.release().release() + "): "
                        + describe(outcome.summary()));
                long warnings = outcome.problems().stream().filter(p -> p.severity() == Problem.Severity.WARNING).count();
                status.set("Patched " + ref.simpleName() + (warnings > 0 ? " (" + plural(warnings, "warning") + ")" : "")
                        + ". Save the JAR to write the change to disk.");
            } else {
                long errors = outcome.errorCount();
                log.error("Compiling " + ref.qualifiedName() + " failed: " + plural(errors, "error"));
                status.set("Compilation failed with " + plural(errors, "error") + ". The JAR was not changed.");
                bottomTabs.getSelectionModel().select(problemsTab);
            }
        }, error -> fail("Could not compile " + ref.qualifiedName(), error));
    }

    private void revert(ClassRef ref) {
        PatchSession current = session.get();
        if (current == null) {
            return;
        }
        ClassEditorTab tab = findTab(ref);
        boolean patched = current.model().isPatched(ref);
        boolean edited = tab != null && tab.isDirty();
        if (!patched && !edited) {
            status.set(ref.simpleName() + " has no changes to revert.");
            return;
        }
        String message = patched
                ? "The original bytecode of " + ref.qualifiedName() + " and its nested classes is restored"
                + (tab != null ? ", and your edits are discarded." : ".")
                : "Your edits of " + ref.qualifiedName() + " are discarded.";
        if (!Dialogs.confirm(stage, "Revert " + ref.simpleName() + "?", message, "Revert")) {
            return;
        }
        background.run("Reverting " + ref.simpleName() + "…", () -> {
            current.revert(ref);
            return null;
        }, ignored -> {
            problems.clear(ref);
            classTree.refresh();
            refreshJarInfo();
            if (patched) {
                log.info("Reverted " + ref.qualifiedName() + " to its original bytecode");
            }
            status.set("Reverted " + ref.simpleName() + ".");
            if (tab != null && editors.getTabs().contains(tab)) {
                load(tab, true);
            }
        }, error -> fail("Could not revert " + ref.qualifiedName(), error));
    }

    private void decompileAgain() {
        ClassEditorTab tab = currentTab();
        if (tab == null) {
            return;
        }
        if (tab.isDirty() && !Dialogs.confirm(stage, "Decompile again?",
                "Your edits of " + tab.ref().simpleName() + " that were not compiled are discarded.", "Decompile")) {
            return;
        }
        load(tab, true);
    }

    private void redecompileIfUnedited() {
        ClassEditorTab tab = currentTab();
        if (tab != null && tab.showsDecompilerOutput()) {
            load(tab, true);
        }
    }

    private void refreshReleases() {
        PatchSession current = session.get();
        if (current != null) {
            tabs().filter(ClassEditorTab::isLoaded)
                    .forEach(tab -> tab.setRelease(current.release(tab.ref(), settings.targetRelease.get()).release()));
        }
    }

    private void navigateTo(ProblemsPane.Row row) {
        ClassEditorTab tab = findTab(row.ref());
        if (tab == null) {
            openClass(row.ref());
            return;
        }
        editors.getSelectionModel().select(tab);
        tab.showSource();
        if (row.problem().line() > 0) {
            tab.sourceEditor().goTo(row.problem().line(), row.problem().column());
        }
    }

    // ------------------------------------------------------------------ saving

    private void save(boolean chooseTarget) {
        PatchSession current = session.get();
        if (current == null) {
            return;
        }
        List<String> uncompiled = tabs().filter(ClassEditorTab::isDirty).map(tab -> tab.ref().simpleName()).toList();
        if (!uncompiled.isEmpty() && !Dialogs.confirm(stage, "Uncompiled edits",
                String.join(", ", uncompiled) + (uncompiled.size() == 1 ? " has" : " have")
                        + " edits that were not compiled. Only compiled changes (Compile & Patch) are saved in the JAR.",
                "Save Anyway")) {
            return;
        }
        Path target = saveTarget;
        if (chooseTarget || target == null) {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Save Patched JAR");
            Path jar = current.jarPath();
            if (Files.isDirectory(jar.getParent())) {
                chooser.setInitialDirectory(jar.getParent().toFile());
            }
            chooser.setInitialFileName(patchedFileName(jar.getFileName().toString()));
            File file = chooser.showSaveDialog(stage);
            if (file == null) {
                return;
            }
            target = file.toPath();
        }
        Path destination = target;
        background.run("Saving " + destination.getFileName() + "…", () -> current.save(destination), report -> {
            saveTarget = report.target();
            log.info("Saved " + report.target() + " (" + report.entries() + " entries, "
                    + plural(current.model().patchedClasses().size(), "patched class") + ")");
            if (!report.strippedSignatureFiles().isEmpty()) {
                log.warn("Removed the JAR signature: " + String.join(", ", report.strippedSignatureFiles()));
            }
            if (report.backup() != null) {
                log.info("The original JAR is kept as " + report.backup());
            }
            refreshJarInfo();
            status.set("Saved " + report.target().getFileName() + ".");
        }, error -> fail("Could not save " + destination.getFileName(), error));
    }

    static String patchedFileName(String name) {
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) + "-patched" + name.substring(dot) : name + "-patched.jar";
    }

    // ------------------------------------------------------------------ tabs and editors

    private ClassEditorTab currentTab() {
        return (ClassEditorTab) editors.getSelectionModel().getSelectedItem();
    }

    private Stream<ClassEditorTab> tabs() {
        return List.copyOf(editors.getTabs()).stream().map(ClassEditorTab.class::cast);
    }

    private ClassEditorTab findTab(ClassRef ref) {
        return tabs().filter(tab -> tab.ref().equals(ref)).findFirst().orElse(null);
    }

    private void withTab(Consumer<ClassEditorTab> action) {
        ClassEditorTab tab = currentTab();
        if (tab != null) {
            action.accept(tab);
        }
    }

    private void withEditor(Consumer<CodeEditor> action) {
        withTab(tab -> action.accept(tab.activeEditor()));
    }

    private boolean confirmCloseTab(ClassEditorTab tab) {
        return !tab.isDirty() || Dialogs.confirm(stage, "Close " + tab.ref().simpleName() + "?",
                "Your edits that were not compiled will be lost.", "Close");
    }

    private void closeTab(ClassEditorTab tab) {
        if (tab != null && confirmCloseTab(tab)) {
            editors.getTabs().remove(tab);
            problems.clear(tab.ref());
        }
    }

    private ContextMenu tabMenu(ClassEditorTab tab) {
        MenuItem close = new MenuItem("Close");
        close.setOnAction(e -> closeTab(tab));
        MenuItem closeOthers = new MenuItem("Close Others");
        closeOthers.setOnAction(e -> tabs().filter(other -> other != tab).forEach(this::closeTab));
        MenuItem closeAll = new MenuItem("Close All");
        closeAll.setOnAction(e -> tabs().forEach(this::closeTab));
        return new ContextMenu(close, closeOthers, closeAll);
    }

    private void goToLine() {
        ClassEditorTab tab = currentTab();
        if (tab == null) {
            return;
        }
        CodeEditor editor = tab.activeEditor();
        TextInputDialog dialog = new TextInputDialog(Integer.toString(editor.currentLine()));
        dialog.initOwner(stage);
        dialog.setTitle("Go to Line");
        dialog.setHeaderText(null);
        dialog.setContentText("Line (1–" + editor.lineCount() + "):");
        dialog.showAndWait().map(String::trim).ifPresent(text -> {
            try {
                editor.goTo(Long.parseLong(text), 1);
            } catch (NumberFormatException ignored) {
                status.set("Not a line number: " + text);
            }
        });
    }

    // ------------------------------------------------------------------ settings and help

    private void editLibraries() {
        PatchSession current = session.get();
        int automatic = current == null ? 0 : current.model().nestedJars().size() + current.manifestLibraries().size();
        Dialogs.libraries(stage, List.copyOf(settings.libraries), automatic, settings).ifPresent(libraries -> {
            settings.libraries.setAll(libraries);
            log.info("Classpath libraries: " + (libraries.isEmpty() ? "none"
                    : libraries.stream().map(p -> p.getFileName().toString()).collect(Collectors.joining(", "))));
            if (current != null) {
                background.run("Updating the classpath…", () -> {
                    current.setUserLibraries(libraries);
                    return null;
                }, ignored -> status.set("Classpath updated."), error -> fail("Could not update the classpath", error));
            }
        });
    }

    private void showHelp() {
        Dialogs.info(stage, "How to Patch a JAR", String.join("\n\n",
                "1. Open a JAR (File > Open JAR…, or drop it on the window). Classes of Spring Boot fat JARs "
                        + "(BOOT-INF/classes) and WARs (WEB-INF/classes) are supported; their nested JARs are used as libraries.",
                "2. Double-click a class to decompile it. If the output does not compile, try the other decompiler "
                        + "(toolbar): Vineflower usually recompiles best, CFR is an alternative.",
                "3. Edit the Java source and choose Compile & Patch (" + keys("Shortcut+B") + "). javac compiles the class "
                        + "against the JAR and its libraries, for the Java version of the original class file. Its bytecode, "
                        + "and that of its nested and anonymous classes, is replaced in memory: see the Bytecode tab.",
                "4. Decompiled code sometimes needs small fixes (generics, casts) before it compiles: errors are listed "
                        + "under Problems and underlined in the editor. Add missing dependencies under Settings > Classpath Libraries.",
                "5. Save the patched JAR (" + keys("Shortcut+S") + "). A signed JAR loses its signature. "
                        + "Saving over the opened JAR keeps a .bak copy of the original."));
    }

    private void showAbout() {
        Dialogs.info(stage, "About PatchJar", "PatchJar 1.0\n\n"
                + "Edits the bytecode of JAR files through decompiled Java source.\n\n"
                + "Decompilers: Vineflower and CFR. Bytecode: ASM. Editor: RichTextFX.\n"
                + "Compiler: javac from the running JDK (Java " + Runtime.version().feature() + ").");
    }

    private void applyTheme(boolean dark) {
        String css = stylesheet("dark.css");
        if (dark && !scene.getStylesheets().contains(css)) {
            scene.getStylesheets().add(css);
        } else if (!dark) {
            scene.getStylesheets().remove(css);
        }
    }

    // ------------------------------------------------------------------ helpers

    private boolean confirmDiscard(String action) {
        PatchSession current = session.get();
        boolean unsaved = current != null && current.hasUnsavedChanges();
        boolean edited = tabs().anyMatch(ClassEditorTab::isDirty);
        if (!unsaved && !edited) {
            return true;
        }
        String what = unsaved ? "Your patches have not been saved to a JAR file." : "Some classes have edits that were not compiled.";
        return Dialogs.confirm(stage, "Discard changes?", what + " Discard them and " + action + "?", "Discard");
    }

    private void refreshJarInfo() {
        PatchSession current = session.get();
        if (current == null) {
            jarInfo.setText("");
            return;
        }
        JarModel model = current.model();
        jarInfo.setText(current.jarPath().getFileName() + "   ·   " + plural(model.classCount(), "class") + "   ·   "
                + model.patchedClasses().size() + " patched" + (current.hasUnsavedChanges() ? "   ·   unsaved" : ""));
    }

    private void fail(String title, Throwable error) {
        log.error(title + ": " + error);
        status.set(title + ".");
        Dialogs.error(stage, title, error);
    }

    private static String describe(PatchSummary summary) {
        List<String> parts = new ArrayList<>();
        if (!summary.replaced().isEmpty()) {
            parts.add("replaced " + classFiles(summary.replaced()));
        }
        if (!summary.added().isEmpty()) {
            parts.add("added " + classFiles(summary.added()));
        }
        if (!summary.removed().isEmpty()) {
            parts.add("removed " + classFiles(summary.removed()));
        }
        return String.join("; ", parts);
    }

    private static String classFiles(List<String> names) {
        return names.stream().map(name -> name.substring(name.lastIndexOf('/') + 1) + ".class").collect(Collectors.joining(", "));
    }

    private static String plural(long count, String noun) {
        return count + " " + noun + (count == 1 ? "" : noun.endsWith("s") ? "es" : "s");
    }

    private static MenuItem menuItem(String text, String accelerator, Runnable action) {
        MenuItem item = new MenuItem(text);
        item.setMnemonicParsing(false);
        if (accelerator != null) {
            item.setAccelerator(KeyCombination.keyCombination(accelerator));
        }
        item.setOnAction(e -> action.run());
        return item;
    }

    private static void disableWhen(BooleanBinding condition, MenuItem... items) {
        for (MenuItem item : items) {
            item.disableProperty().bind(condition);
        }
    }

    private static Button toolButton(String text, String tooltip, Runnable action) {
        Button button = new Button(text);
        button.setMnemonicParsing(false);
        button.setTooltip(new Tooltip(tooltip));
        button.setOnAction(e -> action.run());
        return button;
    }

    private static String keys(String accelerator) {
        return KeyCombination.keyCombination(accelerator).getDisplayText();
    }

    private static String stylesheet(String name) {
        return Objects.requireNonNull(MainWindow.class.getResource(name), name).toExternalForm();
    }

    private static Image appIcon() {
        Canvas canvas = new Canvas(64, 64);
        GraphicsContext g = canvas.getGraphicsContext2D();
        g.setFill(Color.web("#2f6fde"));
        g.fillRoundRect(2, 2, 60, 60, 18, 18);
        g.setFill(Color.WHITE);
        g.setFont(Font.font("System", FontWeight.BOLD, 26));
        g.setTextAlign(TextAlignment.CENTER);
        g.setTextBaseline(VPos.CENTER);
        g.fillText("{ }", 32, 31);
        SnapshotParameters parameters = new SnapshotParameters();
        parameters.setFill(Color.TRANSPARENT);
        return canvas.snapshot(parameters, null);
    }
}
