package io.patchjar.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.IndexRange;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

import org.fxmisc.richtext.CodeArea;

/** Incremental text search over a code area. */
final class FindBar extends HBox {

    enum Direction { NEXT, PREVIOUS, INCREMENTAL }

    private final CodeArea area;
    private final TextField query = new TextField();
    private final CheckBox matchCase = new CheckBox("Match case");
    private final Label status = new Label();

    FindBar(CodeArea area) {
        this.area = area;
        getStyleClass().add("find-bar");
        setAlignment(Pos.CENTER_LEFT);
        setSpacing(6);

        query.setPromptText("Find");
        query.setPrefColumnCount(26);
        query.textProperty().addListener((obs, old, text) -> find(Direction.INCREMENTAL));
        query.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                find(event.isShiftDown() ? Direction.PREVIOUS : Direction.NEXT);
                event.consume();
            } else if (event.getCode() == KeyCode.ESCAPE) {
                close();
                event.consume();
            }
        });
        matchCase.selectedProperty().addListener((obs, old, selected) -> find(Direction.INCREMENTAL));

        Button previous = new Button("Previous");
        previous.setOnAction(e -> find(Direction.PREVIOUS));
        Button next = new Button("Next");
        next.setOnAction(e -> find(Direction.NEXT));
        Button close = new Button("×");
        close.getStyleClass().add("find-close");
        close.setOnAction(e -> close());
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        status.getStyleClass().add("find-status");

        getChildren().addAll(query, previous, next, matchCase, status, spacer, close);
        setVisible(false);
        setManaged(false);
    }

    void open(String initialQuery) {
        setVisible(true);
        setManaged(true);
        if (initialQuery != null) {
            query.setText(initialQuery);
        }
        query.requestFocus();
        query.selectAll();
    }

    void close() {
        setVisible(false);
        setManaged(false);
        area.requestFocus();
    }

    void find(Direction direction) {
        if (!isVisible() && direction == Direction.INCREMENTAL) {
            return;
        }
        String text = query.getText();
        if (text.isEmpty()) {
            status.setText("");
            return;
        }
        int flags = matchCase.isSelected() ? 0 : Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        Matcher matcher = Pattern.compile(Pattern.quote(text), flags).matcher(area.getText());
        List<int[]> matches = new ArrayList<>();
        while (matcher.find()) {
            matches.add(new int[] {matcher.start(), matcher.end()});
        }
        if (matches.isEmpty()) {
            status.setText("No matches");
            return;
        }
        IndexRange selection = area.getSelection();
        int index = switch (direction) {
            case NEXT -> firstIndex(matches, selection.getLength() > 0 ? selection.getStart() + 1 : area.getCaretPosition());
            case INCREMENTAL -> firstIndex(matches, selection.getStart());
            case PREVIOUS -> lastIndexBefore(matches, selection.getStart());
        };
        int[] match = matches.get(index);
        area.selectRange(match[0], match[1]);
        area.requestFollowCaret();
        status.setText((index + 1) + " of " + matches.size());
    }

    /** Index of the first match starting at or after {@code position}, wrapping around. */
    private static int firstIndex(List<int[]> matches, int position) {
        for (int i = 0; i < matches.size(); i++) {
            if (matches.get(i)[0] >= position) {
                return i;
            }
        }
        return 0;
    }

    /** Index of the last match starting before {@code position}, wrapping around. */
    private static int lastIndexBefore(List<int[]> matches, int position) {
        for (int i = matches.size() - 1; i >= 0; i--) {
            if (matches.get(i)[0] < position) {
                return i;
            }
        }
        return matches.size() - 1;
    }
}
