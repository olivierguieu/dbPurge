package io.patchjar.ui;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;
import org.objectweb.asm.util.Printer;

/** Regex based syntax highlighting; each named group becomes the CSS style class of the text it matches. */
final class Highlighters {

    private static final String[] JAVA_KEYWORDS = {
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const", "continue",
            "default", "do", "double", "else", "enum", "extends", "final", "finally", "float", "for", "goto", "if",
            "implements", "import", "instanceof", "int", "interface", "long", "native", "new", "package", "private",
            "protected", "public", "return", "short", "static", "strictfp", "super", "switch", "synchronized", "this",
            "throw", "throws", "transient", "try", "void", "volatile", "while", "var", "record", "yield", "sealed",
            "permits", "non-sealed", "true", "false", "null"};

    // Strings use "unrolled" loops so that long literals do not overflow the regex engine's stack.
    private static final String STRING = "\"\"\"(?s:.*?)\"\"\"|\"[^\"\\\\\\n]*(?:\\\\.[^\"\\\\\\n]*)*\"";
    private static final String CHAR = "'[^'\\\\\\n]*(?:\\\\.[^'\\\\\\n]*)*'";
    private static final String NUMBER = "\\b(?:0[xX][0-9a-fA-F_]+[lL]?|0[bB][01_]+[lL]?|\\d[\\d_]*(?:\\.[\\d_]*)?(?:[eE][+-]?\\d+)?[fFdDlL]?)\\b";

    private static final List<String> JAVA_GROUPS = List.of("COMMENT", "STRING", "CHAR", "ANNOTATION", "KEYWORD", "NUMBER");
    private static final Pattern JAVA = Pattern.compile(
            "(?<COMMENT>//[^\\n]*|/\\*(?s:.*?)\\*/)"
                    + "|(?<STRING>" + STRING + ")"
                    + "|(?<CHAR>" + CHAR + ")"
                    + "|(?<ANNOTATION>@[\\p{L}_$][\\p{L}\\p{N}_$]*(?:\\.[\\p{L}_$][\\p{L}\\p{N}_$]*)*)"
                    + "|(?<KEYWORD>\\b(?:" + String.join("|", JAVA_KEYWORDS) + ")\\b)"
                    + "|(?<NUMBER>" + NUMBER + ")");

    private static final String[] BYTECODE_KEYWORDS = {
            "public", "private", "protected", "static", "final", "synchronized", "volatile", "transient", "native",
            "abstract", "strictfp", "synthetic", "bridge", "varargs", "mandated", "deprecated", "class", "interface",
            "enum", "record", "extends", "implements", "throws", "default"};

    private static final List<String> BYTECODE_GROUPS = List.of("COMMENT", "STRING", "OPCODE", "LABEL", "KEYWORD", "TYPE", "NUMBER");
    private static final Pattern BYTECODE = Pattern.compile(
            "(?<COMMENT>//[^\\n]*)"
                    + "|(?<STRING>" + STRING + ")"
                    + "|(?<OPCODE>\\b(?:" + opcodes() + ")\\b)"
                    + "|(?<LABEL>\\bL\\d+\\b)"
                    + "|(?<KEYWORD>\\b(?:" + String.join("|", BYTECODE_KEYWORDS) + ")\\b)"
                    + "|(?<TYPE>\\b[\\p{L}_$][\\p{L}\\p{N}_$]*(?:/[\\p{L}_$][\\p{L}\\p{N}_$]*)+)"
                    + "|(?<NUMBER>-?\\b\\d+(?:\\.\\d+)?[LFD]?\\b)");

    private Highlighters() {
    }

    static StyleSpans<Collection<String>> java(String text) {
        return highlight(text, JAVA, JAVA_GROUPS);
    }

    static StyleSpans<Collection<String>> bytecode(String text) {
        return highlight(text, BYTECODE, BYTECODE_GROUPS);
    }

    private static StyleSpans<Collection<String>> highlight(String text, Pattern pattern, List<String> groups) {
        Matcher matcher = pattern.matcher(text);
        StyleSpansBuilder<Collection<String>> spans = new StyleSpansBuilder<>();
        int end = 0;
        while (matcher.find()) {
            String styleClass = groups.stream()
                    .filter(group -> matcher.group(group) != null)
                    .findFirst()
                    .map(group -> "hl-" + group.toLowerCase(Locale.ROOT))
                    .orElseThrow();
            spans.add(List.of(), matcher.start() - end);
            spans.add(List.of(styleClass), matcher.end() - matcher.start());
            end = matcher.end();
        }
        spans.add(List.of(), text.length() - end);
        return spans.create();
    }

    private static String opcodes() {
        Stream<String> pseudo = Stream.of("LINENUMBER", "LOCALVARIABLE", "MAXSTACK", "MAXLOCALS", "FRAME", "TRYCATCHBLOCK");
        return Stream.concat(Arrays.stream(Printer.OPCODES), pseudo)
                .filter(Objects::nonNull)
                .filter(opcode -> !opcode.isEmpty())
                .distinct()
                .sorted((a, b) -> b.length() - a.length()) // longest first: ALOAD before LOAD-like prefixes
                .collect(Collectors.joining("|"));
    }
}
