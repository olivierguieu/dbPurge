package io.patchjar.compiler;

import java.util.List;

/**
 * @param release      the Java release to compile for, or null to match the original class file
 * @param useRelease   compile with {@code --release} (checks API usage against the target JDK) rather than
 *                     {@code -source}/{@code -target} against the running JDK
 * @param extraOptions additional javac options, e.g. {@code --add-exports java.base/sun.nio.ch=ALL-UNNAMED}
 */
public record CompileOptions(Integer release, boolean useRelease, List<String> extraOptions) {

    public CompileOptions {
        extraOptions = List.copyOf(extraOptions);
    }

    public static CompileOptions defaults() {
        return new CompileOptions(null, true, List.of());
    }
}
