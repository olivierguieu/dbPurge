package io.patchjar.compiler;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.SimpleJavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;

/** Compiles a single in-memory compilation unit with the JDK's javac. */
public final class JavaSourceCompiler {

    /**
     * @param classes compiled class files by internal name (empty when compilation failed)
     */
    public record Result(boolean success, Map<String, byte[]> classes, List<Problem> problems) {
    }

    private JavaSourceCompiler() {
    }

    /** False when running on a JRE, which has no {@code javax.tools} compiler. */
    public static boolean isAvailable() {
        return ToolProvider.getSystemJavaCompiler() != null;
    }

    /**
     * @param className internal name of the top-level class declared by {@code source}
     * @param release   Java release of the generated class files
     * @param classpath JARs and directories the source is compiled against
     * @param outputDir empty directory receiving the class files
     */
    public static Result compile(String className, String source, int release, CompileOptions options,
                                 List<Path> classpath, Path outputDir) throws IOException {
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        if (javac == null) {
            return failure("No Java compiler available: PatchJar must run on a JDK, not a JRE.");
        }
        Files.createDirectories(outputDir);

        List<String> arguments = new ArrayList<>();
        if (options.useRelease()) {
            arguments.addAll(List.of("--release", Integer.toString(release)));
        } else {
            arguments.addAll(List.of("-source", Integer.toString(release), "-target", Integer.toString(release)));
        }
        arguments.addAll(List.of("-g", "-proc:none", "-implicit:none", "-Xlint:-options"));
        arguments.addAll(options.extraOptions());

        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        StringWriter output = new StringWriter();
        boolean success;
        try (StandardJavaFileManager files = javac.getStandardFileManager(diagnostics, null, StandardCharsets.UTF_8)) {
            files.setLocationFromPaths(StandardLocation.CLASS_PATH, classpath);
            files.setLocationFromPaths(StandardLocation.CLASS_OUTPUT, List.of(outputDir));
            JavaFileObject unit = new SourceFile(className, source);
            try {
                success = javac.getTask(output, files, diagnostics, arguments, null, List.of(unit)).call();
            } catch (IllegalArgumentException | IllegalStateException e) {
                return failure(e.getMessage()); // invalid option, e.g. an unsupported --release value
            }
        }

        List<Problem> problems = new ArrayList<>();
        for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics()) {
            Problem.Severity severity = switch (d.getKind()) {
                case ERROR -> Problem.Severity.ERROR;
                case WARNING, MANDATORY_WARNING -> Problem.Severity.WARNING;
                default -> Problem.Severity.NOTE;
            };
            boolean inSource = d.getSource() != null;
            problems.add(new Problem(severity,
                    inSource ? d.getLineNumber() : -1, inSource ? d.getColumnNumber() : -1,
                    inSource ? d.getStartPosition() : -1, inSource ? d.getEndPosition() : -1,
                    d.getMessage(null)));
        }
        String extraOutput = output.toString().trim();
        if (!extraOutput.isEmpty()) {
            problems.add(new Problem(success ? Problem.Severity.NOTE : Problem.Severity.ERROR, -1, -1, -1, -1, extraOutput));
        }
        if (!success) {
            if (problems.stream().noneMatch(Problem::isError)) {
                problems.add(Problem.error("Compilation failed."));
            }
            return new Result(false, Map.of(), problems);
        }
        return new Result(true, readClasses(outputDir), problems);
    }

    private static Map<String, byte[]> readClasses(Path outputDir) throws IOException {
        Map<String, byte[]> classes = new TreeMap<>();
        List<Path> classFiles;
        try (Stream<Path> files = Files.walk(outputDir)) {
            classFiles = files.filter(p -> p.getFileName().toString().endsWith(".class")).toList();
        }
        for (Path file : classFiles) {
            String relative = outputDir.relativize(file).toString().replace(File.separatorChar, '/');
            classes.put(relative.substring(0, relative.length() - ".class".length()), Files.readAllBytes(file));
        }
        return classes;
    }

    private static Result failure(String message) {
        return new Result(false, Map.of(), List.of(Problem.error(message)));
    }

    private static final class SourceFile extends SimpleJavaFileObject {
        private final String source;

        SourceFile(String className, String source) {
            super(uri(className), Kind.SOURCE);
            this.source = source;
        }

        private static URI uri(String className) {
            try {
                return new URI("string", null, "/" + className + Kind.SOURCE.extension, null);
            } catch (URISyntaxException e) {
                throw new IllegalArgumentException("Invalid class name: " + className, e);
            }
        }

        @Override
        public CharSequence getCharContent(boolean ignoreEncodingErrors) {
            return source;
        }
    }
}
