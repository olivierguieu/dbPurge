package io.patchjar.compiler;

/**
 * A compiler diagnostic.
 *
 * @param line        1-based line in the compiled source, or -1 when the problem is not tied to the source
 * @param column      1-based column, or -1
 * @param startOffset character offset of the start of the problem in the source, or -1
 * @param endOffset   character offset of the end of the problem in the source, or -1
 */
public record Problem(Severity severity, long line, long column, long startOffset, long endOffset, String message) {

    public enum Severity { ERROR, WARNING, NOTE }

    public static Problem error(String message) {
        return new Problem(Severity.ERROR, -1, -1, -1, -1, message);
    }

    public boolean isError() {
        return severity == Severity.ERROR;
    }
}
