package io.patchjar;

/**
 * Entry point of the runnable JAR. It must not extend {@code Application}: when the main class does, the JDK
 * launcher refuses to start unless JavaFX is on the module path.
 */
public final class Launcher {

    private Launcher() {
    }

    public static void main(String[] args) {
        PatchJarApp.main(args);
    }
}
