package io.patchjar.core;

import java.util.List;

import io.patchjar.compiler.Problem;

/**
 * Result of compiling an edited class and, on success, patching it into the JAR.
 *
 * @param release the Java release the source was compiled for
 * @param summary the class files replaced, added and removed; null when compilation failed
 */
public record CompileOutcome(boolean success, ReleaseChoice release, List<Problem> problems, PatchSummary summary) {

    public long errorCount() {
        return problems.stream().filter(Problem::isError).count();
    }
}
