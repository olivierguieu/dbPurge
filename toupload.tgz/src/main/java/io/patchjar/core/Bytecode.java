package io.patchjar.core;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.util.Textifier;
import org.objectweb.asm.util.TraceClassVisitor;

/** Class file helpers: version numbers and a textual bytecode listing. */
public final class Bytecode {

    private Bytecode() {
    }

    /** Human-readable disassembly of a class file (ASM Textifier format). */
    public static String textify(byte[] classFile) {
        StringWriter text = new StringWriter();
        try {
            new ClassReader(classFile).accept(new TraceClassVisitor(null, new Textifier(), new PrintWriter(text)), 0);
        } catch (RuntimeException e) {
            text.append("\n// Could not disassemble: ").append(String.valueOf(e));
        }
        return text.toString();
    }

    public static int majorVersion(byte[] classFile) {
        if (classFile == null || classFile.length < 8) {
            return 0;
        }
        return ((classFile[6] & 0xFF) << 8) | (classFile[7] & 0xFF);
    }

    /** Java feature release for a class file major version (52 → 8); older versions map to 1..4. */
    public static int javaRelease(int majorVersion) {
        return majorVersion >= 49 ? majorVersion - 44 : Math.max(1, majorVersion - 44);
    }

    public static String describeVersion(int majorVersion) {
        int release = javaRelease(majorVersion);
        return (majorVersion < 49 ? "Java 1." + release : "Java " + release) + " (class file " + majorVersion + ")";
    }
}
