package io.patchjar.core;

/**
 * The Java release a class is recompiled for.
 *
 * @param note explains why the release differs from the original class file, or null
 */
public record ReleaseChoice(int release, String note) {
}
