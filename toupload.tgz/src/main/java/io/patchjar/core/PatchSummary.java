package io.patchjar.core;

import java.util.List;

/** Class files (internal names) touched by applying a compiled class to the JAR. */
public record PatchSummary(List<String> replaced, List<String> added, List<String> removed) {

    public int total() {
        return replaced.size() + added.size() + removed.size();
    }
}
