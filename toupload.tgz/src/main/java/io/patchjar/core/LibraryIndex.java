package io.patchjar.core;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Looks up class files in an ordered list of JARs and class directories. */
public final class LibraryIndex implements ClassLookup, Closeable {

    private final List<Path> paths;
    private final Map<Path, Boolean> directories = new HashMap<>();
    private final Map<Path, ZipFile> archives = new HashMap<>();
    private boolean closed;

    public LibraryIndex(List<Path> paths) {
        this.paths = List.copyOf(paths);
    }

    public List<Path> paths() {
        return paths;
    }

    @Override
    public synchronized byte[] find(String internalName) {
        if (closed) {
            return null;
        }
        String entryName = internalName + ".class";
        for (Path path : paths) {
            try {
                if (directories.computeIfAbsent(path, Files::isDirectory)) {
                    Path file = path.resolve(entryName);
                    if (Files.isRegularFile(file)) {
                        return Files.readAllBytes(file);
                    }
                    continue;
                }
                ZipFile zip = archive(path);
                ZipEntry entry = zip == null ? null : zip.getEntry(entryName);
                if (entry != null) {
                    try (InputStream in = zip.getInputStream(entry)) {
                        return in.readAllBytes();
                    }
                }
            } catch (IOException | IllegalStateException ignored) {
                // unreadable library: skip it
            }
        }
        return null;
    }

    private ZipFile archive(Path path) {
        if (archives.containsKey(path)) {
            return archives.get(path);
        }
        ZipFile zip;
        try {
            zip = Files.isRegularFile(path) ? new ZipFile(path.toFile()) : null;
        } catch (IOException e) {
            zip = null;
        }
        archives.put(path, zip);
        return zip;
    }

    @Override
    public synchronized void close() {
        closed = true;
        for (ZipFile zip : archives.values()) {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException ignored) {
                    // nothing useful to do
                }
            }
        }
        archives.clear();
    }
}
