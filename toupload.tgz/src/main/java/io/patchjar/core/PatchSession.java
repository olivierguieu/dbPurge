package io.patchjar.core;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import io.patchjar.compiler.CompileOptions;
import io.patchjar.compiler.JavaSourceCompiler;
import io.patchjar.compiler.Problem;
import io.patchjar.decompiler.DecompileResult;
import io.patchjar.decompiler.DecompilerKind;

/**
 * An opened JAR and everything needed to patch it: decompiling classes, compiling edited sources against the
 * JAR and its libraries, applying the result, and saving the patched archive.
 * <p>
 * Classes are compiled against, in order: the current content of the class's root (patched classes first),
 * the other class roots, the JARs nested in the archive, the manifest {@code Class-Path}, then the libraries
 * configured by the user.
 */
public final class PatchSession implements Closeable {

    /** Oldest {@code --release} supported by current JDKs. */
    public static final int MIN_RELEASE = 8;

    private final JarModel model;
    private final Path workDir;
    private final List<Path> manifestLibraries;
    private final Map<ClassRef, String> editedSources = new ConcurrentHashMap<>();
    private final Map<String, Path> snapshots = new HashMap<>();
    private List<Path> userLibraries;
    private List<Path> nestedLibraries;
    private LibraryIndex libraries;
    private volatile long savedGeneration;
    private volatile boolean everSaved;

    private PatchSession(JarModel model, List<Path> userLibraries) throws IOException {
        this.model = model;
        this.userLibraries = List.copyOf(userLibraries);
        this.manifestLibraries = resolveManifestClassPath(model);
        this.workDir = Files.createTempDirectory("patchjar-");
    }

    public static PatchSession open(Path jar, List<Path> userLibraries) throws IOException {
        return new PatchSession(JarModel.load(jar), userLibraries);
    }

    public JarModel model() {
        return model;
    }

    public Path jarPath() {
        return model.source();
    }

    public List<Path> manifestLibraries() {
        return manifestLibraries;
    }

    public synchronized void setUserLibraries(List<Path> userLibraries) {
        this.userLibraries = List.copyOf(userLibraries);
        closeLibraries();
    }

    // ------------------------------------------------------------------ decompiling

    public DecompileResult decompile(ClassRef ref, DecompilerKind decompiler) throws IOException {
        return decompiler.create().decompile(ref.name(), model.family(ref), classpath(ref.root()));
    }

    /** The source last compiled successfully for {@code ref}, or null. */
    public String editedSource(ClassRef ref) {
        return editedSources.get(ref);
    }

    /** Disassembly of the class and its nested classes, either as they are now or as in the original JAR. */
    public String bytecode(ClassRef ref, boolean original) {
        List<String> names = original ? model.originalFamily(ref) : model.family(ref);
        StringBuilder text = new StringBuilder();
        for (String name : names) {
            byte[] bytes = original ? model.originalClassBytes(ref.root(), name) : model.classBytes(ref.root(), name);
            if (bytes == null) {
                continue;
            }
            if (!text.isEmpty()) {
                text.append('\n');
            }
            text.append("// ======== ").append(name).append(".class · ")
                    .append(Bytecode.describeVersion(Bytecode.majorVersion(bytes))).append(" ========\n");
            text.append(Bytecode.textify(bytes));
        }
        return text.isEmpty() ? "// This class does not exist in the original JAR.\n" : text.toString();
    }

    // ------------------------------------------------------------------ compiling

    /** The release to compile {@code ref} for: {@code override} if set, else the original class file version. */
    public ReleaseChoice release(ClassRef ref, Integer override) {
        if (override != null) {
            return new ReleaseChoice(override, null);
        }
        byte[] bytes = model.originalClassBytes(ref.root(), ref.name());
        if (bytes == null) {
            bytes = model.classBytes(ref.root(), ref.name());
        }
        int major = Bytecode.majorVersion(bytes);
        int wanted = Bytecode.javaRelease(major);
        int newest = Runtime.version().feature();
        if (wanted < MIN_RELEASE) {
            return new ReleaseChoice(MIN_RELEASE, "The original class targets " + Bytecode.describeVersion(major)
                    + "; it is compiled for Java " + MIN_RELEASE + ", the oldest release javac supports.");
        }
        if (wanted > newest) {
            return new ReleaseChoice(newest, "The original class targets " + Bytecode.describeVersion(major)
                    + " but PatchJar runs on Java " + newest + "; it is compiled for Java " + newest
                    + ". Run PatchJar on a newer JDK to keep the original version.");
        }
        return new ReleaseChoice(wanted, null);
    }

    /**
     * Compiles {@code source} as the new version of {@code ref} and, if it compiles, replaces the class and its
     * nested classes in the JAR (in memory; see {@link #save(Path)}).
     */
    public CompileOutcome compileAndPatch(ClassRef ref, String source, CompileOptions options) throws IOException {
        ReleaseChoice release = release(ref, options.release());
        Path dir = Files.createTempDirectory(workDir, "compile-");
        try {
            List<Path> classpath = compileClasspath(ref, dir.resolve("overlay"));
            JavaSourceCompiler.Result result = JavaSourceCompiler.compile(
                    ref.name(), source, release.release(), options, classpath, dir.resolve("classes"));
            if (!result.success()) {
                return new CompileOutcome(false, release, result.problems(), null);
            }
            if (!result.classes().containsKey(ref.name())) {
                List<Problem> problems = new ArrayList<>(result.problems());
                problems.add(0, Problem.error("The source must declare class " + ref.qualifiedName() + " but it declares "
                        + String.join(", ", result.classes().keySet().stream().map(n -> n.replace('/', '.')).toList())));
                return new CompileOutcome(false, release, problems, null);
            }
            PatchSummary summary = model.applyPatch(ref, result.classes());
            editedSources.put(ref, source);
            return new CompileOutcome(true, release, result.problems(), summary);
        } finally {
            FileUtil.deleteRecursively(dir);
        }
    }

    /** Restores the original bytecode of {@code ref} and its nested classes. */
    public void revert(ClassRef ref) {
        model.revert(ref);
        editedSources.remove(ref);
    }

    // ------------------------------------------------------------------ saving

    public boolean hasUnsavedChanges() {
        return model.generation() != savedGeneration && (everSaved || model.hasChanges());
    }

    /**
     * Writes the patched JAR. When {@code target} is the JAR that was opened, a {@code .bak} copy of it is kept
     * (unless one already exists).
     */
    public SaveReport save(Path target) throws IOException {
        Path destination = target.toAbsolutePath();
        Path backup = null;
        if (Files.exists(destination) && Files.isSameFile(destination, model.source())) {
            backup = destination.resolveSibling(destination.getFileName() + ".bak");
            if (!Files.exists(backup)) {
                Files.copy(destination, backup, StandardCopyOption.COPY_ATTRIBUTES);
            }
        }
        long generation = model.generation();
        SaveReport report = model.save(destination).withBackup(backup);
        savedGeneration = generation;
        everSaved = true;
        return report;
    }

    @Override
    public synchronized void close() {
        closeLibraries();
        FileUtil.deleteRecursively(workDir);
    }

    // ------------------------------------------------------------------ classpath

    private synchronized ClassLookup classpath(String root) throws IOException {
        if (libraries == null) {
            List<Path> paths = new ArrayList<>(nestedLibraries());
            paths.addAll(manifestLibraries);
            paths.addAll(userLibraries);
            libraries = new LibraryIndex(paths);
        }
        return model.lookup(root).or(libraries).or(JdkClasses.INSTANCE);
    }

    private List<Path> compileClasspath(ClassRef ref, Path overlayDir) throws IOException {
        List<String> roots = new ArrayList<>(List.of(ref.root()));
        model.roots().stream().filter(root -> !root.equals(ref.root())).forEach(roots::add);

        List<Path> classpath = new ArrayList<>();
        for (int i = 0; i < roots.size(); i++) {
            String root = roots.get(i);
            Map<String, byte[]> patched = model.modifiedClasses(root);
            if (!patched.isEmpty()) {
                Path overlay = overlayDir.resolve(Integer.toString(i));
                for (Map.Entry<String, byte[]> patchedClass : patched.entrySet()) {
                    Path file = overlay.resolve(patchedClass.getKey() + ".class");
                    Files.createDirectories(file.getParent());
                    Files.write(file, patchedClass.getValue());
                }
                classpath.add(overlay);
            }
            classpath.add(snapshot(root));
        }
        synchronized (this) {
            classpath.addAll(nestedLibraries());
            classpath.addAll(manifestLibraries);
            classpath.addAll(userLibraries);
        }
        return classpath;
    }

    /** A JAR with the original classes of {@code root}, laid out by package so javac can read them. */
    private synchronized Path snapshot(String root) throws IOException {
        Path jar = snapshots.get(root);
        if (jar == null) {
            jar = workDir.resolve("classes-" + snapshots.size() + ".jar");
            try (ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(jar)))) {
                out.setLevel(Deflater.NO_COMPRESSION);
                for (Map.Entry<String, byte[]> originalClass : model.originalClasses(root).entrySet()) {
                    out.putNextEntry(new ZipEntry(originalClass.getKey() + ".class"));
                    out.write(originalClass.getValue());
                    out.closeEntry();
                }
            }
            snapshots.put(root, jar);
        }
        return jar;
    }

    /** JARs nested in the archive (Spring Boot, WAR, ...), extracted once so they can be put on the classpath. */
    private synchronized List<Path> nestedLibraries() throws IOException {
        if (nestedLibraries == null) {
            List<Path> extracted = new ArrayList<>();
            List<String> names = model.nestedJars();
            for (int i = 0; i < names.size(); i++) {
                String name = names.get(i);
                byte[] data = model.entryData(name);
                if (data == null) {
                    continue;
                }
                Path file = workDir.resolve("nested").resolve(i + "-" + name.substring(name.lastIndexOf('/') + 1));
                Files.createDirectories(file.getParent());
                Files.write(file, data);
                extracted.add(file);
            }
            nestedLibraries = extracted;
        }
        return nestedLibraries;
    }

    private synchronized void closeLibraries() {
        if (libraries != null) {
            libraries.close();
            libraries = null;
        }
    }

    private static List<Path> resolveManifestClassPath(JarModel model) {
        Path dir = model.source().getParent();
        List<Path> resolved = new ArrayList<>();
        for (String item : model.manifestClassPath()) {
            try {
                Path path = Path.of(dir.toUri().resolve(item));
                if (Files.exists(path)) {
                    resolved.add(path);
                }
            } catch (IllegalArgumentException | FileSystemNotFoundException ignored) {
                // not a usable local path
            }
        }
        return List.copyOf(resolved);
    }
}
