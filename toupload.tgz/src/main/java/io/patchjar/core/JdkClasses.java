package io.patchjar.core;

import java.io.IOException;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

/** Reads class files of the running JDK from the {@code jrt:/} file system. */
public final class JdkClasses implements ClassLookup {

    public static final JdkClasses INSTANCE = new JdkClasses();

    private final FileSystem jrt;
    private final Map<String, List<String>> modulesByPackage = new ConcurrentHashMap<>();

    private JdkClasses() {
        FileSystem fs;
        try {
            fs = FileSystems.getFileSystem(URI.create("jrt:/"));
        } catch (RuntimeException e) {
            fs = null;
        }
        jrt = fs;
    }

    @Override
    public byte[] find(String internalName) {
        int slash = internalName.lastIndexOf('/');
        if (jrt == null || slash < 0) {
            return null;
        }
        String pkg = internalName.substring(0, slash).replace('/', '.');
        for (String module : modulesByPackage.computeIfAbsent(pkg, this::modulesOf)) {
            Path file = jrt.getPath("/modules", module, internalName + ".class");
            try {
                if (Files.isRegularFile(file)) {
                    return Files.readAllBytes(file);
                }
            } catch (IOException ignored) {
                // fall through to the next module
            }
        }
        return null;
    }

    private List<String> modulesOf(String pkg) {
        Path dir = jrt.getPath("/packages", pkg);
        if (!Files.isDirectory(dir)) {
            return List.of();
        }
        try (Stream<Path> modules = Files.list(dir)) {
            return modules.map(p -> p.getFileName().toString()).toList();
        } catch (IOException e) {
            return List.of();
        }
    }
}
