package io.patchjar.core;

/**
 * Identifies a top-level class inside a JAR.
 *
 * @param root the class root the class lives in: {@code ""} for the JAR root, {@code "BOOT-INF/classes/"}
 *             for a Spring Boot fat jar, {@code "WEB-INF/classes/"} for a WAR, ...
 * @param name the internal name of the class, e.g. {@code com/acme/Foo}
 */
public record ClassRef(String root, String name) {

    public String entryName() {
        return root + name + ".class";
    }

    public String simpleName() {
        return name.substring(name.lastIndexOf('/') + 1);
    }

    /** Dotted package name, empty for the default package. */
    public String packageName() {
        int slash = name.lastIndexOf('/');
        return slash < 0 ? "" : name.substring(0, slash).replace('/', '.');
    }

    public String qualifiedName() {
        return name.replace('/', '.');
    }

    @Override
    public String toString() {
        return root.isEmpty() ? qualifiedName() : qualifiedName() + " [" + root + "]";
    }
}
