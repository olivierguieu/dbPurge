package io.patchjar.core;

import java.nio.file.Path;
import java.util.List;

/**
 * @param strippedSignatureFiles signature files dropped because the JAR was signed and patched
 * @param backup                 copy of the original JAR made before overwriting it, or null
 */
public record SaveReport(Path target, int entries, List<String> strippedSignatureFiles, Path backup) {

    SaveReport withBackup(Path backup) {
        return new SaveReport(target, entries, strippedSignatureFiles, backup);
    }
}
