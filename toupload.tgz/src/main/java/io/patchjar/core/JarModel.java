package io.patchjar.core;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.jar.Attributes;
import java.util.jar.Manifest;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * In-memory copy of a JAR. Every entry keeps its original bytes next to its current bytes, so patches can be
 * reverted and the archive written back with its original entry order, timestamps and compression methods.
 * <p>
 * Classes are indexed per class root (see {@link ClassRef#root()}) and grouped into <em>families</em>: a
 * top-level class together with all of its member, local and anonymous classes, which are always decompiled,
 * recompiled and replaced together.
 */
public final class JarModel {

    public static final String MANIFEST = "META-INF/MANIFEST.MF";

    private static final Comparator<String> ROOT_ORDER =
            Comparator.comparing((String prefix) -> !prefix.isEmpty()).thenComparing(Comparator.naturalOrder());

    private final Path source;
    private final String comment;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Map<String, Root> roots = new TreeMap<>(ROOT_ORDER);
    private long generation;

    private JarModel(Path source, String comment) {
        this.source = source;
        this.comment = comment;
    }

    public static JarModel load(Path file) throws IOException {
        JarModel model;
        try (ZipFile zip = new ZipFile(file.toFile())) {
            model = new JarModel(file.toAbsolutePath(), zip.getComment());
            Enumeration<? extends ZipEntry> zipEntries = zip.entries();
            while (zipEntries.hasMoreElements()) {
                ZipEntry zipEntry = zipEntries.nextElement();
                if (model.entries.containsKey(zipEntry.getName())) {
                    continue;
                }
                byte[] data;
                if (zipEntry.isDirectory()) {
                    data = new byte[0];
                } else {
                    try (InputStream in = zip.getInputStream(zipEntry)) {
                        data = in.readAllBytes();
                    }
                }
                model.entries.put(zipEntry.getName(),
                        new Entry(zipEntry.getName(), data, data, zipEntry.getTime(), zipEntry.getMethod()));
            }
        }
        model.indexClasses();
        return model;
    }

    private void indexClasses() {
        for (Entry entry : entries.values()) {
            if (!entry.name.endsWith(".class") || entry.data == null) {
                continue;
            }
            ClassInfo info = parse(entry.data);
            if (info == null || isSpecial(info.name())) {
                continue;
            }
            String suffix = info.name() + ".class";
            String prefix;
            if (entry.name.equals(suffix)) {
                prefix = "";
            } else if (entry.name.endsWith("/" + suffix)) {
                prefix = entry.name.substring(0, entry.name.length() - suffix.length());
            } else {
                continue; // stored under a path that does not match its class name
            }
            roots.computeIfAbsent(prefix, Root::new).classes.put(info.name(), info);
        }
        for (Root root : roots.values()) {
            root.rebuildFamilies();
            root.originalFamilies = root.families;
            root.originalNames = Set.copyOf(root.classes.keySet());
        }
    }

    public Path source() {
        return source;
    }

    /** Incremented on every patch or revert. */
    public synchronized long generation() {
        return generation;
    }

    /** Class roots in display order, the JAR root first. */
    public synchronized List<String> roots() {
        return List.copyOf(roots.keySet());
    }

    public synchronized List<ClassInfo> topLevelClasses(String root) {
        Root r = roots.get(root);
        if (r == null) {
            return List.of();
        }
        return r.families.keySet().stream()
                .map(r.classes::get)
                .filter(Objects::nonNull)
                .sorted(Comparator.comparing(ClassInfo::name))
                .toList();
    }

    /** Number of top-level classes over all roots. */
    public synchronized int classCount() {
        return roots.values().stream().mapToInt(r -> r.families.size()).sum();
    }

    public synchronized ClassInfo classInfo(ClassRef ref) {
        Root root = roots.get(ref.root());
        return root == null ? null : root.classes.get(ref.name());
    }

    /** The class and its nested classes as they are now, top-level class first. */
    public synchronized List<String> family(ClassRef ref) {
        Root root = roots.get(ref.root());
        List<String> family = root == null ? null : root.families.get(ref.name());
        return family == null ? List.of(ref.name()) : family;
    }

    /** The class and its nested classes as they were when the JAR was opened. */
    public synchronized List<String> originalFamily(ClassRef ref) {
        Root root = roots.get(ref.root());
        List<String> family = root == null ? null : root.originalFamilies.get(ref.name());
        return family == null ? List.of() : family;
    }

    public synchronized byte[] classBytes(String root, String name) {
        Entry entry = entries.get(root + name + ".class");
        return entry == null ? null : entry.data;
    }

    public synchronized byte[] originalClassBytes(String root, String name) {
        Entry entry = entries.get(root + name + ".class");
        return entry == null ? null : entry.original;
    }

    /** Resolves classes against the current JAR content, searching {@code preferredRoot} first. */
    public ClassLookup lookup(String preferredRoot) {
        return name -> {
            synchronized (JarModel.this) {
                byte[] bytes = classBytes(preferredRoot, name);
                if (bytes != null) {
                    return bytes;
                }
                for (String root : roots.keySet()) {
                    if (!root.equals(preferredRoot) && (bytes = classBytes(root, name)) != null) {
                        return bytes;
                    }
                }
                return null;
            }
        };
    }

    /**
     * Replaces the family of {@code ref} with freshly compiled classes. Classes of the old family that the
     * compiler did not produce anymore (e.g. a removed anonymous class) are deleted.
     *
     * @param classes compiled classes by internal name
     */
    public synchronized PatchSummary applyPatch(ClassRef ref, Map<String, byte[]> classes) {
        Root root = roots.computeIfAbsent(ref.root(), Root::new);
        List<String> previous = root.families.getOrDefault(ref.name(), List.of());
        List<String> replaced = new ArrayList<>();
        List<String> added = new ArrayList<>();
        List<String> removed = new ArrayList<>();

        for (Map.Entry<String, byte[]> compiled : classes.entrySet()) {
            String entryName = ref.root() + compiled.getKey() + ".class";
            Entry entry = entries.get(entryName);
            if (entry == null) {
                entries.put(entryName, new Entry(entryName, null, compiled.getValue(), -1, ZipEntry.DEFLATED));
                added.add(compiled.getKey());
            } else {
                (entry.data == null ? added : replaced).add(compiled.getKey());
                entry.data = compiled.getValue();
            }
            root.classes.put(compiled.getKey(), ClassInfo.read(compiled.getValue()));
        }
        for (String name : previous) {
            if (classes.containsKey(name)) {
                continue;
            }
            String entryName = ref.root() + name + ".class";
            Entry entry = entries.get(entryName);
            if (entry != null && entry.data != null) {
                if (entry.original == null) {
                    entries.remove(entryName);
                } else {
                    entry.data = null;
                }
                removed.add(name);
            }
            root.classes.remove(name);
        }
        root.rebuildFamilies();
        generation++;
        return new PatchSummary(replaced, added, removed);
    }

    /** Restores the original bytes of the family of {@code ref}, dropping classes that patches added. */
    public synchronized void revert(ClassRef ref) {
        Root root = roots.get(ref.root());
        if (root == null) {
            return;
        }
        for (String name : familyUnion(root, ref.name())) {
            String entryName = ref.root() + name + ".class";
            Entry entry = entries.get(entryName);
            if (entry == null) {
                continue;
            }
            if (entry.original == null) {
                entries.remove(entryName);
                root.classes.remove(name);
            } else {
                entry.data = entry.original;
                ClassInfo info = parse(entry.original);
                if (info != null) {
                    root.classes.put(name, info);
                }
            }
        }
        root.rebuildFamilies();
        generation++;
    }

    public synchronized boolean isPatched(ClassRef ref) {
        Root root = roots.get(ref.root());
        if (root == null) {
            return false;
        }
        for (String name : familyUnion(root, ref.name())) {
            Entry entry = entries.get(ref.root() + name + ".class");
            if (entry != null && entry.isModified()) {
                return true;
            }
        }
        return false;
    }

    public synchronized List<ClassRef> patchedClasses() {
        List<ClassRef> patched = new ArrayList<>();
        for (Root root : roots.values()) {
            Set<String> topLevel = new TreeSet<>(root.families.keySet());
            topLevel.addAll(root.originalFamilies.keySet());
            for (String name : topLevel) {
                ClassRef ref = new ClassRef(root.prefix, name);
                if (isPatched(ref)) {
                    patched.add(ref);
                }
            }
        }
        return patched;
    }

    public synchronized boolean hasChanges() {
        return entries.values().stream().anyMatch(Entry::isModified);
    }

    /** Current bytes of every class of {@code root} that differs from the original JAR. */
    public synchronized Map<String, byte[]> modifiedClasses(String root) {
        Map<String, byte[]> modified = new TreeMap<>();
        Root r = roots.get(root);
        if (r != null) {
            for (String name : r.classes.keySet()) {
                Entry entry = entries.get(root + name + ".class");
                if (entry != null && entry.data != null && entry.isModified()) {
                    modified.put(name, entry.data);
                }
            }
        }
        return modified;
    }

    /** Original bytes of every class of {@code root}, as they were when the JAR was opened. */
    public synchronized Map<String, byte[]> originalClasses(String root) {
        Map<String, byte[]> original = new TreeMap<>();
        Root r = roots.get(root);
        if (r != null) {
            for (String name : r.originalNames) {
                Entry entry = entries.get(root + name + ".class");
                if (entry != null && entry.original != null) {
                    original.put(name, entry.original);
                }
            }
        }
        return original;
    }

    public synchronized boolean isSigned() {
        return entries.values().stream().anyMatch(e -> e.data != null && isSignatureFile(e.name));
    }

    /** Names of the JARs nested inside this archive (e.g. {@code BOOT-INF/lib/*.jar}, {@code WEB-INF/lib/*.jar}). */
    public synchronized List<String> nestedJars() {
        return entries.values().stream()
                .filter(e -> e.data != null && e.name.toLowerCase(Locale.ROOT).endsWith(".jar"))
                .map(e -> e.name)
                .toList();
    }

    public synchronized byte[] entryData(String name) {
        Entry entry = entries.get(name);
        return entry == null ? null : entry.data;
    }

    /** The raw items of the manifest's {@code Class-Path} attribute (relative URLs). */
    public synchronized List<String> manifestClassPath() {
        Entry entry = entries.get(MANIFEST);
        if (entry == null || entry.data == null) {
            return List.of();
        }
        try {
            String classPath = new Manifest(new ByteArrayInputStream(entry.data))
                    .getMainAttributes().getValue(Attributes.Name.CLASS_PATH);
            return classPath == null || classPath.isBlank() ? List.of() : List.of(classPath.trim().split("\\s+"));
        } catch (IOException e) {
            return List.of();
        }
    }

    /**
     * Writes the current content to {@code target} (atomically when possible). When the JAR is signed and has
     * been patched, the signature files and manifest digests are removed, since they would no longer verify.
     */
    public SaveReport save(Path target) throws IOException {
        boolean stripSignatures;
        List<Entry> snapshot = new ArrayList<>();
        synchronized (this) { // write outside the lock: readers are not blocked while a large JAR is written
            stripSignatures = hasChanges() && isSigned();
            for (Entry entry : entries.values()) {
                snapshot.add(new Entry(entry.name, entry.original, entry.data, entry.time, entry.method));
            }
        }
        Path destination = target.toAbsolutePath();
        Path temp = destination.resolveSibling("." + destination.getFileName() + "." + ProcessHandle.current().pid() + ".tmp");
        List<String> stripped = new ArrayList<>();
        int written = 0;
        try {
            Files.deleteIfExists(temp);
            try (OutputStream file = Files.newOutputStream(temp, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
                 ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(file))) {
                if (comment != null) {
                    out.setComment(comment);
                }
                long now = System.currentTimeMillis();
                for (Entry entry : snapshot) {
                    if (entry.data == null) {
                        continue;
                    }
                    byte[] data = entry.data;
                    if (stripSignatures && isSignatureFile(entry.name)) {
                        stripped.add(entry.name);
                        continue;
                    }
                    if (stripSignatures && entry.name.equals(MANIFEST)) {
                        data = stripDigests(data);
                    }
                    ZipEntry zipEntry = new ZipEntry(entry.name);
                    long time = entry.isModified() ? now : entry.time;
                    if (time != -1) {
                        zipEntry.setTime(time);
                    }
                    if (entry.method == ZipEntry.STORED) {
                        // e.g. nested jars of Spring Boot fat jars must stay uncompressed
                        CRC32 crc = new CRC32();
                        crc.update(data);
                        zipEntry.setMethod(ZipEntry.STORED);
                        zipEntry.setSize(data.length);
                        zipEntry.setCompressedSize(data.length);
                        zipEntry.setCrc(crc.getValue());
                    } else {
                        zipEntry.setMethod(ZipEntry.DEFLATED);
                    }
                    out.putNextEntry(zipEntry);
                    out.write(data);
                    out.closeEntry();
                    written++;
                }
            }
            if (Files.exists(destination)) {
                try {
                    Files.setPosixFilePermissions(temp, Files.getPosixFilePermissions(destination));
                } catch (UnsupportedOperationException | IOException ignored) {
                    // not a POSIX file system
                }
            }
            try {
                Files.move(temp, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, destination, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException | RuntimeException e) {
            Files.deleteIfExists(temp);
            throw e;
        }
        return new SaveReport(destination, written, stripped, null);
    }

    static boolean isSignatureFile(String name) {
        String upper = name.toUpperCase(Locale.ROOT);
        if (!upper.startsWith("META-INF/") || upper.indexOf('/', "META-INF/".length()) >= 0) {
            return false;
        }
        return upper.endsWith(".SF") || upper.endsWith(".RSA") || upper.endsWith(".DSA")
                || upper.endsWith(".EC") || upper.startsWith("META-INF/SIG-");
    }

    private static byte[] stripDigests(byte[] manifestBytes) throws IOException {
        Manifest manifest = new Manifest(new ByteArrayInputStream(manifestBytes));
        boolean changed = false;
        Iterator<Map.Entry<String, Attributes>> sections = manifest.getEntries().entrySet().iterator();
        while (sections.hasNext()) {
            Attributes attributes = sections.next().getValue();
            changed |= attributes.keySet().removeIf(key -> key.toString().toUpperCase(Locale.ROOT).endsWith("-DIGEST"));
            if (attributes.isEmpty()) {
                sections.remove();
            }
        }
        if (!changed) {
            return manifestBytes;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        manifest.write(out);
        return out.toByteArray();
    }

    private static Set<String> familyUnion(Root root, String topLevel) {
        Set<String> names = new LinkedHashSet<>();
        names.add(topLevel);
        names.addAll(root.families.getOrDefault(topLevel, List.of()));
        names.addAll(root.originalFamilies.getOrDefault(topLevel, List.of()));
        return names;
    }

    private static ClassInfo parse(byte[] bytes) {
        try {
            return ClassInfo.read(bytes);
        } catch (RuntimeException e) {
            return null; // corrupt or unsupported class file: kept as a plain resource
        }
    }

    private static boolean isSpecial(String name) {
        return name.equals("module-info") || name.equals("package-info") || name.endsWith("/package-info");
    }

    private static final class Entry {
        final String name;
        final byte[] original; // null when the entry was added by a patch
        final long time;
        final int method;
        byte[] data;           // null when the entry was removed by a patch

        Entry(String name, byte[] original, byte[] data, long time, int method) {
            this.name = name;
            this.original = original;
            this.data = data;
            this.time = time;
            this.method = method;
        }

        boolean isModified() {
            return data != original;
        }
    }

    private static final class Root {
        final String prefix;
        final Map<String, ClassInfo> classes = new HashMap<>();
        Map<String, List<String>> families = Map.of();
        Map<String, List<String>> originalFamilies = Map.of();
        Set<String> originalNames = Set.of();

        Root(String prefix) {
            this.prefix = prefix;
        }

        void rebuildFamilies() {
            Map<String, String> topLevelOf = new HashMap<>();
            for (String name : classes.keySet()) {
                resolveTopLevel(name, topLevelOf);
            }
            Map<String, List<String>> grouped = new HashMap<>();
            topLevelOf.forEach((name, top) -> grouped.computeIfAbsent(top, k -> new ArrayList<>()).add(name));
            grouped.forEach((top, members) -> members.sort(
                    Comparator.comparing((String member) -> !member.equals(top)).thenComparing(Comparator.naturalOrder())));
            families = grouped;
        }

        private String resolveTopLevel(String name, Map<String, String> memo) {
            List<String> chain = new ArrayList<>();
            String current = name;
            String top = null;
            while (top == null) {
                String known = memo.get(current);
                if (known != null) {
                    top = known;
                    break;
                }
                chain.add(current);
                String parent = classes.get(current).parent();
                if (parent == null || !classes.containsKey(parent) || chain.contains(parent)) {
                    top = current; // top-level, orphaned nested class, or cyclic metadata
                } else {
                    current = parent;
                }
            }
            for (String member : chain) {
                memo.put(member, top);
            }
            return top;
        }
    }
}
