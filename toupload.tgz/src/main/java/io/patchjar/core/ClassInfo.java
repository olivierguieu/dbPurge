package io.patchjar.core;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.Opcodes;

/**
 * Header information of a class file, read without parsing method bodies.
 *
 * @param nestHost       the NestHost attribute (Java 11+ nest members), or null
 * @param enclosingClass the owner from the EnclosingMethod attribute (local and anonymous classes), or null
 * @param declaredOuter  the outer class declared by the class's own InnerClasses entry (member classes), or null
 * @param nested         whether the class describes itself as an inner class
 */
public record ClassInfo(String name, int access, String superName, int version,
                        String nestHost, String enclosingClass, String declaredOuter, boolean nested) {

    public enum Kind { CLASS, ABSTRACT_CLASS, INTERFACE, ENUM, ANNOTATION, RECORD }

    public static ClassInfo read(byte[] bytes) {
        HeaderReader reader = new HeaderReader();
        new ClassReader(bytes).accept(reader, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        return new ClassInfo(reader.name, reader.access, reader.superName, reader.version,
                reader.nestHost, reader.enclosingClass, reader.declaredOuter, reader.nested);
    }

    public int majorVersion() {
        return version & 0xFFFF;
    }

    public String simpleName() {
        return name.substring(name.lastIndexOf('/') + 1);
    }

    public Kind kind() {
        if ((access & Opcodes.ACC_ANNOTATION) != 0) return Kind.ANNOTATION;
        if ((access & Opcodes.ACC_INTERFACE) != 0) return Kind.INTERFACE;
        if ((access & Opcodes.ACC_ENUM) != 0) return Kind.ENUM;
        if ((access & Opcodes.ACC_RECORD) != 0 || "java/lang/Record".equals(superName)) return Kind.RECORD;
        if ((access & Opcodes.ACC_ABSTRACT) != 0) return Kind.ABSTRACT_CLASS;
        return Kind.CLASS;
    }

    /** The class this one is declared in, or null for a top-level class. */
    public String parent() {
        if (nestHost != null && !nestHost.equals(name)) return nestHost;
        if (declaredOuter != null) return declaredOuter;
        if (enclosingClass != null) return enclosingClass;
        if (nested) {
            int dollar = name.lastIndexOf('$');
            if (dollar > 0) return name.substring(0, dollar);
        }
        return null;
    }

    private static final class HeaderReader extends ClassVisitor {
        String name;
        String superName;
        String nestHost;
        String enclosingClass;
        String declaredOuter;
        int access;
        int version;
        boolean nested;

        HeaderReader() {
            super(Opcodes.ASM9);
        }

        @Override
        public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
            this.version = version;
            this.access = access;
            this.name = name;
            this.superName = superName;
        }

        @Override
        public void visitNestHost(String nestHost) {
            this.nestHost = nestHost;
        }

        @Override
        public void visitOuterClass(String owner, String name, String descriptor) {
            this.enclosingClass = owner;
        }

        @Override
        public void visitInnerClass(String name, String outerName, String innerName, int access) {
            if (name.equals(this.name)) {
                nested = true;
                declaredOuter = outerName;
            }
        }
    }
}
