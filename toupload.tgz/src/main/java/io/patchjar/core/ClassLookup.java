package io.patchjar.core;

/** Finds class files by internal name. Implementations return null instead of throwing when a class is missing. */
@FunctionalInterface
public interface ClassLookup {

    byte[] find(String internalName);

    default ClassLookup or(ClassLookup next) {
        return name -> {
            byte[] bytes = find(name);
            return bytes != null ? bytes : next.find(name);
        };
    }
}
