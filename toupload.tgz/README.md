# PatchJar

A JavaFX desktop tool that patches the bytecode of a JAR by editing Java source: open a JAR, decompile a
class, edit the Java code, **Compile & Patch**, and save. The class files inside the archive are replaced
with freshly compiled ones — no need to unpack, rebuild or repackage anything by hand.

## Features

- Opens JAR, WAR, EAR and ZIP files, including Spring Boot fat JARs (`BOOT-INF/classes`), WARs
  (`WEB-INF/classes`) and multi-release JARs.
- Decompiles with **Vineflower** (default) or **CFR**; switch in the toolbar if one produces code that does not compile.
- Java editor with syntax highlighting, line numbers, find (⌘F / Ctrl+F), go to line, auto-indent.
- **Compile & Patch** (⌘B / Ctrl+B) compiles the class in-process with `javac`:
  - against the JAR itself (including classes you already patched), its nested JARs (`BOOT-INF/lib`, `WEB-INF/lib`),
    its manifest `Class-Path`, and extra libraries you add;
  - for the Java version of the original class file (`--release`), so the patched JAR runs where it ran before.
- Replaces the class **and** its nested, local and anonymous classes; class files the new code no longer
  produces (e.g. a removed anonymous class) are deleted.
- Compile errors are listed under *Problems*, underlined in the editor and marked in the gutter; the JAR is only
  changed when compilation succeeds.
- *Bytecode* view (ASM) of the class as currently patched, or as in the original JAR.
- Patched classes are highlighted in the tree; any class can be reverted to its original bytecode.
- Saving keeps entry order, timestamps and compression methods (Spring Boot needs `BOOT-INF/lib/*.jar` stored
  uncompressed), removes the signature of signed JARs (it would no longer verify), and keeps a `.bak` copy when you
  overwrite the JAR you opened.
- Light and dark themes.

## Requirements

- **JDK 21 or newer** — a JDK, not a JRE: PatchJar uses `javac` at runtime.
- Maven 3.9+ to build.

## Build and run

```bash
mvn javafx:run                                  # run from source
mvn package                                     # build + tests -> target/patchjar-1.0.0-all.jar
java -jar target/patchjar-1.0.0-all.jar [app.jar]
```

The `-all` JAR bundles the JavaFX native libraries of the platform it was built on; build it on each OS you
want to run it on. (JavaFX prints an "Unsupported JavaFX configuration" warning when run with `java -jar`: it is harmless.)

## Patching a JAR

1. **Open** a JAR (⌘O / Ctrl+O, or drop it on the window).
2. **Double-click** a class in the tree (⌘P / Ctrl+P filters classes). It is decompiled into the editor.
3. **Edit** the source, then **Compile & Patch** (⌘B / Ctrl+B). Fix any reported errors and compile again.
4. **Save** the patched JAR (⌘S / Ctrl+S; ⌘⇧S / Ctrl+Shift+S to choose another file).

| Action | macOS | Windows / Linux |
|---|---|---|
| Open JAR | ⌘O | Ctrl+O |
| Save / Save As | ⌘S / ⌘⇧S | Ctrl+S / Ctrl+Shift+S |
| Compile & Patch | ⌘B | Ctrl+B |
| Decompile again | ⌘⇧D | Ctrl+Shift+D |
| Find / next / previous | ⌘F / ⌘G / ⌘⇧G | Ctrl+F / F3 / Shift+F3 |
| Go to line | ⌘L | Ctrl+L |
| Go to class | ⌘P | Ctrl+P |
| Close tab | ⌘W | Ctrl+W |

Settings (persisted): decompiler and target Java version (toolbar), *Settings > Classpath Libraries*
(dependencies the JAR needs to compile against), *Settings > Compiler Options* (`--release` on/off, extra javac
options such as `-parameters` or `--add-exports ...`), dark theme.

## How it works

1. The JAR is loaded in memory. Each entry keeps its original and current bytes, so any change can be reverted
   and nothing is written until you save.
2. Classes are indexed per *class root* (`""`, `BOOT-INF/classes/`, ...) and grouped by top-level class using the
   `NestHost`, `InnerClasses` and `EnclosingMethod` attributes.
3. The decompiler reads classes from memory, falling back to the libraries and to the running JDK (`jrt:/`).
4. `javac` (`javax.tools`) compiles the edited unit with `-g -proc:none` and `--release N`, where `N` is the Java
   version of the original class file (clamped to what the running JDK supports).
5. The compiled classes replace the class family in the in-memory JAR; saving writes a new archive atomically.

## Limitations and tips

- Decompiled code does not always recompile as-is (generic inference, unusual control flow, synthetic members).
  The whole class is recompiled, so errors in methods you did not touch must be fixed too. Try the other
  decompiler first. On sample libraries, the share of classes whose Vineflower output recompiles unmodified
  ranged from 83% (gson, generics-heavy) to 95% (commons-lang3) and 100% (slf4j); CFR recompiles fewer classes,
  but fails on different ones.
- Obfuscated classes (names that are not valid Java identifiers) generally cannot be recompiled.
- Classes compiled for Java 7 or older are recompiled for Java 8, the oldest release current JDKs support.
  Classes newer than the running JDK require running PatchJar on a newer JDK.
- A `Serializable` class without an explicit `serialVersionUID` may get a different computed UID once recompiled.
- If a type cannot be found, add the missing dependency under *Settings > Classpath Libraries*.

## Project layout

```
src/main/java/io/patchjar/
  PatchJarApp, Launcher     JavaFX application and runnable-JAR entry point
  core/                     JarModel (in-memory JAR), PatchSession (decompile/compile/patch/save), class lookups
  decompiler/               CFR and Vineflower adapters
  compiler/                 javac wrapper
  ui/                       JavaFX user interface
src/test/java/io/patchjar/core/
  PatchSessionTest          end-to-end tests: decompile, edit, compile, save and run patched JARs
```
