# Jira FX Tool

A small **Java 1.8 + JavaFX 8** desktop application that extracts and presents
information from a **Jira Server / Data Center** instance.

The first report is **sum of estimates per person for a chosen sprint**, with a
second tab showing the raw issues that back the totals.

## Features

- Connect to Jira Server/DC with a **Personal Access Token** (Bearer) or
  **username/password** (HTTP Basic).
- Browse **boards** → **sprints** via the Jira Agile REST API.
- Aggregate the configured **estimate field** per assignee (story points custom
  field, or `timeoriginalestimate` for time in seconds).
- Sortable summary table + grand total, plus a raw issues table.
- Remembers your base URL / username / settings between runs (**secrets are
  never written to disk**).

## Requirements

- **Any JDK 8** to build — it does **not** need to bundle JavaFX.
- **Maven 3.x**.
- A **JavaFX 8 runtime** to *run* the app (see below).

JavaFX 8 was never published to Maven Central in a Java-8-compatible form (the
`org.openjfx` artifacts start at version 11 and are built for Java 11 bytecode,
so a JDK 8 can neither compile against nor run them). JavaFX 8 only ever shipped
*inside* a JDK. So `jfxrt.jar` is consumed as a **`provided`** Maven dependency
that you install once from a JavaFX-bundled JDK 8, and that same JDK supplies the
native libraries at run time.

### One-time JavaFX 8 setup

Get a JavaFX-bundled JDK 8 — **Azul Zulu FX 8** or **BellSoft Liberica Full 8**
(both free) — unpack it anywhere, and install its `jfxrt.jar` into your local
Maven repo:

```bash
# Path to the JavaFX-bundled JDK 8 you unpacked (macOS aarch64 example):
FX_JDK_HOME="$HOME/.local/opt/zulu-fx-8/Contents/Home"

mvn install:install-file \
  -Dfile="$FX_JDK_HOME/jre/lib/ext/jfxrt.jar" \
  -DgroupId=com.azul.zulufx -DartifactId=javafx-rt \
  -Dversion=8.0.492 -Dpackaging=jar
```

The `groupId` / `artifactId` / `version` must match the JavaFX `<dependency>` in
`pom.xml`. (Download URLs: Azul `azul.com/downloads` → Java 8 → "JavaFX"
bundles; BellSoft `bell-sw.com` → Liberica "Full".)

## Build

Any JDK 8 works for the build (JavaFX is only needed at run time), once the
one-time setup above is done:

```bash
export JAVA_HOME="$(/usr/libexec/java_home -v 1.8)"
mvn clean package
```

This produces a runnable fat-jar at `target/jira-fx-tool.jar` (Jackson is
bundled; JavaFX is **not** — it is supplied by the JavaFX runtime at launch).

## Run

Launch with a JavaFX 8 runtime on the classpath. Simplest is to run with the
JavaFX-bundled JDK 8 from the setup step — it does **not** have to be your
default `java`:

```bash
FX_JDK_HOME="$HOME/.local/opt/zulu-fx-8/Contents/Home"
"$FX_JDK_HOME/bin/java" -jar target/jira-fx-tool.jar
```

Alternatively, run with your normal JDK 8 and point it at the JavaFX runtime
explicitly:

```bash
java \
  -Xbootclasspath/a:"$FX_JDK_HOME/jre/lib/ext/jfxrt.jar" \
  -Djava.library.path="$FX_JDK_HOME/jre/lib" \
  -jar target/jira-fx-tool.jar
```

Then in the UI:

1. Enter your Jira **base URL** (e.g. `https://jira.mycompany.com`).
2. Choose **auth method** and enter your token (or username + password).
3. Click **Connect**.
4. Pick a **Board**, then a **Sprint**.
5. Click **Load estimates**.

## Configuring the estimate field

The "Estimate field" box defaults to `customfield_10002`. The story-points field
id **varies per Jira instance**. To find yours:

- Open any issue in a browser and append `?expand=names` to the REST call:
  `https://<jira>/rest/api/2/issue/<KEY>?expand=names` and look for "Story
  Points" in the `names` block, or
- ask your Jira admin.

Set the box to `timeoriginalestimate` to instead sum original time estimates
(returned in **seconds**).

## Project layout

```
pom.xml
src/main/java/com/jiratool/
  Main.java            JavaFX application + UI + aggregation
  JiraClient.java      REST client (Agile API, HttpURLConnection + Jackson)
  Board.java           model
  Sprint.java          model
  Issue.java           model
  PersonEstimate.java  per-assignee aggregate
```

## Extending

`JiraClient` is the single place that talks to Jira. To add another report
(e.g. estimates per status, or velocity across sprints), add a method there and
a tab in `Main.buildResults()`.
