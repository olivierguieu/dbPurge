package com.jiratool;

/** A Jira Agile sprint. */
public class Sprint {
    private final long id;
    private final String name;
    private final String state;

    public Sprint(long id, String name, String state) {
        this.id = id;
        this.name = name;
        this.state = state;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getState() {
        return state;
    }

    @Override
    public String toString() {
        return name + " [" + state + "]";
    }
}
