package com.jiratool;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Tooltip;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * JavaFX 8 desktop application that extracts and presents information from a
 * Jira Server / Data Center instance.
 *
 * Current report: sum of estimates per assignee for a chosen sprint, plus the
 * raw issue list backing the totals.
 */
public class Main extends Application {

    private static final DecimalFormat FMT = new DecimalFormat("#0.##");
    private static final File CONFIG_FILE =
            new File(System.getProperty("user.home"), ".jira-fx-tool.properties");

    // --- connection inputs ---
    private TextField baseUrlField;
    private RadioButton tokenAuthRadio;
    private RadioButton basicAuthRadio;
    private TextField usernameField;
    private PasswordField secretField;   // PAT or password depending on auth mode
    private Label secretLabel;
    private TextField estimateFieldField;
    private Button connectBtn;

    // --- selection inputs ---
    private ComboBox<Board> boardCombo;
    private ComboBox<Sprint> sprintCombo;
    private Button loadIssuesBtn;

    // --- output ---
    private TableView<PersonEstimate> summaryTable;
    private TableView<Issue> issuesTable;
    private Label totalLabel;
    private Label statusLabel;
    private ProgressIndicator progress;

    private JiraClient client;

    @Override
    public void start(Stage stage) {
        BorderPane root = new BorderPane();
        root.setTop(buildControls());
        root.setCenter(buildResults());
        root.setBottom(buildStatusBar());

        loadConfig();
        updateSecretLabel();

        Scene scene = new Scene(root, 1000, 700);
        stage.setTitle("Jira FX Tool — Estimates per Person");
        stage.setScene(scene);
        stage.show();
    }

    // ----------------------------------------------------------------- UI build

    private VBox buildControls() {
        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(8);
        grid.setPadding(new Insets(12));

        baseUrlField = new TextField();
        baseUrlField.setPromptText("https://jira.mycompany.com");
        baseUrlField.setPrefWidth(360);

        ToggleGroup authGroup = new ToggleGroup();
        tokenAuthRadio = new RadioButton("Personal Access Token");
        tokenAuthRadio.setToggleGroup(authGroup);
        tokenAuthRadio.setSelected(true);
        basicAuthRadio = new RadioButton("Username / Password");
        basicAuthRadio.setToggleGroup(authGroup);
        authGroup.selectedToggleProperty().addListener((o, a, b) -> updateSecretLabel());
        HBox authBox = new HBox(16, tokenAuthRadio, basicAuthRadio);
        authBox.setAlignment(Pos.CENTER_LEFT);

        usernameField = new TextField();
        usernameField.setPromptText("username (required for Basic auth)");

        secretLabel = new Label("Token:");
        secretField = new PasswordField();
        secretField.setPromptText("personal access token");

        estimateFieldField = new TextField("customfield_10002");
        estimateFieldField.setPromptText("estimate field id");
        Tooltip tip = new Tooltip(
                "Field id holding the estimate.\n"
                + "Story points are usually customfield_100xx (varies per instance).\n"
                + "Use 'timeoriginalestimate' to sum original time estimates (seconds).");
        estimateFieldField.setTooltip(tip);

        connectBtn = new Button("Connect");
        connectBtn.setDefaultButton(true);
        connectBtn.setOnAction(e -> doConnect());

        int r = 0;
        grid.add(new Label("Jira base URL:"), 0, r);
        grid.add(baseUrlField, 1, r, 3, 1);
        r++;
        grid.add(new Label("Auth method:"), 0, r);
        grid.add(authBox, 1, r, 3, 1);
        r++;
        grid.add(new Label("Username:"), 0, r);
        grid.add(usernameField, 1, r);
        grid.add(secretLabel, 2, r);
        grid.add(secretField, 3, r);
        r++;
        grid.add(new Label("Estimate field:"), 0, r);
        grid.add(estimateFieldField, 1, r);
        grid.add(connectBtn, 3, r);

        // --- board / sprint selection row ---
        boardCombo = new ComboBox<>();
        boardCombo.setPromptText("select a board");
        boardCombo.setPrefWidth(280);
        boardCombo.setDisable(true);
        boardCombo.setOnAction(e -> {
            Board b = boardCombo.getValue();
            if (b != null) {
                loadSprints(b.getId());
            }
        });

        sprintCombo = new ComboBox<>();
        sprintCombo.setPromptText("select a sprint");
        sprintCombo.setPrefWidth(280);
        sprintCombo.setDisable(true);

        loadIssuesBtn = new Button("Load estimates");
        loadIssuesBtn.setDisable(true);
        loadIssuesBtn.setOnAction(e -> loadIssues());

        HBox selectionBox = new HBox(8,
                new Label("Board:"), boardCombo,
                new Label("Sprint:"), sprintCombo,
                loadIssuesBtn);
        selectionBox.setAlignment(Pos.CENTER_LEFT);
        selectionBox.setPadding(new Insets(0, 12, 12, 12));

        VBox top = new VBox(grid, selectionBox);
        return top;
    }

    private TabPane buildResults() {
        // Summary table: estimates per person
        summaryTable = new TableView<>();
        TableColumn<PersonEstimate, String> cAssignee = new TableColumn<>("Assignee");
        cAssignee.setCellValueFactory(new PropertyValueFactory<>("assignee"));
        cAssignee.setPrefWidth(360);
        TableColumn<PersonEstimate, Number> cTotal = new TableColumn<>("Total estimate");
        cTotal.setCellValueFactory(c ->
                new javafx.beans.property.SimpleDoubleProperty(c.getValue().getTotalEstimate()));
        cTotal.setPrefWidth(160);
        TableColumn<PersonEstimate, Number> cCount = new TableColumn<>("Issues");
        cCount.setCellValueFactory(c ->
                new javafx.beans.property.SimpleIntegerProperty(c.getValue().getIssueCount()));
        cCount.setPrefWidth(100);
        summaryTable.getColumns().add(cAssignee);
        summaryTable.getColumns().add(cTotal);
        summaryTable.getColumns().add(cCount);
        summaryTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        totalLabel = new Label("No data loaded.");
        totalLabel.setPadding(new Insets(8, 0, 0, 0));
        VBox summaryBox = new VBox(summaryTable, totalLabel);
        summaryBox.setPadding(new Insets(12));
        VBox.setVgrow(summaryTable, Priority.ALWAYS);

        // Issues table: raw backing data
        issuesTable = new TableView<>();
        TableColumn<Issue, String> iKey = new TableColumn<>("Key");
        iKey.setCellValueFactory(new PropertyValueFactory<>("key"));
        iKey.setPrefWidth(110);
        TableColumn<Issue, String> iType = new TableColumn<>("Type");
        iType.setCellValueFactory(new PropertyValueFactory<>("issueType"));
        iType.setPrefWidth(90);
        TableColumn<Issue, String> iSummary = new TableColumn<>("Summary");
        iSummary.setCellValueFactory(new PropertyValueFactory<>("summary"));
        iSummary.setPrefWidth(420);
        TableColumn<Issue, String> iAssignee = new TableColumn<>("Assignee");
        iAssignee.setCellValueFactory(new PropertyValueFactory<>("assignee"));
        iAssignee.setPrefWidth(180);
        TableColumn<Issue, String> iStatus = new TableColumn<>("Status");
        iStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        iStatus.setPrefWidth(120);
        TableColumn<Issue, Number> iEst = new TableColumn<>("Estimate");
        iEst.setCellValueFactory(c ->
                new javafx.beans.property.SimpleDoubleProperty(c.getValue().getEstimate()));
        iEst.setPrefWidth(100);
        issuesTable.getColumns().add(iKey);
        issuesTable.getColumns().add(iType);
        issuesTable.getColumns().add(iSummary);
        issuesTable.getColumns().add(iAssignee);
        issuesTable.getColumns().add(iStatus);
        issuesTable.getColumns().add(iEst);

        Tab summaryTab = new Tab("Estimates per person", summaryBox);
        summaryTab.setClosable(false);
        Tab issuesTab = new Tab("Issues", issuesTable);
        issuesTab.setClosable(false);

        TabPane tabs = new TabPane(summaryTab, issuesTab);
        return tabs;
    }

    private HBox buildStatusBar() {
        statusLabel = new Label("Not connected.");
        progress = new ProgressIndicator();
        progress.setMaxSize(18, 18);
        progress.setVisible(false);
        HBox bar = new HBox(8, progress, statusLabel);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(6, 12, 6, 12));
        return bar;
    }

    private void updateSecretLabel() {
        boolean token = tokenAuthRadio.isSelected();
        secretLabel.setText(token ? "Token:" : "Password:");
        secretField.setPromptText(token ? "personal access token" : "password");
        usernameField.setDisable(token);
    }

    // ------------------------------------------------------------- actions

    private void doConnect() {
        String baseUrl = baseUrlField.getText().trim();
        if (baseUrl.isEmpty()) {
            setStatus("Please enter the Jira base URL.", true);
            return;
        }
        String secret = secretField.getText();
        if (secret == null || secret.isEmpty()) {
            setStatus("Please enter your " + (tokenAuthRadio.isSelected() ? "token." : "password."), true);
            return;
        }

        final JiraClient newClient;
        if (tokenAuthRadio.isSelected()) {
            newClient = JiraClient.withToken(baseUrl, secret);
        } else {
            String user = usernameField.getText().trim();
            if (user.isEmpty()) {
                setStatus("Username is required for Basic auth.", true);
                return;
            }
            newClient = JiraClient.withBasic(baseUrl, user, secret);
        }

        runAsync("Connecting…", () -> {
            String who = newClient.verify();
            List<Board> boards = newClient.getBoards();
            return new Object[]{who, boards};
        }, result -> {
            Object[] arr = (Object[]) result;
            String who = (String) arr[0];
            @SuppressWarnings("unchecked")
            List<Board> boards = (List<Board>) arr[1];
            client = newClient;
            boardCombo.setItems(FXCollections.observableArrayList(boards));
            boardCombo.setDisable(false);
            sprintCombo.getItems().clear();
            sprintCombo.setDisable(true);
            loadIssuesBtn.setDisable(true);
            saveConfig();
            setStatus("Connected as " + who + " — " + boards.size() + " board(s) found.", false);
        });
    }

    private void loadSprints(long boardId) {
        if (client == null) {
            return;
        }
        sprintCombo.getItems().clear();
        sprintCombo.setDisable(true);
        loadIssuesBtn.setDisable(true);
        runAsync("Loading sprints…", () -> client.getSprints(boardId), result -> {
            @SuppressWarnings("unchecked")
            List<Sprint> sprints = (List<Sprint>) result;
            sprintCombo.setItems(FXCollections.observableArrayList(sprints));
            sprintCombo.setDisable(sprints.isEmpty());
            loadIssuesBtn.setDisable(sprints.isEmpty());
            if (sprints.isEmpty()) {
                setStatus("No sprints on this board (is it a Scrum board?).", false);
            } else {
                setStatus(sprints.size() + " sprint(s) found.", false);
            }
        });
    }

    private void loadIssues() {
        if (client == null) {
            return;
        }
        final Sprint sprint = sprintCombo.getValue();
        if (sprint == null) {
            setStatus("Please select a sprint.", true);
            return;
        }
        final String estimateField = estimateFieldField.getText().trim();
        if (estimateField.isEmpty()) {
            setStatus("Please enter the estimate field id.", true);
            return;
        }

        runAsync("Loading issues for " + sprint.getName() + "…",
                () -> client.getSprintIssues(sprint.getId(), estimateField),
                result -> {
                    @SuppressWarnings("unchecked")
                    List<Issue> issues = (List<Issue>) result;
                    populateResults(issues);
                    setStatus("Loaded " + issues.size() + " issue(s) from " + sprint.getName() + ".", false);
                });
    }

    private void populateResults(List<Issue> issues) {
        issuesTable.setItems(FXCollections.observableArrayList(issues));

        // aggregate estimates per assignee (preserve first-seen order, then sort)
        Map<String, PersonEstimate> byPerson = new LinkedHashMap<>();
        double grandTotal = 0d;
        for (Issue issue : issues) {
            PersonEstimate pe = byPerson.get(issue.getAssignee());
            if (pe == null) {
                pe = new PersonEstimate(issue.getAssignee());
                byPerson.put(issue.getAssignee(), pe);
            }
            pe.add(issue.getEstimate());
            grandTotal += issue.getEstimate();
        }

        List<PersonEstimate> rows = new ArrayList<>(byPerson.values());
        rows.sort(Comparator.comparingDouble(PersonEstimate::getTotalEstimate).reversed());

        ObservableList<PersonEstimate> data = FXCollections.observableArrayList(rows);
        summaryTable.setItems(data);
        totalLabel.setText("Grand total: " + FMT.format(grandTotal)
                + "  •  " + issues.size() + " issue(s)  •  " + rows.size() + " assignee(s)");
    }

    // --------------------------------------------------------- async plumbing

    private interface Work {
        Object run() throws Exception;
    }

    private interface OnDone {
        void accept(Object result);
    }

    private void runAsync(String busyMessage, Work work, OnDone onDone) {
        setBusy(true, busyMessage);
        Task<Object> task = new Task<Object>() {
            @Override
            protected Object call() throws Exception {
                return work.run();
            }
        };
        task.setOnSucceeded(e -> {
            setBusy(false, null);
            onDone.accept(task.getValue());
        });
        task.setOnFailed(e -> {
            setBusy(false, null);
            Throwable ex = task.getException();
            setStatus("Error: " + (ex != null ? ex.getMessage() : "unknown"), true);
        });
        Thread t = new Thread(task, "jira-worker");
        t.setDaemon(true);
        t.start();
    }

    private void setBusy(boolean busy, String message) {
        Platform.runLater(() -> {
            progress.setVisible(busy);
            connectBtn.setDisable(busy);
            loadIssuesBtn.setDisable(busy || sprintCombo.getValue() == null);
            if (message != null) {
                statusLabel.setText(message);
            }
        });
    }

    private void setStatus(String message, boolean error) {
        Platform.runLater(() -> {
            statusLabel.setText(message);
            statusLabel.setStyle(error ? "-fx-text-fill: #b00020;" : "-fx-text-fill: -fx-text-base-color;");
        });
    }

    // ------------------------------------------------------------- config I/O

    private void loadConfig() {
        if (!CONFIG_FILE.exists()) {
            return;
        }
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(CONFIG_FILE)) {
            p.load(in);
        } catch (Exception ignored) {
            return;
        }
        baseUrlField.setText(p.getProperty("baseUrl", ""));
        usernameField.setText(p.getProperty("username", ""));
        estimateFieldField.setText(p.getProperty("estimateField", "customfield_10002"));
        if ("basic".equals(p.getProperty("authMode"))) {
            basicAuthRadio.setSelected(true);
        } else {
            tokenAuthRadio.setSelected(true);
        }
    }

    /** Persists non-secret settings only — the token/password is never written to disk. */
    private void saveConfig() {
        Properties p = new Properties();
        p.setProperty("baseUrl", baseUrlField.getText().trim());
        p.setProperty("username", usernameField.getText().trim());
        p.setProperty("estimateField", estimateFieldField.getText().trim());
        p.setProperty("authMode", tokenAuthRadio.isSelected() ? "token" : "basic");
        try (FileOutputStream out = new FileOutputStream(CONFIG_FILE)) {
            p.store(out, "Jira FX Tool settings (no secrets stored)");
        } catch (Exception ignored) {
            // non-fatal
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
