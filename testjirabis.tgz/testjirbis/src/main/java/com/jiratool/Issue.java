package com.jiratool;

/** A single Jira issue with the fields this tool cares about. */
public class Issue {
    private final String key;
    private final String summary;
    private final String assignee;
    private final String status;
    private final String issueType;
    private final double estimate;

    public Issue(String key, String summary, String assignee, String status,
                 String issueType, double estimate) {
        this.key = key;
        this.summary = summary;
        this.assignee = assignee;
        this.status = status;
        this.issueType = issueType;
        this.estimate = estimate;
    }

    public String getKey() {
        return key;
    }

    public String getSummary() {
        return summary;
    }

    public String getAssignee() {
        return assignee;
    }

    public String getStatus() {
        return status;
    }

    public String getIssueType() {
        return issueType;
    }

    public double getEstimate() {
        return estimate;
    }
}
