package com.jiratool;

/** Aggregated estimate total for a single assignee. */
public class PersonEstimate {
    private final String assignee;
    private double totalEstimate;
    private int issueCount;

    public PersonEstimate(String assignee) {
        this.assignee = assignee;
    }

    public void add(double estimate) {
        this.totalEstimate += estimate;
        this.issueCount++;
    }

    public String getAssignee() {
        return assignee;
    }

    public double getTotalEstimate() {
        return totalEstimate;
    }

    public int getIssueCount() {
        return issueCount;
    }
}
