package com.jiratool;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * Minimal Jira Server / Data Center REST client.
 *
 * Uses the Agile API (/rest/agile/1.0) for boards, sprints and sprint issues,
 * relying only on the JDK's HttpURLConnection plus Jackson for JSON.
 *
 * Authentication is either:
 *   - Bearer Personal Access Token (preferred on recent Server/DC), or
 *   - HTTP Basic with username + password.
 */
public class JiraClient {

    private final String baseUrl;
    private final String authHeader;
    private final ObjectMapper mapper = new ObjectMapper();

    private JiraClient(String baseUrl, String authHeader) {
        // strip trailing slash so we can concatenate paths safely
        this.baseUrl = baseUrl.endsWith("/")
                ? baseUrl.substring(0, baseUrl.length() - 1)
                : baseUrl;
        this.authHeader = authHeader;
    }

    /** Build a client authenticating with a Personal Access Token (Bearer). */
    public static JiraClient withToken(String baseUrl, String personalAccessToken) {
        return new JiraClient(baseUrl, "Bearer " + personalAccessToken.trim());
    }

    /** Build a client authenticating with username + password (HTTP Basic). */
    public static JiraClient withBasic(String baseUrl, String username, String password) {
        String creds = username + ":" + password;
        String encoded = Base64.getEncoder()
                .encodeToString(creds.getBytes(StandardCharsets.UTF_8));
        return new JiraClient(baseUrl, "Basic " + encoded);
    }

    private JsonNode get(String path) throws Exception {
        URL url = new URL(baseUrl + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", authHeader);
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);

            int code = conn.getResponseCode();
            boolean ok = code >= 200 && code < 300;
            InputStream is = ok ? conn.getInputStream() : conn.getErrorStream();

            StringBuilder sb = new StringBuilder();
            if (is != null) {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(is, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        sb.append(line);
                    }
                }
            }

            if (!ok) {
                throw new RuntimeException("HTTP " + code + " from " + path
                        + (sb.length() > 0 ? " : " + sb : ""));
            }
            return mapper.readTree(sb.toString());
        } finally {
            conn.disconnect();
        }
    }

    /** Quick connectivity / auth check; returns the current user's display name. */
    public String verify() throws Exception {
        JsonNode me = get("/rest/api/2/myself");
        String name = me.path("displayName").asText("");
        if (name.isEmpty()) {
            name = me.path("name").asText("(unknown)");
        }
        return name;
    }

    /** All boards visible to the user (paged). */
    public List<Board> getBoards() throws Exception {
        List<Board> boards = new ArrayList<>();
        int startAt = 0;
        while (true) {
            JsonNode root = get("/rest/agile/1.0/board?startAt=" + startAt + "&maxResults=50");
            JsonNode values = root.path("values");
            for (JsonNode v : values) {
                boards.add(new Board(
                        v.path("id").asLong(),
                        v.path("name").asText(),
                        v.path("type").asText()));
            }
            if (root.path("isLast").asBoolean(true) || values.size() == 0) {
                break;
            }
            startAt += values.size();
        }
        return boards;
    }

    /** All sprints on a board (paged). Scrum boards only. */
    public List<Sprint> getSprints(long boardId) throws Exception {
        List<Sprint> sprints = new ArrayList<>();
        int startAt = 0;
        while (true) {
            JsonNode root = get("/rest/agile/1.0/board/" + boardId
                    + "/sprint?startAt=" + startAt + "&maxResults=50");
            JsonNode values = root.path("values");
            for (JsonNode v : values) {
                sprints.add(new Sprint(
                        v.path("id").asLong(),
                        v.path("name").asText(),
                        v.path("state").asText()));
            }
            if (root.path("isLast").asBoolean(true) || values.size() == 0) {
                break;
            }
            startAt += values.size();
        }
        return sprints;
    }

    /**
     * All issues in a sprint (paged), reading the configured estimate field.
     *
     * @param estimateField the field id holding the estimate, e.g. a story-points
     *                      custom field ("customfield_10002") or "timeoriginalestimate".
     */
    public List<Issue> getSprintIssues(long sprintId, String estimateField) throws Exception {
        List<Issue> issues = new ArrayList<>();
        String fields = "assignee,summary,status,issuetype," + estimateField;
        String encodedFields = URLEncoder.encode(fields, "UTF-8");

        int startAt = 0;
        int total = Integer.MAX_VALUE;
        while (startAt < total) {
            JsonNode root = get("/rest/agile/1.0/sprint/" + sprintId
                    + "/issue?startAt=" + startAt + "&maxResults=50&fields=" + encodedFields);
            total = root.path("total").asInt(0);
            JsonNode arr = root.path("issues");
            if (arr.size() == 0) {
                break;
            }
            for (JsonNode v : arr) {
                JsonNode f = v.path("fields");

                String key = v.path("key").asText("");
                String summary = f.path("summary").asText("");

                JsonNode assigneeNode = f.path("assignee");
                String assignee = (assigneeNode.isMissingNode() || assigneeNode.isNull())
                        ? "Unassigned"
                        : assigneeNode.path("displayName").asText(
                                assigneeNode.path("name").asText("Unassigned"));

                String status = f.path("status").path("name").asText("");
                String issueType = f.path("issuetype").path("name").asText("");

                double estimate = 0d;
                JsonNode est = f.path(estimateField);
                if (est != null && est.isNumber()) {
                    estimate = est.asDouble();
                }

                issues.add(new Issue(key, summary, assignee, status, issueType, estimate));
            }
            startAt += arr.size();
        }
        return issues;
    }
}
