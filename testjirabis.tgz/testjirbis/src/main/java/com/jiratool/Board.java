package com.jiratool;

/** A Jira Agile board. */
public class Board {
    private final long id;
    private final String name;
    private final String type;

    public Board(long id, String name, String type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    @Override
    public String toString() {
        return name + " (#" + id + ", " + type + ")";
    }
}
