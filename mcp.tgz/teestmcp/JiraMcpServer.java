/*
 * JiraMcpServer.java - an MCP server for Jira: it lets the model search issues
 * with JQL, read, create and update them, comment on them, assign them and
 * move them through their workflow.
 *
 * It calls Jira's REST API (version 2, which both Jira Cloud and Jira Data
 * Center serve) and speaks MCP over stdio like McpServer.java, whose JSON and
 * JSON-RPC code it repeats so that each server stays a single file with no
 * dependencies beyond the JDK (Java 11 or newer).
 *
 * Settings come from the environment:
 *   JIRA_URL        your site, like https://your-domain.atlassian.net
 *                   (for a scoped API token: https://api.atlassian.com/ex/jira/<cloud id>)
 *   JIRA_EMAIL      Jira Cloud: the email address of your Atlassian account
 *   JIRA_API_TOKEN  Jira Cloud: an API token from
 *                   https://id.atlassian.com/manage-profile/security/api-tokens
 *                   Jira Data Center: a personal access token, with JIRA_EMAIL unset
 *
 *   Build:  make jira_mcp_server.jar   (or skip the build and run: java JiraMcpServer.java)
 *   Use:    claude mcp add jira -e JIRA_URL=... -e JIRA_EMAIL=... -e JIRA_API_TOKEN=... \
 *             -- java -jar /absolute/path/to/jira_mcp_server.jar
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public final class JiraMcpServer {
    private static final String SERVER_NAME = "jira-mcp";
    private static final String SERVER_VERSION = "0.1.0";
    private static final int MAX_DEPTH = 64; // deepest JSON nesting we accept

    /** MCP protocol revisions this server can speak, newest first. */
    private static final List<String> PROTOCOL_VERSIONS =
            List.of("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05");

    // JSON-RPC 2.0 error codes
    private static final int PARSE_ERROR = -32700;
    private static final int INVALID_REQUEST = -32600;
    private static final int METHOD_NOT_FOUND = -32601;
    private static final int INVALID_PARAMS = -32602;

    // ------------------------------------------------------------------------
    // JSON values
    // ------------------------------------------------------------------------
    // JSON maps onto plain Java: an object is a Map (members in document order),
    // an array a List, a string a String, true/false a Boolean, null is null and
    // a number is a JsonNumber. Replies are built from the same pieces.

    /** A JSON number, kept as the literal that was sent so an id is echoed back exactly. */
    private static final class JsonNumber {
        final String literal;

        JsonNumber(String literal) {
            this.literal = literal;
        }

        double value() {
            return Double.parseDouble(literal);
        }

        @Override
        public String toString() {
            return literal;
        }
    }

    /** An object with these members, in order: object("a", 1, "b", "x") is {"a":1,"b":"x"}. */
    private static Map<String, Object> object(Object... namesAndValues) {
        var members = new LinkedHashMap<String, Object>();
        for (int i = 0; i < namesAndValues.length; i += 2)
            members.put((String) namesAndValues[i], namesAndValues[i + 1]);
        return members;
    }

    /** v if it is an object, else an empty one: a missing or malformed object reads as {}. */
    private static Map<?, ?> asObject(Object v) {
        return v instanceof Map ? (Map<?, ?>) v : Map.of();
    }

    /** v written out as compact JSON. */
    private static String toJson(Object v) {
        if (v instanceof String) return quote((String) v);
        if (v instanceof List)
            return ((List<?>) v).stream().map(JiraMcpServer::toJson).collect(Collectors.joining(",", "[", "]"));
        if (v instanceof Map)
            return ((Map<?, ?>) v).entrySet().stream()
                    .map(member -> quote((String) member.getKey()) + ":" + toJson(member.getValue()))
                    .collect(Collectors.joining(",", "{", "}"));
        return String.valueOf(v); // null, a Boolean, an Integer or a JsonNumber
    }

    /** s as a quoted, escaped JSON string. */
    private static String quote(String s) {
        var out = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\')
                out.append('\\').append(c);
            else if (c == '\n')
                out.append("\\n");
            else if (c == '\r')
                out.append("\\r");
            else if (c == '\t')
                out.append("\\t");
            else if (c < 0x20)
                out.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
            else
                out.append(c);
        }
        return out.append('"').toString();
    }

    // ------------------------------------------------------------------------
    // Minimal JSON parser: turns one message into the values above
    // ------------------------------------------------------------------------

    private static final class JsonParser {
        private final String text;
        private int pos;   // current position in the text
        private int depth; // current array/object nesting

        private JsonParser(String text) {
            this.text = text;
        }

        /** Parses a whole JSON text; throws IllegalArgumentException if it is not valid JSON. */
        static Object parse(String text) {
            var parser = new JsonParser(text);
            Object value = parser.value();
            parser.skipSpace();
            if (parser.pos < text.length()) throw parser.invalid(); // trailing garbage
            return value;
        }

        private IllegalArgumentException invalid() {
            return new IllegalArgumentException("invalid JSON at offset " + pos);
        }

        /** The character at pos, or '\0' at the end of the text. */
        private char peek() {
            return pos < text.length() ? text.charAt(pos) : '\0';
        }

        private static boolean isDigit(char c) {
            return c >= '0' && c <= '9';
        }

        private void skipSpace() {
            while (peek() == ' ' || peek() == '\t' || peek() == '\n' || peek() == '\r') pos++;
        }

        private Object value() {
            skipSpace();
            switch (peek()) {
                case '{':
                case '[': return container();
                case '"': return string();
                case 't': return literal("true", true);
                case 'f': return literal("false", false);
                case 'n': return literal("null", null);
                default: return number();
            }
        }

        private Object literal(String word, Object value) {
            if (!text.startsWith(word, pos)) throw invalid();
            pos += word.length();
            return value;
        }

        private JsonNumber number() {
            int start = pos;
            if (peek() == '-') pos++;
            if (peek() == '0') pos++; // no leading zeros
            else digits();
            if (peek() == '.') {
                pos++;
                digits();
            }
            if (peek() == 'e' || peek() == 'E') {
                pos++;
                if (peek() == '+' || peek() == '-') pos++;
                digits();
            }
            return new JsonNumber(text.substring(start, pos));
        }

        /** Skips a run of one or more digits. */
        private void digits() {
            if (!isDigit(peek())) throw invalid();
            while (isDigit(peek())) pos++;
        }

        /** Parses a string literal; pos is at its opening quote. */
        private String string() {
            var out = new StringBuilder();
            pos++; // skip the opening quote
            for (;;) {
                if (pos == text.length()) throw invalid(); // no closing quote
                char c = text.charAt(pos++);
                if (c == '"') return out.toString();
                if (c < 0x20) throw invalid(); // control characters must be escaped
                if (c != '\\') {
                    out.append(c);
                    continue;
                }
                c = peek();
                pos++;
                switch (c) {
                    case '"':
                    case '\\':
                    case '/': out.append(c); break;
                    case 'b': out.append('\b'); break;
                    case 'f': out.append('\f'); break;
                    case 'n': out.append('\n'); break;
                    case 'r': out.append('\r'); break;
                    case 't': out.append('\t'); break;
                    case 'u': {
                        char unit = hex4();
                        if (Character.isLowSurrogate(unit)) throw invalid(); // half a pair, on its own
                        out.append(unit);
                        if (Character.isHighSurrogate(unit)) { // the other half must follow
                            if (!text.startsWith("\\u", pos)) throw invalid();
                            pos += 2;
                            char low = hex4();
                            if (!Character.isLowSurrogate(low)) throw invalid();
                            out.append(low);
                        }
                        break;
                    }
                    default: throw invalid();
                }
            }
        }

        /** The UTF-16 code unit spelled by the 4 hex digits at pos. */
        private char hex4() {
            int value = 0;
            for (int i = 0; i < 4; i++, pos++) {
                char c = peek();
                int digit = isDigit(c) ? c - '0'
                        : c >= 'a' && c <= 'f' ? c - 'a' + 10
                        : c >= 'A' && c <= 'F' ? c - 'A' + 10
                        : -1;
                if (digit < 0) throw invalid();
                value = value * 16 + digit;
            }
            return (char) value;
        }

        /** Parses an array or object; pos is at its opening bracket. */
        private Object container() {
            boolean isObject = peek() == '{';
            char close = isObject ? '}' : ']';
            var members = new LinkedHashMap<String, Object>();
            var items = new ArrayList<Object>();

            if (++depth > MAX_DEPTH) throw invalid();
            pos++; // skip the opening bracket
            skipSpace();
            if (peek() != close) {
                for (;;) {
                    if (isObject) { // "name": value
                        skipSpace();
                        if (peek() != '"') throw invalid();
                        String name = string();
                        skipSpace();
                        if (peek() != ':') throw invalid();
                        pos++;
                        Object member = value();
                        if (!members.containsKey(name)) members.put(name, member); // a repeated name keeps its first value
                    } else {
                        items.add(value());
                    }
                    skipSpace();
                    if (peek() == close) break;
                    if (peek() != ',') throw invalid();
                    pos++;
                }
            }
            pos++; // skip the closing bracket
            depth--;
            return isObject ? members : items;
        }
    }

    // ------------------------------------------------------------------------
    // Reading Jira's replies
    // ------------------------------------------------------------------------

    /** The value at this path of member names in nested objects, or null if there is none. */
    private static Object get(Object v, String... path) {
        for (String name : path) v = asObject(v).get(name);
        return v;
    }

    /** get() as text: "" if the value is missing or null. */
    private static String str(Object v, String... path) {
        Object value = get(v, path);
        return value == null ? "" : value.toString();
    }

    private static List<?> asList(Object v) {
        return v instanceof List ? (List<?>) v : List.of();
    }

    private static int intValue(Object v, int fallback) {
        return v instanceof JsonNumber ? (int) ((JsonNumber) v).value() : fallback;
    }

    /** The first item that passes the test, or null. */
    private static Object find(List<?> items, Predicate<Object> test) {
        for (Object item : items)
            if (test.test(item)) return item;
        return null;
    }

    /** The items of an array, or the member at path in each, joined by commas. */
    private static String listOf(Object array, String... path) {
        return asList(array).stream().map(item -> str(item, path)).collect(Collectors.joining(", "));
    }

    /** A Jira timestamp like 2026-10-09T14:23:05.123+0200, as 2026-10-09 14:23. */
    private static String when(Object timestamp) {
        String s = timestamp == null ? "" : timestamp.toString();
        return s.length() >= 16 ? s.substring(0, 16).replace('T', ' ') : s;
    }

    /** One line about an issue: ABC-1 [In Progress] Fix the login page */
    private static String briefly(Object issue) {
        return str(issue, "key") + " [" + str(issue, "fields", "status", "name") + "] " + str(issue, "fields", "summary");
    }

    /** Appends "Name: value | Name: value" as a line, leaving out empty values (and empty lines). */
    private static void appendLine(StringBuilder out, String... namesAndValues) {
        var line = new StringJoiner(" | ");
        for (int i = 0; i < namesAndValues.length; i += 2)
            if (!namesAndValues[i + 1].isEmpty()) line.add(namesAndValues[i] + ": " + namesAndValues[i + 1]);
        if (line.length() > 0) out.append(line).append('\n');
    }

    // ------------------------------------------------------------------------
    // Jira REST client
    // ------------------------------------------------------------------------

    /** JIRA_URL without trailing slashes, or null if it is not an http(s) URL. */
    private static final String JIRA_URL = jiraUrl(System.getenv("JIRA_URL"));
    /** The Authorization header sent to Jira, or null without a token. */
    private static final String AUTHORIZATION = authorization(System.getenv("JIRA_EMAIL"), System.getenv("JIRA_API_TOKEN"));
    // HTTP/1.1: a few calls in a row gain nothing from HTTP/2, and plain-http servers get no h2c upgrade to trip on
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private static Map<?, ?> serverInfo; // see serverInfo()

    private static String jiraUrl(String url) {
        if (url == null || !url.strip().matches("(?i)https?://\\S+")) return null;
        return url.strip().replaceAll("/+$", "");
    }

    /** Basic with email and API token for Jira Cloud; Bearer with a personal access token for Data Center. */
    private static String authorization(String email, String token) {
        if (token == null || token.isBlank()) return null;
        if (email == null || email.isBlank()) return "Bearer " + token.strip();
        String credentials = email.strip() + ":" + token.strip();
        return "Basic " + Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Calls Jira's REST API and returns its parsed JSON reply, or null if it sent
     * none. Throws with Jira's own explanation if the call fails.
     */
    private static Object jira(String method, String path, Object body) {
        serverInfo(); // asked first, so that nothing after a change to Jira can fail for want of it
        return send(method, path, body);
    }

    /** What Jira says about itself, asked once: whether it is Jira Cloud, and the address people browse it at. */
    private static Map<?, ?> serverInfo() {
        if (serverInfo == null) serverInfo = asObject(send("GET", "serverInfo", null));
        return serverInfo;
    }

    /** Jira Cloud names users by accountId and pages searches with tokens; Data Center uses usernames and offsets. */
    private static boolean isCloud() {
        return "Cloud".equals(serverInfo().get("deploymentType"));
    }

    private static String browseUrl(String issueKey) {
        Object site = serverInfo().get("baseUrl");
        return (site instanceof String ? site : JIRA_URL) + "/browse/" + issueKey;
    }

    private static Object send(String method, String path, Object body) {
        if (JIRA_URL == null || AUTHORIZATION == null)
            throw new IllegalStateException("Jira is not configured: set JIRA_URL to your site's address (like "
                    + "https://your-domain.atlassian.net) and JIRA_API_TOKEN, plus JIRA_EMAIL for Jira Cloud, "
                    + "in this server's environment");
        var request = HttpRequest.newBuilder(URI.create(JIRA_URL + "/rest/api/2/" + path))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", AUTHORIZATION)
                .header("Accept", "application/json");
        if (body == null)
            request.method(method, HttpRequest.BodyPublishers.noBody());
        else
            request.header("Content-Type", "application/json")
                    .method(method, HttpRequest.BodyPublishers.ofString(toJson(body)));

        HttpResponse<String> response;
        try {
            response = HTTP.send(request.build(), HttpResponse.BodyHandlers.ofString());
        } catch (IOException e) {
            throw new UncheckedIOException("Could not reach Jira at " + JIRA_URL + ": " + e, e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for Jira", e);
        }
        if (response.statusCode() / 100 != 2) throw new IllegalStateException(failure(method, path, response));
        if (response.body().isBlank()) return null; // 204 No Content
        try {
            return JsonParser.parse(response.body());
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException("Jira answered " + method + " " + withoutQuery(path)
                    + " with something other than JSON (is JIRA_URL right?): " + abbreviate(response.body()));
        }
    }

    /** Why a call failed, in Jira's words if it sent any: {"errorMessages": [...], "errors": {"field": "..."}}. */
    private static String failure(String method, String path, HttpResponse<String> response) {
        int status = response.statusCode();
        var why = new StringBuilder("Jira answered " + method + " " + withoutQuery(path) + " with HTTP " + status);
        try {
            Object error = JsonParser.parse(response.body());
            for (Object message : asList(get(error, "errorMessages"))) why.append('\n').append(message);
            for (Map.Entry<?, ?> e : asObject(get(error, "errors")).entrySet())
                why.append('\n').append(e.getKey()).append(": ").append(e.getValue());
        } catch (IllegalArgumentException notJson) {
            // an HTML error page, say: the status has to do
        }
        if (status == 401) why.append("\nCheck JIRA_EMAIL and JIRA_API_TOKEN (Jira Cloud API tokens expire after a year at most).");
        if (status / 100 == 3)
            response.headers().firstValue("Location").ifPresent(to -> why.append("\nRedirected to ").append(to).append(": check JIRA_URL."));
        response.headers().firstValue("Retry-After").ifPresent(seconds -> why.append("\nRetry after ").append(seconds).append(" seconds."));
        return why.toString();
    }

    private static String withoutQuery(String path) {
        return path.replaceFirst("\\?.*", "");
    }

    private static String abbreviate(String s) {
        s = s.strip();
        return s.length() <= 200 ? s : s.substring(0, 200) + "...";
    }

    /** s encoded for a URL path segment or query value. */
    private static String encode(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
    }

    /** A query string from names and values, leaving out null values: queryString("a", 1, "b", "x y") is "?a=1&b=x%20y". */
    private static String queryString(Object... namesAndValues) {
        var query = new StringJoiner("&", "?", "").setEmptyValue("");
        for (int i = 0; i < namesAndValues.length; i += 2)
            if (namesAndValues[i + 1] != null) query.add(namesAndValues[i] + "=" + encode(namesAndValues[i + 1].toString()));
        return query.toString();
    }

    /**
     * A user as Jira expects one: {"accountId": ...} on Jira Cloud, {"name": ...} on
     * Data Center. "me" is the account this server uses; null is nobody.
     */
    private static Map<String, Object> user(String id) {
        String field = isCloud() ? "accountId" : "name";
        if ("me".equals(id)) id = str(jira("GET", "myself", null), field);
        return object(field, id);
    }

    // ------------------------------------------------------------------------
    // Tools: add your own here
    // ------------------------------------------------------------------------

    private static final class Tool {
        final String name;
        final String description;
        final Map<String, Object> inputSchema; // JSON Schema of the arguments object
        /**
         * Gets the arguments object ({} if none was sent) and returns the tool's text
         * output, or throws an exception whose message the model then sees as an
         * error (isError: true).
         */
        final Function<Map<?, ?>, String> run;

        Tool(String name, String description, Map<String, Object> inputSchema, Function<Map<?, ?>, String> run) {
            this.name = name;
            this.description = description;
            this.inputSchema = inputSchema;
            this.run = run;
        }
    }

    private static String requireString(Map<?, ?> args, String name) {
        Object v = args.get(name);
        if (!(v instanceof String) || ((String) v).isBlank())
            throw new IllegalArgumentException("'" + name + "' must be a non-empty string");
        return (String) v;
    }

    /** String argument `name`, or null if it is missing. */
    private static String optString(Map<?, ?> args, String name) {
        Object v = args.get(name);
        if (v != null && !(v instanceof String)) throw new IllegalArgumentException("'" + name + "' must be a string");
        return (String) v;
    }

    /** String-array argument `name`, or null if it is missing. */
    private static List<String> optStrings(Map<?, ?> args, String name) {
        Object v = args.get(name);
        if (v == null) return null;
        if (!(v instanceof List) || !((List<?>) v).stream().allMatch(item -> item instanceof String))
            throw new IllegalArgumentException("'" + name + "' must be an array of strings");
        return ((List<?>) v).stream().map(item -> (String) item).collect(Collectors.toList());
    }

    /** Integer argument `name` brought within 1..max, or fallback if it is missing. */
    private static int intArg(Map<?, ?> args, String name, int fallback, int max) {
        Object v = args.get(name);
        if (v == null) return fallback;
        if (!(v instanceof JsonNumber)) throw new IllegalArgumentException("'" + name + "' must be a number");
        return (int) Math.max(1, Math.min(max, ((JsonNumber) v).value()));
    }

    private static final List<String> SEARCH_FIELDS =
            List.of("summary", "status", "issuetype", "priority", "assignee", "updated");

    private static String searchIssues(Map<?, ?> args) {
        String jql = requireString(args, "jql"), pageToken = optString(args, "pageToken");
        int maxResults = intArg(args, "maxResults", 20, 100);
        List<?> issues;
        String nextPage = null;
        if (isCloud()) { // the enhanced search, whose pages are chained by tokens
            var search = object("jql", jql, "maxResults", maxResults, "fields", SEARCH_FIELDS);
            if (pageToken != null) search.put("nextPageToken", pageToken);
            Object page = jira("POST", "search/jql", search);
            issues = asList(get(page, "issues"));
            if (get(page, "nextPageToken") instanceof String && !Boolean.TRUE.equals(get(page, "isLast")))
                nextPage = (String) get(page, "nextPageToken");
        } else { // Data Center pages by offset
            int startAt;
            try {
                startAt = pageToken == null ? 0 : Integer.parseInt(pageToken);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("'pageToken' must be one that search_issues returned");
            }
            Object page = jira("POST", "search",
                    object("jql", jql, "startAt", startAt, "maxResults", maxResults, "fields", SEARCH_FIELDS));
            issues = asList(get(page, "issues"));
            if (startAt + issues.size() < intValue(get(page, "total"), 0))
                nextPage = String.valueOf(startAt + issues.size());
        }
        if (issues.isEmpty()) return "No issues match.";

        var out = new StringBuilder();
        for (Object issue : issues) {
            Object fields = get(issue, "fields");
            String assignee = str(fields, "assignee", "displayName");
            var details = new StringJoiner(", ");
            for (String detail : new String[] {str(fields, "issuetype", "name"), str(fields, "priority", "name"),
                    assignee.isEmpty() ? "unassigned" : "assigned to " + assignee, "updated " + when(get(fields, "updated"))})
                if (!detail.isEmpty()) details.add(detail);
            out.append(briefly(issue)).append(" (").append(details).append(")\n");
        }
        if (nextPage != null) out.append("More issues match: call again with pageToken \"").append(nextPage).append("\".");
        return out.toString().strip();
    }

    private static final String ISSUE_FIELDS = "summary,status,resolution,issuetype,priority,assignee,reporter,"
            + "created,updated,duedate,labels,components,fixVersions,parent,subtasks,issuelinks,description,comment";
    private static final int LATEST_COMMENTS = 10;

    private static String getIssue(Map<?, ?> args) {
        Object issue = jira("GET", "issue/" + encode(requireString(args, "issueKey")) + queryString("fields", ISSUE_FIELDS), null);
        String key = str(issue, "key");
        Object fields = get(issue, "fields");

        var out = new StringBuilder(key + ": " + str(fields, "summary") + "\n");
        appendLine(out, "URL", browseUrl(key));
        appendLine(out, "Type", str(fields, "issuetype", "name"), "Status", str(fields, "status", "name"),
                "Resolution", str(fields, "resolution", "name"), "Priority", str(fields, "priority", "name"));
        String assignee = str(fields, "assignee", "displayName");
        appendLine(out, "Assignee", assignee.isEmpty() ? "unassigned" : assignee,
                "Reporter", str(fields, "reporter", "displayName"));
        appendLine(out, "Created", when(get(fields, "created")), "Updated", when(get(fields, "updated")),
                "Due", str(fields, "duedate"));
        appendLine(out, "Labels", listOf(get(fields, "labels")), "Components", listOf(get(fields, "components"), "name"),
                "Fix versions", listOf(get(fields, "fixVersions"), "name"));
        Object parent = get(fields, "parent");
        if (parent != null) appendLine(out, "Parent", briefly(parent));
        for (Object subtask : asList(get(fields, "subtasks"))) appendLine(out, "Subtask", briefly(subtask));
        for (Object link : asList(get(fields, "issuelinks"))) {
            boolean outward = get(link, "outwardIssue") != null; // "blocks" ABC-2, rather than "is blocked by" it
            appendLine(out, "Link", str(link, "type", outward ? "outward" : "inward") + " "
                    + briefly(get(link, outward ? "outwardIssue" : "inwardIssue")));
        }
        String description = str(fields, "description").strip();
        out.append("\nDescription:\n").append(description.isEmpty() ? "(none)" : description).append('\n');

        Object comments = get(fields, "comment");
        List<?> latest = asList(get(comments, "comments"));
        int total = intValue(get(comments, "total"), latest.size());
        if (total > latest.size()) // Jira sent only the first comments: fetch the last ones
            latest = asList(get(jira("GET", "issue/" + encode(key) + "/comment"
                    + queryString("startAt", Math.max(0, total - LATEST_COMMENTS), "maxResults", LATEST_COMMENTS), null), "comments"));
        latest = latest.subList(Math.max(0, latest.size() - LATEST_COMMENTS), latest.size());
        if (total == 0) {
            out.append("\nNo comments.");
        } else {
            out.append("\nComments (").append(total > latest.size() ? "the latest " + latest.size() + " of " + total : total).append("):");
            for (Object comment : latest)
                out.append("\n\n").append(str(comment, "author", "displayName")).append(", ").append(when(get(comment, "created")))
                        .append(":\n").append(str(comment, "body").strip());
        }
        return out.toString().strip();
    }

    /** The optional fields that create_issue and update_issue share, in the form Jira takes them. */
    private static Map<String, Object> optionalFields(Map<?, ?> args) {
        var fields = new LinkedHashMap<String, Object>();
        String description = optString(args, "description"), priority = optString(args, "priority");
        String dueDate = optString(args, "dueDate");
        List<String> labels = optStrings(args, "labels");
        if (description != null) fields.put("description", description);
        if (priority != null) fields.put("priority", object("name", priority));
        if (labels != null) fields.put("labels", labels);
        if (dueDate != null) fields.put("duedate", dueDate.isEmpty() ? null : dueDate);
        return fields;
    }

    private static String createIssue(Map<?, ?> args) {
        var fields = object("project", object("key", requireString(args, "projectKey")),
                "issuetype", object("name", requireString(args, "issueType")),
                "summary", requireString(args, "summary"));
        fields.putAll(optionalFields(args));
        String assignee = optString(args, "assignee"), parentKey = optString(args, "parentKey");
        if (assignee != null) fields.put("assignee", user(assignee));
        if (parentKey != null) fields.put("parent", object("key", parentKey));
        String key = str(jira("POST", "issue", object("fields", fields)), "key");
        return "Created " + key + ": " + browseUrl(key);
    }

    private static String updateIssue(Map<?, ?> args) {
        String key = requireString(args, "issueKey"), summary = optString(args, "summary");
        var fields = new LinkedHashMap<String, Object>();
        if (summary != null) fields.put("summary", summary);
        fields.putAll(optionalFields(args));
        if (fields.isEmpty())
            throw new IllegalArgumentException("Nothing to update: give summary, description, priority, labels or dueDate");
        jira("PUT", "issue/" + encode(key), object("fields", fields));
        return "Updated " + key + ": " + String.join(", ", fields.keySet());
    }

    private static String addComment(Map<?, ?> args) {
        String key = requireString(args, "issueKey");
        Object comment = jira("POST", "issue/" + encode(key) + "/comment", object("body", requireString(args, "body")));
        return "Added comment " + str(comment, "id") + " to " + key;
    }

    private static List<?> transitions(String issueKey) {
        return asList(get(jira("GET", "issue/" + encode(issueKey) + "/transitions", null), "transitions"));
    }

    /** "Start Progress" (id 21) -> In Progress */
    private static String describeTransition(Object transition) {
        return "\"" + str(transition, "name") + "\" (id " + str(transition, "id") + ") -> " + str(transition, "to", "name");
    }

    private static String getTransitions(Map<?, ?> args) {
        String key = requireString(args, "issueKey");
        List<?> transitions = transitions(key);
        if (transitions.isEmpty()) return key + " has no transitions you can make.";
        return "Transitions for " + key + ":\n"
                + transitions.stream().map(JiraMcpServer::describeTransition).collect(Collectors.joining("\n"));
    }

    private static String transitionIssue(Map<?, ?> args) {
        String key = requireString(args, "issueKey"), wanted = requireString(args, "transition");
        String resolution = optString(args, "resolution"), comment = optString(args, "comment");
        List<?> transitions = transitions(key);
        // The transition with this id, else with this name, else leading to the status of this name.
        Object chosen = find(transitions, t -> wanted.equals(str(t, "id")));
        if (chosen == null) chosen = find(transitions, t -> wanted.equalsIgnoreCase(str(t, "name")));
        if (chosen == null) chosen = find(transitions, t -> wanted.equalsIgnoreCase(str(t, "to", "name")));
        if (chosen == null)
            throw new IllegalArgumentException("No transition \"" + wanted + "\" for " + key + ". "
                    + (transitions.isEmpty() ? "None are available to you." : "Available: "
                    + transitions.stream().map(JiraMcpServer::describeTransition).collect(Collectors.joining("; "))));

        var request = object("transition", object("id", str(chosen, "id")));
        if (resolution != null) request.put("fields", object("resolution", object("name", resolution)));
        if (comment != null) request.put("update", object("comment", List.of(object("add", object("body", comment)))));
        jira("POST", "issue/" + encode(key) + "/transitions", request);
        return key + " is now " + str(chosen, "to", "name") + " (transition \"" + str(chosen, "name") + "\")";
    }

    private static String assignIssue(Map<?, ?> args) {
        String key = requireString(args, "issueKey");
        if (!args.containsKey("assignee"))
            throw new IllegalArgumentException("'assignee' is required: a user from find_users, \"me\", or null to unassign");
        String assignee = optString(args, "assignee");
        jira("PUT", "issue/" + encode(key) + "/assignee", user(assignee));
        return assignee == null ? key + " is now unassigned" : key + " is now assigned to " + assignee;
    }

    private static String findUsers(Map<?, ?> args) {
        String query = requireString(args, "query");
        boolean cloud = isCloud();
        List<?> users = asList(jira("GET", "user/search" + queryString(cloud ? "query" : "username", query, "maxResults", 20), null));
        if (users.isEmpty()) return "No users match \"" + query + "\".";
        return users.stream()
                .map(u -> str(u, "displayName")
                        + (str(u, "emailAddress").isEmpty() ? "" : " <" + str(u, "emailAddress") + ">")
                        + (cloud ? ": accountId " + str(u, "accountId") : ": username " + str(u, "name"))
                        + (Boolean.FALSE.equals(get(u, "active")) ? " (inactive)" : ""))
                .collect(Collectors.joining("\n"));
    }

    private static String listProjects(Map<?, ?> args) {
        String query = optString(args, "query");
        List<?> projects;
        boolean more = false;
        if (isCloud()) {
            Object page = jira("GET", "project/search" + queryString("query", query, "maxResults", 100, "orderBy", "key"), null);
            projects = asList(get(page, "values"));
            more = Boolean.FALSE.equals(get(page, "isLast"));
        } else { // Data Center lists every project at once
            projects = asList(jira("GET", "project", null));
            if (query != null) {
                String q = query.toLowerCase(Locale.ROOT);
                projects = projects.stream()
                        .filter(p -> (str(p, "key") + " " + str(p, "name")).toLowerCase(Locale.ROOT).contains(q))
                        .collect(Collectors.toList());
            }
        }
        if (projects.isEmpty()) return query == null ? "You can see no projects." : "No projects match \"" + query + "\".";
        return projects.stream().map(p -> str(p, "key") + ": " + str(p, "name")).collect(Collectors.joining("\n"))
                + (more ? "\nThere are more: narrow the list with query." : "");
    }

    private static String getProject(Map<?, ?> args) {
        Object project = jira("GET", "project/" + encode(requireString(args, "projectKey")), null);
        var out = new StringBuilder(str(project, "key") + ": " + str(project, "name") + "\n");
        appendLine(out, "Lead", str(project, "lead", "displayName"));
        appendLine(out, "Issue types", asList(get(project, "issueTypes")).stream()
                .map(type -> str(type, "name") + (Boolean.TRUE.equals(get(type, "subtask")) ? " (sub-task)" : ""))
                .collect(Collectors.joining(", ")));
        appendLine(out, "Components", listOf(get(project, "components"), "name"));
        String description = str(project, "description").strip();
        if (!description.isEmpty()) out.append("\n").append(description);
        return out.toString().strip();
    }

    private static final String WIKI_MARKUP = "Jira wiki markup, not Markdown: *bold*, _italic_, {{monospace}}, "
            + "h2. Heading, * bullet, # numbered item, {code}...{code}, [text|https://link]";

    private static final List<Tool> TOOLS = List.of(
            new Tool("search_issues",
                    "Search Jira issues with JQL, such as 'project = ABC AND statusCategory != Done ORDER BY updated DESC' "
                            + "or 'assignee = currentUser() AND resolution = Unresolved'. Returns one line per issue.",
                    object("type", "object",
                            "properties", object(
                                    "jql", object("type", "string", "description",
                                            "The JQL query. It must restrict the search (by project or assignee, say): "
                                                    + "a bare ORDER BY is rejected."),
                                    "maxResults", object("type", "integer", "description", "Issues per page, 1 to 100 (default 20)"),
                                    "pageToken", object("type", "string", "description",
                                            "For the next page of a search: the pageToken that the previous call returned")),
                            "required", List.of("jql")),
                    JiraMcpServer::searchIssues),
            new Tool("get_issue",
                    "Read a Jira issue: its fields, description, subtasks, links and latest comments.",
                    object("type", "object",
                            "properties", object("issueKey", object("type", "string", "description", "Issue key, like ABC-123")),
                            "required", List.of("issueKey")),
                    JiraMcpServer::getIssue),
            new Tool("create_issue",
                    "Create a Jira issue. get_project lists the issue types a project takes.",
                    object("type", "object",
                            "properties", object(
                                    "projectKey", object("type", "string", "description", "Project key, like ABC"),
                                    "issueType", object("type", "string", "description", "Issue type name, like Task, Bug or Story"),
                                    "summary", object("type", "string", "description", "One-line title"),
                                    "description", object("type", "string", "description", WIKI_MARKUP),
                                    "priority", object("type", "string", "description", "Priority name, like High"),
                                    "labels", object("type", "array", "items", object("type", "string"),
                                            "description", "Labels, without spaces"),
                                    "dueDate", object("type", "string", "description", "Due date, as YYYY-MM-DD"),
                                    "assignee", object("type", "string", "description",
                                            "accountId (Jira Cloud) or username (Data Center) from find_users, or \"me\""),
                                    "parentKey", object("type", "string", "description",
                                            "Parent issue key: the epic of a story, or the issue a sub-task belongs to")),
                            "required", List.of("projectKey", "issueType", "summary")),
                    JiraMcpServer::createIssue),
            new Tool("update_issue",
                    "Change fields of a Jira issue; the fields left out stay as they are. "
                            + "transition_issue changes the status and assign_issue the assignee.",
                    object("type", "object",
                            "properties", object(
                                    "issueKey", object("type", "string", "description", "Issue key, like ABC-123"),
                                    "summary", object("type", "string", "description", "One-line title"),
                                    "description", object("type", "string", "description", WIKI_MARKUP),
                                    "priority", object("type", "string", "description", "Priority name, like High"),
                                    "labels", object("type", "array", "items", object("type", "string"),
                                            "description", "Labels, without spaces: they replace all the current ones"),
                                    "dueDate", object("type", "string", "description", "Due date, as YYYY-MM-DD, or \"\" to clear it")),
                            "required", List.of("issueKey")),
                    JiraMcpServer::updateIssue),
            new Tool("add_comment",
                    "Add a comment to a Jira issue.",
                    object("type", "object",
                            "properties", object(
                                    "issueKey", object("type", "string", "description", "Issue key, like ABC-123"),
                                    "body", object("type", "string", "description", WIKI_MARKUP)),
                            "required", List.of("issueKey", "body")),
                    JiraMcpServer::addComment),
            new Tool("get_transitions",
                    "List the workflow transitions you can make on a Jira issue now, and the status each one leads to.",
                    object("type", "object",
                            "properties", object("issueKey", object("type", "string", "description", "Issue key, like ABC-123")),
                            "required", List.of("issueKey")),
                    JiraMcpServer::getTransitions),
            new Tool("transition_issue",
                    "Move a Jira issue through its workflow, to In Progress or Done say.",
                    object("type", "object",
                            "properties", object(
                                    "issueKey", object("type", "string", "description", "Issue key, like ABC-123"),
                                    "transition", object("type", "string", "description",
                                            "The transition's name or id, or the name of the status to move to"),
                                    "resolution", object("type", "string", "description",
                                            "Resolution to set, like Done or Fixed, if the transition asks for one"),
                                    "comment", object("type", "string", "description", "A comment to add on the way, in " + WIKI_MARKUP)),
                            "required", List.of("issueKey", "transition")),
                    JiraMcpServer::transitionIssue),
            new Tool("assign_issue",
                    "Assign a Jira issue to someone, or unassign it.",
                    object("type", "object",
                            "properties", object(
                                    "issueKey", object("type", "string", "description", "Issue key, like ABC-123"),
                                    "assignee", object("type", List.of("string", "null"), "description",
                                            "accountId (Jira Cloud) or username (Data Center) from find_users, "
                                                    + "\"me\" for the account this server uses, or null to unassign")),
                            "required", List.of("issueKey", "assignee")),
                    JiraMcpServer::assignIssue),
            new Tool("find_users",
                    "Find Jira users by name or email, for the ids that assign_issue and create_issue take.",
                    object("type", "object",
                            "properties", object("query", object("type", "string", "description", "Part of a name or email address")),
                            "required", List.of("query")),
                    JiraMcpServer::findUsers),
            new Tool("list_projects",
                    "List the Jira projects you can see, as KEY: Name.",
                    object("type", "object",
                            "properties", object("query", object("type", "string", "description",
                                    "Only projects whose key or name contains this text"))),
                    JiraMcpServer::listProjects),
            new Tool("get_project",
                    "Read a Jira project: its lead, issue types and components.",
                    object("type", "object",
                            "properties", object("projectKey", object("type", "string", "description", "Project key, like ABC")),
                            "required", List.of("projectKey")),
                    JiraMcpServer::getProject));

    // ------------------------------------------------------------------------
    // MCP methods
    // ------------------------------------------------------------------------

    /** A JSON-RPC error, sent back in place of a result. */
    @SuppressWarnings("serial") // never serialized
    private static final class RpcError extends Exception {
        final int code;

        RpcError(int code, String message) {
            super(message);
            this.code = code;
        }
    }

    /** A method returns its JSON result, or throws RpcError. */
    private interface Method {
        Object handle(Map<?, ?> params) throws RpcError;
    }

    private static Map<String, Object> initialize(Map<?, ?> params) {
        // Echo the client's protocol version if we know it, else offer our newest.
        Object wanted = params.get("protocolVersion");
        String version = wanted instanceof String && PROTOCOL_VERSIONS.contains(wanted)
                ? (String) wanted
                : PROTOCOL_VERSIONS.get(0);
        return object("protocolVersion", version,
                "capabilities", object("tools", object()),
                "serverInfo", object("name", SERVER_NAME, "version", SERVER_VERSION));
    }

    private static Map<String, Object> ping(Map<?, ?> params) {
        return object();
    }

    private static Map<String, Object> toolsList(Map<?, ?> params) { // no pagination: every tool fits in one page
        var tools = new ArrayList<Object>();
        for (Tool tool : TOOLS)
            tools.add(object("name", tool.name, "description", tool.description, "inputSchema", tool.inputSchema));
        return object("tools", tools);
    }

    private static Map<String, Object> toolsCall(Map<?, ?> params) throws RpcError {
        Object name = params.get("name");
        Tool tool = TOOLS.stream().filter(t -> t.name.equals(name)).findFirst()
                .orElseThrow(() -> new RpcError(INVALID_PARAMS,
                        "Unknown tool: " + (name instanceof String ? name : "(no name given)")));

        String text;
        boolean isError;
        try {
            text = tool.run.apply(asObject(params.get("arguments")));
            isError = false;
        } catch (RuntimeException e) {
            text = e.getMessage() != null ? e.getMessage() : e.toString();
            isError = true;
        }
        return object("content", List.of(object("type", "text", "text", text)), "isError", isError);
    }

    private static final Map<String, Method> METHODS = Map.of(
            "initialize", JiraMcpServer::initialize,
            "ping", JiraMcpServer::ping,
            "tools/list", JiraMcpServer::toolsList,
            "tools/call", JiraMcpServer::toolsCall);

    // ------------------------------------------------------------------------
    // JSON-RPC over stdio
    // ------------------------------------------------------------------------

    /** The reply to one message, or null if it gets none. */
    private static Map<String, Object> handleMessage(String line) {
        Object msg;
        try {
            msg = JsonParser.parse(line);
        } catch (IllegalArgumentException e) {
            return errorReply(null, PARSE_ERROR, "Parse error");
        }
        Map<?, ?> fields = asObject(msg);
        Object id = fields.get("id"), method = fields.get("method");
        if (!(msg instanceof Map) || (fields.containsKey("method") && !(method instanceof String))
                || (fields.containsKey("id") && !(id instanceof String) && !(id instanceof JsonNumber)))
            return errorReply(null, INVALID_REQUEST, "Invalid Request");
        if (method != null && id != null)
            return handleRequest(id, (String) method, asObject(fields.get("params")));
        // Anything else is a notification (e.g. notifications/initialized) or a
        // response to a request we never sent: neither gets a reply.
        return null;
    }

    private static Map<String, Object> handleRequest(Object id, String method, Map<?, ?> params) {
        Method handler = METHODS.get(method);
        if (handler == null) return errorReply(id, METHOD_NOT_FOUND, "Method not found: " + method);
        try {
            return object("jsonrpc", "2.0", "id", id, "result", handler.handle(params));
        } catch (RpcError e) {
            return errorReply(id, e.code, e.getMessage());
        }
    }

    /** An error reply; a null id is sent as null. */
    private static Map<String, Object> errorReply(Object id, int code, String message) {
        return object("jsonrpc", "2.0", "id", id, "error", object("code", code, "message", message));
    }

    public static void main(String[] args) throws IOException {
        // stdout carries protocol messages only: keep it for them, and point
        // System.out at stderr so a stray print (from a tool, say) can't corrupt it.
        Writer out = new BufferedWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8));
        System.setOut(System.err);
        var in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

        System.err.println(SERVER_NAME + " " + SERVER_VERSION + " ready on stdio, for "
                + (JIRA_URL != null && AUTHORIZATION != null ? JIRA_URL
                        : "no Jira yet: set JIRA_URL and JIRA_API_TOKEN (plus JIRA_EMAIL for Jira Cloud)"));
        String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue;
            Map<String, Object> reply = handleMessage(line);
            if (reply != null) {
                out.write(toJson(reply) + "\n");
                out.flush();
            }
        }
    }
}
