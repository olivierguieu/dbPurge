/*
 * mcp_server.c - a minimal Model Context Protocol (MCP) server in plain C.
 *
 * It speaks JSON-RPC 2.0 over stdio, the standard MCP transport for local
 * servers: one JSON message per line on stdin, one reply per line on stdout.
 * No dependencies beyond libc. It exposes three example tools: echo, add and
 * current_time.
 *
 *   Build:  make        (or: cc -std=c11 -O2 -o mcp_server mcp_server.c)
 *   Try:    make demo
 *   Use:    claude mcp add simple-c -- /absolute/path/to/mcp_server
 */
#define _POSIX_C_SOURCE 200809L /* for getline() and localtime_r() */

#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define SERVER_NAME "simple-c-mcp"
#define SERVER_VERSION "0.1.0"
#define MAX_DEPTH 64 /* deepest JSON nesting we accept */

/* MCP protocol revisions this server can speak, newest first. */
static const char *const PROTOCOL_VERSIONS[] = {
    "2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05",
};

/* JSON-RPC 2.0 error codes */
enum {
    PARSE_ERROR = -32700,
    INVALID_REQUEST = -32600,
    METHOD_NOT_FOUND = -32601,
    INVALID_PARAMS = -32602,
};

#define COUNT(a) (sizeof(a) / sizeof((a)[0]))

/* Turns bare JSON into a C string literal: JSON({"a": 1}) is "{\"a\": 1}".
   This keeps the schemas below readable without escaping every quote. */
#define JSON(...) #__VA_ARGS__

static void *must(void *p) {
    if (!p) {
        fputs(SERVER_NAME ": out of memory\n", stderr);
        exit(1);
    }
    return p;
}

/* ------------------------------------------------------------------------ */
/* Growable string buffer                                                   */
/* ------------------------------------------------------------------------ */

typedef struct {
    char *data;
    size_t len, cap;
} Buf;

/* Make room for n more bytes plus the terminating NUL. */
static void buf_reserve(Buf *b, size_t n) {
    if (b->len + n < b->cap) return;
    size_t cap = b->cap ? b->cap : 256;
    while (b->len + n >= cap) cap *= 2;
    b->data = must(realloc(b->data, cap));
    b->cap = cap;
}

static void buf_append(Buf *b, const char *s, size_t n) {
    buf_reserve(b, n);
    memcpy(b->data + b->len, s, n);
    b->len += n;
    b->data[b->len] = '\0';
}

static void buf_puts(Buf *b, const char *s) { buf_append(b, s, strlen(s)); }

static void buf_printf(Buf *b, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n < 0) return;
    buf_reserve(b, (size_t)n);
    va_start(ap, fmt);
    vsnprintf(b->data + b->len, (size_t)n + 1, fmt, ap);
    va_end(ap);
    b->len += (size_t)n;
}

/* The contents as a C string, "" if nothing was written yet. */
static const char *buf_str(const Buf *b) { return b->data ? b->data : ""; }

/* Append s as a quoted, escaped JSON string. */
static void buf_put_json_string(Buf *b, const char *s) {
    buf_puts(b, "\"");
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\')
            buf_printf(b, "\\%c", c);
        else if (c == '\n')
            buf_puts(b, "\\n");
        else if (c == '\r')
            buf_puts(b, "\\r");
        else if (c == '\t')
            buf_puts(b, "\\t");
        else if (c < 0x20)
            buf_printf(b, "\\u%04x", c);
        else
            buf_append(b, s, 1);
    }
    buf_puts(b, "\"");
}

/* ------------------------------------------------------------------------ */
/* Minimal JSON parser: turns one message into a tree of Json nodes         */
/* ------------------------------------------------------------------------ */

typedef enum { JSON_NULL, JSON_BOOL, JSON_NUMBER, JSON_STRING, JSON_ARRAY, JSON_OBJECT } JsonType;

typedef struct Json Json;
struct Json {
    JsonType type;
    bool boolean;
    double number;
    char *string; /* JSON_STRING: the decoded text; JSON_NUMBER: the literal as written */
    char *key;    /* member name, when this value sits in an object */
    Json *child;  /* first element/member of an array/object */
    Json *next;   /* next sibling in the enclosing array/object */
};

typedef struct {
    const char *p; /* current position in the input */
    int depth;     /* current array/object nesting */
} Parser;

static Json *parse_value(Parser *ps);

static void json_free(Json *v) {
    while (v) {
        Json *next = v->next;
        json_free(v->child);
        free(v->string);
        free(v->key);
        free(v);
        v = next;
    }
}

static Json *json_new(JsonType type) {
    Json *v = must(calloc(1, sizeof *v));
    v->type = type;
    return v;
}

static bool is_digit(char c) { return c >= '0' && c <= '9'; }

static void skip_space(Parser *ps) {
    while (*ps->p == ' ' || *ps->p == '\t' || *ps->p == '\n' || *ps->p == '\r') ps->p++;
}

/* Value of the 4 hex digits at s, or -1 if they are not all hex digits. */
static long hex4(const char *s) {
    long v = 0;
    for (int i = 0; i < 4; i++) {
        char c = s[i];
        int d = is_digit(c)             ? c - '0'
                : c >= 'a' && c <= 'f' ? c - 'a' + 10
                : c >= 'A' && c <= 'F' ? c - 'A' + 10
                                       : -1;
        if (d < 0) return -1;
        v = v * 16 + d;
    }
    return v;
}

/* Write code point cp as UTF-8 into out; returns the number of bytes. */
static int put_utf8(char *out, long cp) {
    if (cp < 0x80) {
        out[0] = (char)cp;
        return 1;
    }
    if (cp < 0x800) {
        out[0] = (char)(0xC0 | (cp >> 6));
        out[1] = (char)(0x80 | (cp & 0x3F));
        return 2;
    }
    if (cp < 0x10000) {
        out[0] = (char)(0xE0 | (cp >> 12));
        out[1] = (char)(0x80 | ((cp >> 6) & 0x3F));
        out[2] = (char)(0x80 | (cp & 0x3F));
        return 3;
    }
    out[0] = (char)(0xF0 | (cp >> 18));
    out[1] = (char)(0x80 | ((cp >> 12) & 0x3F));
    out[2] = (char)(0x80 | ((cp >> 6) & 0x3F));
    out[3] = (char)(0x80 | (cp & 0x3F));
    return 4;
}

/* Parse a string literal (ps->p is at the opening quote) into decoded UTF-8. */
static char *parse_string(Parser *ps) {
    const char *start = ps->p + 1, *end = start;
    while (*end != '"') { /* find the closing quote */
        if (*end == '\\') end++;
        if (*end == '\0') return NULL;
        end++;
    }

    /* Decoding never makes a string longer, so the raw length is enough. */
    char *out = must(malloc((size_t)(end - start) + 1)), *o = out;
    for (const char *p = start; p < end;) {
        char c = *p++;
        if ((unsigned char)c < 0x20) goto fail; /* control characters must be escaped */
        if (c != '\\') {
            *o++ = c;
            continue;
        }
        c = *p++;
        switch (c) {
        case '"':
        case '\\':
        case '/': *o++ = c; break;
        case 'b': *o++ = '\b'; break;
        case 'f': *o++ = '\f'; break;
        case 'n': *o++ = '\n'; break;
        case 'r': *o++ = '\r'; break;
        case 't': *o++ = '\t'; break;
        case 'u': {
            long cp = hex4(p);
            if (cp < 0 || (cp >= 0xDC00 && cp <= 0xDFFF)) goto fail;
            p += 4;
            if (cp >= 0xD800 && cp <= 0xDBFF) { /* high surrogate: a low one must follow */
                long lo = p[0] == '\\' && p[1] == 'u' ? hex4(p + 2) : -1;
                if (lo < 0xDC00 || lo > 0xDFFF) goto fail;
                cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                p += 6;
            }
            o += put_utf8(o, cp);
            break;
        }
        default: goto fail;
        }
    }
    *o = '\0';
    ps->p = end + 1;
    return out;
fail:
    free(out);
    return NULL;
}

static Json *parse_number(Parser *ps) {
    const char *start = ps->p, *p = start;
    if (*p == '-') p++;
    if (!is_digit(*p)) return NULL;
    if (*p == '0') { /* no leading zeros */
        p++;
    } else {
        while (is_digit(*p)) p++;
    }
    if (*p == '.') {
        if (!is_digit(*++p)) return NULL;
        while (is_digit(*p)) p++;
    }
    if (*p == 'e' || *p == 'E') {
        p++;
        if (*p == '+' || *p == '-') p++;
        if (!is_digit(*p)) return NULL;
        while (is_digit(*p)) p++;
    }

    size_t len = (size_t)(p - start);
    Json *v = json_new(JSON_NUMBER);
    v->string = must(malloc(len + 1));
    memcpy(v->string, start, len);
    v->string[len] = '\0';
    v->number = strtod(v->string, NULL);
    ps->p = p;
    return v;
}

static Json *parse_literal(Parser *ps, const char *word, JsonType type, bool value) {
    size_t n = strlen(word);
    if (strncmp(ps->p, word, n) != 0) return NULL;
    ps->p += n;
    Json *v = json_new(type);
    v->boolean = value;
    return v;
}

/* Parse an array or object; ps->p is at its opening bracket. */
static Json *parse_container(Parser *ps) {
    bool is_object = *ps->p == '{';
    char close = is_object ? '}' : ']';
    Json *c = json_new(is_object ? JSON_OBJECT : JSON_ARRAY);
    Json **tail = &c->child;
    char *key = NULL;

    if (++ps->depth > MAX_DEPTH) goto fail;
    ps->p++; /* skip the opening bracket */
    skip_space(ps);
    if (*ps->p == close) goto done;
    for (;;) {
        if (is_object) { /* "key": */
            skip_space(ps);
            if (*ps->p != '"' || !(key = parse_string(ps))) goto fail;
            skip_space(ps);
            if (*ps->p != ':') goto fail;
            ps->p++;
        }
        Json *item = parse_value(ps);
        if (!item) goto fail;
        item->key = key;
        key = NULL;
        *tail = item;
        tail = &item->next;

        skip_space(ps);
        if (*ps->p == close) goto done;
        if (*ps->p != ',') goto fail;
        ps->p++;
    }
done:
    ps->p++; /* skip the closing bracket */
    ps->depth--;
    return c;
fail:
    free(key);
    json_free(c);
    return NULL;
}

static Json *parse_value(Parser *ps) {
    skip_space(ps);
    switch (*ps->p) {
    case '{':
    case '[': return parse_container(ps);
    case '"': {
        char *s = parse_string(ps);
        if (!s) return NULL;
        Json *v = json_new(JSON_STRING);
        v->string = s;
        return v;
    }
    case 't': return parse_literal(ps, "true", JSON_BOOL, true);
    case 'f': return parse_literal(ps, "false", JSON_BOOL, false);
    case 'n': return parse_literal(ps, "null", JSON_NULL, false);
    default: return parse_number(ps);
    }
}

/* Parse a whole JSON text; returns NULL if it is not valid JSON. */
static Json *json_parse(const char *text) {
    Parser ps = {text, 0};
    Json *v = parse_value(&ps);
    if (!v) return NULL;
    skip_space(&ps);
    if (*ps.p != '\0') { /* trailing garbage */
        json_free(v);
        return NULL;
    }
    return v;
}

/* Member `key` of an object, or NULL if obj is not an object or lacks it. */
static const Json *json_get(const Json *obj, const char *key) {
    if (!obj || obj->type != JSON_OBJECT) return NULL;
    for (const Json *m = obj->child; m; m = m->next)
        if (strcmp(m->key, key) == 0) return m;
    return NULL;
}

static const char *json_get_string(const Json *obj, const char *key) {
    const Json *v = json_get(obj, key);
    return v && v->type == JSON_STRING ? v->string : NULL;
}

static bool json_get_number(const Json *obj, const char *key, double *out) {
    const Json *v = json_get(obj, key);
    if (!v || v->type != JSON_NUMBER) return false;
    *out = v->number;
    return true;
}

/* ------------------------------------------------------------------------ */
/* Tools: add your own here                                                 */
/* ------------------------------------------------------------------------ */

typedef struct {
    const char *name;
    const char *description;
    const char *input_schema; /* JSON Schema of the arguments object */
    /* Writes the tool's text output into `out` and returns true, or writes an
       error message and returns false (the model then sees isError: true). */
    bool (*run)(const Json *args, Buf *out);
} Tool;

static bool tool_echo(const Json *args, Buf *out) {
    const char *message = json_get_string(args, "message");
    if (!message) {
        buf_puts(out, "'message' must be a string");
        return false;
    }
    buf_puts(out, message);
    return true;
}

static bool tool_add(const Json *args, Buf *out) {
    double a, b;
    if (!json_get_number(args, "a", &a) || !json_get_number(args, "b", &b)) {
        buf_puts(out, "'a' and 'b' must both be numbers");
        return false;
    }
    buf_printf(out, "%.15g", a + b);
    return true;
}

static bool tool_current_time(const Json *args, Buf *out) {
    (void)args;
    char stamp[64];
    time_t now = time(NULL);
    struct tm local;
    if (!localtime_r(&now, &local)) {
        buf_puts(out, "could not read the system clock");
        return false;
    }
    strftime(stamp, sizeof stamp, "%Y-%m-%d %H:%M:%S %z", &local);
    buf_puts(out, stamp);
    return true;
}

static const Tool TOOLS[] = {
    {"echo", "Echo a message back unchanged.",
     JSON({"type": "object",
           "properties": {"message": {"type": "string", "description": "Text to echo back"}},
           "required": ["message"]}),
     tool_echo},
    {"add", "Add two numbers and return the sum.",
     JSON({"type": "object",
           "properties": {"a": {"type": "number"}, "b": {"type": "number"}},
           "required": ["a", "b"]}),
     tool_add},
    {"current_time", "Get the current local date and time of the machine running this server.",
     JSON({"type": "object", "properties": {}}),
     tool_current_time},
};

/* ------------------------------------------------------------------------ */
/* MCP methods                                                              */
/* ------------------------------------------------------------------------ */

/* A method writes its JSON result into `out` and returns 0, or writes an
   error message and returns a JSON-RPC error code. */
typedef int (*MethodFn)(const Json *params, Buf *out);

static int mcp_initialize(const Json *params, Buf *out) {
    /* Echo the client's protocol version if we know it, else offer our newest. */
    const char *wanted = json_get_string(params, "protocolVersion");
    const char *version = PROTOCOL_VERSIONS[0];
    for (size_t i = 0; wanted && i < COUNT(PROTOCOL_VERSIONS); i++)
        if (strcmp(wanted, PROTOCOL_VERSIONS[i]) == 0) version = PROTOCOL_VERSIONS[i];

    buf_printf(out,
               JSON({"protocolVersion": "%s",
                     "capabilities": {"tools": {}},
                     "serverInfo": {"name": "%s", "version": "%s"}}),
               version, SERVER_NAME, SERVER_VERSION);
    return 0;
}

static int mcp_ping(const Json *params, Buf *out) {
    (void)params;
    buf_puts(out, "{}");
    return 0;
}

static int mcp_tools_list(const Json *params, Buf *out) {
    (void)params; /* no pagination: every tool fits in one page */
    buf_puts(out, "{\"tools\":[");
    for (size_t i = 0; i < COUNT(TOOLS); i++) {
        if (i > 0) buf_puts(out, ",");
        buf_puts(out, "{\"name\":");
        buf_put_json_string(out, TOOLS[i].name);
        buf_puts(out, ",\"description\":");
        buf_put_json_string(out, TOOLS[i].description);
        buf_puts(out, ",\"inputSchema\":");
        buf_puts(out, TOOLS[i].input_schema);
        buf_puts(out, "}");
    }
    buf_puts(out, "]}");
    return 0;
}

static int mcp_tools_call(const Json *params, Buf *out) {
    const char *name = json_get_string(params, "name");
    const Tool *tool = NULL;
    for (size_t i = 0; name && i < COUNT(TOOLS); i++)
        if (strcmp(name, TOOLS[i].name) == 0) tool = &TOOLS[i];
    if (!tool) {
        buf_printf(out, "Unknown tool: %s", name ? name : "(no name given)");
        return INVALID_PARAMS;
    }

    Buf text = {0};
    bool ok = tool->run(json_get(params, "arguments"), &text);
    buf_puts(out, "{\"content\":[{\"type\":\"text\",\"text\":");
    buf_put_json_string(out, buf_str(&text));
    buf_printf(out, "}],\"isError\":%s}", ok ? "false" : "true");
    free(text.data);
    return 0;
}

static const struct {
    const char *name;
    MethodFn handle;
} METHODS[] = {
    {"initialize", mcp_initialize},
    {"ping", mcp_ping},
    {"tools/list", mcp_tools_list},
    {"tools/call", mcp_tools_call},
};

/* ------------------------------------------------------------------------ */
/* JSON-RPC over stdio                                                      */
/* ------------------------------------------------------------------------ */

/* Write one response line: a result if code is 0 (body is JSON), otherwise an
   error (body is the message). A NULL id is sent as null. */
static void send_response(const Json *id, int code, const char *body) {
    Buf msg = {0};
    buf_puts(&msg, "{\"jsonrpc\":\"2.0\",\"id\":");
    if (!id)
        buf_puts(&msg, "null");
    else if (id->type == JSON_STRING)
        buf_put_json_string(&msg, id->string);
    else
        buf_puts(&msg, id->string); /* a number, echoed exactly as it was sent */

    if (code == 0) {
        buf_puts(&msg, ",\"result\":");
        buf_puts(&msg, body);
    } else {
        buf_printf(&msg, ",\"error\":{\"code\":%d,\"message\":", code);
        buf_put_json_string(&msg, body);
        buf_puts(&msg, "}");
    }
    buf_puts(&msg, "}\n");
    fwrite(msg.data, 1, msg.len, stdout);
    fflush(stdout);
    free(msg.data);
}

static void handle_request(const Json *id, const char *method, const Json *params) {
    Buf out = {0};
    int code;
    size_t i = 0;
    while (i < COUNT(METHODS) && strcmp(METHODS[i].name, method) != 0) i++;
    if (i < COUNT(METHODS)) {
        code = METHODS[i].handle(params, &out);
    } else {
        code = METHOD_NOT_FOUND;
        buf_printf(&out, "Method not found: %s", method);
    }
    send_response(id, code, buf_str(&out));
    free(out.data);
}

static void handle_message(const char *line) {
    Json *msg = json_parse(line);
    const Json *id = json_get(msg, "id");
    const Json *method = json_get(msg, "method");

    if (!msg)
        send_response(NULL, PARSE_ERROR, "Parse error");
    else if (msg->type != JSON_OBJECT || (method && method->type != JSON_STRING) ||
             (id && id->type != JSON_STRING && id->type != JSON_NUMBER))
        send_response(NULL, INVALID_REQUEST, "Invalid Request");
    else if (method && id)
        handle_request(id, method->string, json_get(msg, "params"));
    /* Anything else is a notification (e.g. notifications/initialized) or a
       response to a request we never sent: neither gets a reply. */
    json_free(msg);
}

int main(void) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t len;

    /* stdout carries protocol messages only; diagnostics go to stderr. */
    fputs(SERVER_NAME " " SERVER_VERSION " ready on stdio\n", stderr);
    while ((len = getline(&line, &cap, stdin)) != -1) {
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = '\0';
        if (len > 0) handle_message(line);
    }
    free(line);
    return 0;
}
