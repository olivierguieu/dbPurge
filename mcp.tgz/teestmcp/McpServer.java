/*
 * McpServer.java - a minimal Model Context Protocol (MCP) server in plain Java,
 * ported from mcp_server.c.
 *
 * It speaks JSON-RPC 2.0 over stdio, the standard MCP transport for local
 * servers: one JSON message per line on stdin, one reply per line on stdout.
 * No dependencies beyond the JDK (Java 11 or newer). It exposes three example
 * tools: echo, add and current_time.
 *
 *   Build:  make mcp_server.jar   (or skip the build and run: java McpServer.java)
 *   Try:    make demo-java
 *   Use:    claude mcp add simple-java -- java -jar /absolute/path/to/mcp_server.jar
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public final class McpServer {
    private static final String SERVER_NAME = "simple-java-mcp";
    private static final String SERVER_VERSION = "0.1.0";
    private static final int MAX_DEPTH = 64; // deepest JSON nesting we accept

    /** MCP protocol revisions this server can speak, newest first. */
    private static final List<String> PROTOCOL_VERSIONS =
            List.of("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05");

    // JSON-RPC 2.0 error codes
    private static final int PARSE_ERROR = -32700;
    private static final int INVALID_REQUEST = -32600;
    private static final int METHOD_NOT_FOUND = -32601;
    private static final int INVALID_PARAMS = -32602;

    // ------------------------------------------------------------------------
    // JSON values
    // ------------------------------------------------------------------------
    // JSON maps onto plain Java: an object is a Map (members in document order),
    // an array a List, a string a String, true/false a Boolean, null is null and
    // a number is a JsonNumber. Replies are built from the same pieces.

    /** A JSON number, kept as the literal that was sent so an id is echoed back exactly. */
    private static final class JsonNumber {
        final String literal;

        JsonNumber(String literal) {
            this.literal = literal;
        }

        double value() {
            return Double.parseDouble(literal);
        }

        @Override
        public String toString() {
            return literal;
        }
    }

    /** An object with these members, in order: object("a", 1, "b", "x") is {"a":1,"b":"x"}. */
    private static Map<String, Object> object(Object... namesAndValues) {
        var members = new LinkedHashMap<String, Object>();
        for (int i = 0; i < namesAndValues.length; i += 2)
            members.put((String) namesAndValues[i], namesAndValues[i + 1]);
        return members;
    }

    /** v if it is an object, else an empty one: a missing or malformed object reads as {}. */
    private static Map<?, ?> asObject(Object v) {
        return v instanceof Map ? (Map<?, ?>) v : Map.of();
    }

    /** v written out as compact JSON. */
    private static String toJson(Object v) {
        if (v instanceof String) return quote((String) v);
        if (v instanceof List)
            return ((List<?>) v).stream().map(McpServer::toJson).collect(Collectors.joining(",", "[", "]"));
        if (v instanceof Map)
            return ((Map<?, ?>) v).entrySet().stream()
                    .map(member -> quote((String) member.getKey()) + ":" + toJson(member.getValue()))
                    .collect(Collectors.joining(",", "{", "}"));
        return String.valueOf(v); // null, a Boolean, an Integer or a JsonNumber
    }

    /** s as a quoted, escaped JSON string. */
    private static String quote(String s) {
        var out = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' || c == '\\')
                out.append('\\').append(c);
            else if (c == '\n')
                out.append("\\n");
            else if (c == '\r')
                out.append("\\r");
            else if (c == '\t')
                out.append("\\t");
            else if (c < 0x20)
                out.append(String.format(Locale.ROOT, "\\u%04x", (int) c));
            else
                out.append(c);
        }
        return out.append('"').toString();
    }

    // ------------------------------------------------------------------------
    // Minimal JSON parser: turns one message into the values above
    // ------------------------------------------------------------------------

    private static final class JsonParser {
        private final String text;
        private int pos;   // current position in the text
        private int depth; // current array/object nesting

        private JsonParser(String text) {
            this.text = text;
        }

        /** Parses a whole JSON text; throws IllegalArgumentException if it is not valid JSON. */
        static Object parse(String text) {
            var parser = new JsonParser(text);
            Object value = parser.value();
            parser.skipSpace();
            if (parser.pos < text.length()) throw parser.invalid(); // trailing garbage
            return value;
        }

        private IllegalArgumentException invalid() {
            return new IllegalArgumentException("invalid JSON at offset " + pos);
        }

        /** The character at pos, or '\0' at the end of the text. */
        private char peek() {
            return pos < text.length() ? text.charAt(pos) : '\0';
        }

        private static boolean isDigit(char c) {
            return c >= '0' && c <= '9';
        }

        private void skipSpace() {
            while (peek() == ' ' || peek() == '\t' || peek() == '\n' || peek() == '\r') pos++;
        }

        private Object value() {
            skipSpace();
            switch (peek()) {
                case '{':
                case '[': return container();
                case '"': return string();
                case 't': return literal("true", true);
                case 'f': return literal("false", false);
                case 'n': return literal("null", null);
                default: return number();
            }
        }

        private Object literal(String word, Object value) {
            if (!text.startsWith(word, pos)) throw invalid();
            pos += word.length();
            return value;
        }

        private JsonNumber number() {
            int start = pos;
            if (peek() == '-') pos++;
            if (peek() == '0') pos++; // no leading zeros
            else digits();
            if (peek() == '.') {
                pos++;
                digits();
            }
            if (peek() == 'e' || peek() == 'E') {
                pos++;
                if (peek() == '+' || peek() == '-') pos++;
                digits();
            }
            return new JsonNumber(text.substring(start, pos));
        }

        /** Skips a run of one or more digits. */
        private void digits() {
            if (!isDigit(peek())) throw invalid();
            while (isDigit(peek())) pos++;
        }

        /** Parses a string literal; pos is at its opening quote. */
        private String string() {
            var out = new StringBuilder();
            pos++; // skip the opening quote
            for (;;) {
                if (pos == text.length()) throw invalid(); // no closing quote
                char c = text.charAt(pos++);
                if (c == '"') return out.toString();
                if (c < 0x20) throw invalid(); // control characters must be escaped
                if (c != '\\') {
                    out.append(c);
                    continue;
                }
                c = peek();
                pos++;
                switch (c) {
                    case '"':
                    case '\\':
                    case '/': out.append(c); break;
                    case 'b': out.append('\b'); break;
                    case 'f': out.append('\f'); break;
                    case 'n': out.append('\n'); break;
                    case 'r': out.append('\r'); break;
                    case 't': out.append('\t'); break;
                    case 'u': {
                        char unit = hex4();
                        if (Character.isLowSurrogate(unit)) throw invalid(); // half a pair, on its own
                        out.append(unit);
                        if (Character.isHighSurrogate(unit)) { // the other half must follow
                            if (!text.startsWith("\\u", pos)) throw invalid();
                            pos += 2;
                            char low = hex4();
                            if (!Character.isLowSurrogate(low)) throw invalid();
                            out.append(low);
                        }
                        break;
                    }
                    default: throw invalid();
                }
            }
        }

        /** The UTF-16 code unit spelled by the 4 hex digits at pos. */
        private char hex4() {
            int value = 0;
            for (int i = 0; i < 4; i++, pos++) {
                char c = peek();
                int digit = isDigit(c) ? c - '0'
                        : c >= 'a' && c <= 'f' ? c - 'a' + 10
                        : c >= 'A' && c <= 'F' ? c - 'A' + 10
                        : -1;
                if (digit < 0) throw invalid();
                value = value * 16 + digit;
            }
            return (char) value;
        }

        /** Parses an array or object; pos is at its opening bracket. */
        private Object container() {
            boolean isObject = peek() == '{';
            char close = isObject ? '}' : ']';
            var members = new LinkedHashMap<String, Object>();
            var items = new ArrayList<Object>();

            if (++depth > MAX_DEPTH) throw invalid();
            pos++; // skip the opening bracket
            skipSpace();
            if (peek() != close) {
                for (;;) {
                    if (isObject) { // "name": value
                        skipSpace();
                        if (peek() != '"') throw invalid();
                        String name = string();
                        skipSpace();
                        if (peek() != ':') throw invalid();
                        pos++;
                        Object member = value();
                        if (!members.containsKey(name)) members.put(name, member); // a repeated name keeps its first value
                    } else {
                        items.add(value());
                    }
                    skipSpace();
                    if (peek() == close) break;
                    if (peek() != ',') throw invalid();
                    pos++;
                }
            }
            pos++; // skip the closing bracket
            depth--;
            return isObject ? members : items;
        }
    }

    // ------------------------------------------------------------------------
    // Tools: add your own here
    // ------------------------------------------------------------------------

    private static final class Tool {
        final String name;
        final String description;
        final Map<String, Object> inputSchema; // JSON Schema of the arguments object
        /**
         * Gets the arguments object ({} if none was sent) and returns the tool's text
         * output, or throws an exception whose message the model then sees as an
         * error (isError: true).
         */
        final Function<Map<?, ?>, String> run;

        Tool(String name, String description, Map<String, Object> inputSchema, Function<Map<?, ?>, String> run) {
            this.name = name;
            this.description = description;
            this.inputSchema = inputSchema;
            this.run = run;
        }
    }

    private static String echo(Map<?, ?> args) {
        Object message = args.get("message");
        if (!(message instanceof String)) throw new IllegalArgumentException("'message' must be a string");
        return (String) message;
    }

    private static String add(Map<?, ?> args) {
        Object a = args.get("a"), b = args.get("b");
        if (!(a instanceof JsonNumber) || !(b instanceof JsonNumber))
            throw new IllegalArgumentException("'a' and 'b' must both be numbers");
        return formatNumber(((JsonNumber) a).value() + ((JsonNumber) b).value());
    }

    /** x the way C's printf("%.15g") writes it: 15 significant digits, without trailing zeros. */
    private static String formatNumber(double x) {
        if (Double.isNaN(x)) return "nan";
        if (Double.isInfinite(x)) return x > 0 ? "inf" : "-inf";
        if (x == 0) return Double.compare(x, 0.0) < 0 ? "-0" : "0"; // BigDecimal has no -0
        var d = new BigDecimal(x).round(new MathContext(15, RoundingMode.HALF_EVEN)).stripTrailingZeros();
        int exponent = d.precision() - d.scale() - 1; // the power of ten of the leading digit
        if (exponent >= -4 && exponent < 15) return d.toPlainString();
        // Scientific notation, as in 1.5e+20
        String digits = d.unscaledValue().abs().toString();
        String mantissa = digits.length() == 1 ? digits : digits.charAt(0) + "." + digits.substring(1);
        return (d.signum() < 0 ? "-" : "") + mantissa + String.format(Locale.ROOT, "e%+03d", exponent);
    }

    private static String currentTime(Map<?, ?> args) {
        return ZonedDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z"));
    }

    private static final List<Tool> TOOLS = List.of(
            new Tool("echo", "Echo a message back unchanged.",
                    object("type", "object",
                            "properties", object("message", object("type", "string", "description", "Text to echo back")),
                            "required", List.of("message")),
                    McpServer::echo),
            new Tool("add", "Add two numbers and return the sum.",
                    object("type", "object",
                            "properties", object("a", object("type", "number"), "b", object("type", "number")),
                            "required", List.of("a", "b")),
                    McpServer::add),
            new Tool("current_time", "Get the current local date and time of the machine running this server.",
                    object("type", "object", "properties", object()),
                    McpServer::currentTime));

    // ------------------------------------------------------------------------
    // MCP methods
    // ------------------------------------------------------------------------

    /** A JSON-RPC error, sent back in place of a result. */
    @SuppressWarnings("serial") // never serialized
    private static final class RpcError extends Exception {
        final int code;

        RpcError(int code, String message) {
            super(message);
            this.code = code;
        }
    }

    /** A method returns its JSON result, or throws RpcError. */
    private interface Method {
        Object handle(Map<?, ?> params) throws RpcError;
    }

    private static Map<String, Object> initialize(Map<?, ?> params) {
        // Echo the client's protocol version if we know it, else offer our newest.
        Object wanted = params.get("protocolVersion");
        String version = wanted instanceof String && PROTOCOL_VERSIONS.contains(wanted)
                ? (String) wanted
                : PROTOCOL_VERSIONS.get(0);
        return object("protocolVersion", version,
                "capabilities", object("tools", object()),
                "serverInfo", object("name", SERVER_NAME, "version", SERVER_VERSION));
    }

    private static Map<String, Object> ping(Map<?, ?> params) {
        return object();
    }

    private static Map<String, Object> toolsList(Map<?, ?> params) { // no pagination: every tool fits in one page
        var tools = new ArrayList<Object>();
        for (Tool tool : TOOLS)
            tools.add(object("name", tool.name, "description", tool.description, "inputSchema", tool.inputSchema));
        return object("tools", tools);
    }

    private static Map<String, Object> toolsCall(Map<?, ?> params) throws RpcError {
        Object name = params.get("name");
        Tool tool = TOOLS.stream().filter(t -> t.name.equals(name)).findFirst()
                .orElseThrow(() -> new RpcError(INVALID_PARAMS,
                        "Unknown tool: " + (name instanceof String ? name : "(no name given)")));

        String text;
        boolean isError;
        try {
            text = tool.run.apply(asObject(params.get("arguments")));
            isError = false;
        } catch (RuntimeException e) {
            text = e.getMessage() != null ? e.getMessage() : e.toString();
            isError = true;
        }
        return object("content", List.of(object("type", "text", "text", text)), "isError", isError);
    }

    private static final Map<String, Method> METHODS = Map.of(
            "initialize", McpServer::initialize,
            "ping", McpServer::ping,
            "tools/list", McpServer::toolsList,
            "tools/call", McpServer::toolsCall);

    // ------------------------------------------------------------------------
    // JSON-RPC over stdio
    // ------------------------------------------------------------------------

    /** The reply to one message, or null if it gets none. */
    private static Map<String, Object> handleMessage(String line) {
        Object msg;
        try {
            msg = JsonParser.parse(line);
        } catch (IllegalArgumentException e) {
            return errorReply(null, PARSE_ERROR, "Parse error");
        }
        Map<?, ?> fields = asObject(msg);
        Object id = fields.get("id"), method = fields.get("method");
        if (!(msg instanceof Map) || (fields.containsKey("method") && !(method instanceof String))
                || (fields.containsKey("id") && !(id instanceof String) && !(id instanceof JsonNumber)))
            return errorReply(null, INVALID_REQUEST, "Invalid Request");
        if (method != null && id != null)
            return handleRequest(id, (String) method, asObject(fields.get("params")));
        // Anything else is a notification (e.g. notifications/initialized) or a
        // response to a request we never sent: neither gets a reply.
        return null;
    }

    private static Map<String, Object> handleRequest(Object id, String method, Map<?, ?> params) {
        Method handler = METHODS.get(method);
        if (handler == null) return errorReply(id, METHOD_NOT_FOUND, "Method not found: " + method);
        try {
            return object("jsonrpc", "2.0", "id", id, "result", handler.handle(params));
        } catch (RpcError e) {
            return errorReply(id, e.code, e.getMessage());
        }
    }

    /** An error reply; a null id is sent as null. */
    private static Map<String, Object> errorReply(Object id, int code, String message) {
        return object("jsonrpc", "2.0", "id", id, "error", object("code", code, "message", message));
    }

    public static void main(String[] args) throws IOException {
        // stdout carries protocol messages only: keep it for them, and point
        // System.out at stderr so a stray print (from a tool, say) can't corrupt it.
        Writer out = new BufferedWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8));
        System.setOut(System.err);
        var in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

        System.err.println(SERVER_NAME + " " + SERVER_VERSION + " ready on stdio");
        String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue;
            Map<String, Object> reply = handleMessage(line);
            if (reply != null) {
                out.write(toJson(reply) + "\n");
                out.flush();
            }
        }
    }
}
