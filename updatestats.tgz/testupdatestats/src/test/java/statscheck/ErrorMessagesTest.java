package statscheck;

import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertTrue;

class ErrorMessagesTest {

    @Test
    void suggestsGrantForPermissionDeniedOnKnownCatalogTable() {
        SQLException e = new SQLException("Permission denied on object sysstatistics, database mydb, owner dbo.");

        assertTrue(ErrorMessages.explain(e, "alice").contains("grant select on sysstatistics to alice;"));
    }

    @Test
    void fallsBackToAllCatalogTablesWhenObjectNotExtractable() {
        SQLException e = new SQLException("Permission denied.");

        String hint = ErrorMessages.explain(e, "alice");
        assertTrue(hint.contains("grant select on sysobjects to alice;"));
        assertTrue(hint.contains("grant select on sysstatistics to alice;"));
    }

    @Test
    void recognizesUnknownServerHostMessage() {
        // Regression test: jTDS's actual message is "Unknown server host name '...'.",
        // which does NOT contain the substring "unknown host" -- caught by manual testing
        // against the real jar, not by reasoning about it up front.
        SQLException e = new SQLException("Unknown server host name 'nonexistent.invalid.test'.");

        assertTrue(ErrorMessages.explain(e, "alice").contains("Could not reach the server"));
    }

    @Test
    void fallsBackToGenericHintForUnrecognizedMessage() {
        SQLException e = new SQLException("Some other driver failure.");

        assertTrue(ErrorMessages.explain(e, "alice").contains("Check --host/--port"));
    }
}
