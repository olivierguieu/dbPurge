package statscheck.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StatsRowTest {

    private static final IndexInfo INDEX = new IndexInfo(1, "orders", "ix_orders_composite", 2, 2);
    private static final LocalDate TODAY = LocalDate.of(2026, 8, 5);

    @Test
    void noStatsWhenAnyColumnNeverComputed() {
        List<ColumnStats> columns = Arrays.asList(
                new ColumnStats(1, "customer_id", TODAY.minusDays(1).atStartOfDay(), 1.0),
                new ColumnStats(2, "order_date", null, null));

        StatsRow row = StatsRow.classify(INDEX, columns, 7, 20.0, TODAY);

        assertEquals(StatsStatus.NO_STATS, row.getStatus());
    }

    @Test
    void staleWhenOldestColumnExceedsDaysThreshold() {
        List<ColumnStats> columns = Collections.singletonList(
                new ColumnStats(1, "customer_id", TODAY.minusDays(10).atStartOfDay(), 2.0));

        StatsRow row = StatsRow.classify(INDEX, columns, 7, 20.0, TODAY);

        assertEquals(StatsStatus.STALE, row.getStatus());
    }

    @Test
    void okAtExactDaysBoundary() {
        // daysSince == staleDays is strictly-greater semantics -> OK, not STALE.
        List<ColumnStats> columns = Collections.singletonList(
                new ColumnStats(1, "customer_id", TODAY.minusDays(7).atStartOfDay(), 2.0));

        StatsRow row = StatsRow.classify(INDEX, columns, 7, 20.0, TODAY);

        assertEquals(StatsStatus.OK, row.getStatus());
    }

    @Test
    void staleWhenNonOldestColumnExceedsPctThreshold() {
        // The oldest column, in isolation, passes both thresholds (5 days < 7, 2% < 20%).
        // A different, more-recently-updated column has an extreme datachange%. Status must
        // still come back STALE -- this is the composite-index blind spot the design fixed:
        // deriving status from only the "representative" (oldest) column would miss it.
        List<ColumnStats> columns = Arrays.asList(
                new ColumnStats(1, "customer_id", TODAY.minusDays(5).atStartOfDay(), 2.0),
                new ColumnStats(2, "order_date", TODAY.minusDays(2).atStartOfDay(), 150.0));

        StatsRow row = StatsRow.classify(INDEX, columns, 7, 20.0, TODAY);

        assertEquals(StatsStatus.STALE, row.getStatus());
        assertEquals("customer_id", row.getOldestColumn().getColumnName());
        assertEquals("order_date", row.getMostChangedColumn().getColumnName());
    }

    @Test
    void oldestAndMostChangedCanBeTheSameColumn() {
        List<ColumnStats> columns = Arrays.asList(
                new ColumnStats(1, "customer_id", TODAY.minusDays(10).atStartOfDay(), 50.0),
                new ColumnStats(2, "order_date", TODAY.minusDays(1).atStartOfDay(), 5.0));

        StatsRow row = StatsRow.classify(INDEX, columns, 7, 20.0, TODAY);

        assertEquals("customer_id", row.getOldestColumn().getColumnName());
        assertEquals("customer_id", row.getMostChangedColumn().getColumnName());
        assertEquals(StatsStatus.STALE, row.getStatus());
    }
}
