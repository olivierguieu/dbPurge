package statscheck.cli;

import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PasswordResolverTest {

    @Test
    void cliValueWinsOverEnv() {
        Map<String, String> env = new HashMap<>();
        env.put(PasswordResolver.ENV_VAR, "fromEnv");

        assertEquals("fromCli", PasswordResolver.resolve("fromCli", env));
    }

    @Test
    void fallsBackToEnvWhenCliValueOmitted() {
        Map<String, String> env = new HashMap<>();
        env.put(PasswordResolver.ENV_VAR, "fromEnv");

        assertEquals("fromEnv", PasswordResolver.resolve(null, env));
    }

    @Test
    void throwsWhenNeitherProvided() {
        assertThrows(ConfigException.class, () -> PasswordResolver.resolve(null, Collections.emptyMap()));
    }
}
