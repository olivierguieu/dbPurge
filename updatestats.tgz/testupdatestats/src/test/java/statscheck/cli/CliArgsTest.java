package statscheck.cli;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CliArgsTest {

    @Test
    void parsesRequiredFlagsWithDefaults() {
        CliArgs args = CliArgs.parse(new String[] {
                "--host", "dbhost", "--port", "7100", "--database", "mydb", "--user", "alice"
        });

        assertEquals("dbhost", args.getHost());
        assertEquals(7100, args.getPort());
        assertEquals("mydb", args.getDatabase());
        assertEquals("alice", args.getUser());
        assertEquals(7, args.getStaleDays());
        assertEquals(20.0, args.getStalePct());
        assertFalse(args.isCsv());
        assertFalse(args.isVerbose());
        assertFalse(args.isHelp());
    }

    @Test
    void acceptsFlagEqualsValueForm() {
        CliArgs args = CliArgs.parse(new String[] {
                "--host=dbhost", "--port=7100", "--database=mydb", "--user=alice",
                "--stale-days=14", "--stale-pct=10.5", "--csv"
        });

        assertEquals("dbhost", args.getHost());
        assertEquals(7100, args.getPort());
        assertEquals(14, args.getStaleDays());
        assertEquals(10.5, args.getStalePct());
        assertTrue(args.isCsv());
    }

    @Test
    void missingRequiredFlagThrows() {
        assertThrows(ConfigException.class, () -> CliArgs.parse(new String[] {
                "--port", "7100", "--database", "mydb", "--user", "alice"
        }));
    }

    @Test
    void nonNumericPortThrows() {
        assertThrows(ConfigException.class, () -> CliArgs.parse(new String[] {
                "--host", "dbhost", "--port", "notanumber", "--database", "mydb", "--user", "alice"
        }));
    }

    @Test
    void unknownFlagThrows() {
        assertThrows(ConfigException.class, () -> CliArgs.parse(new String[] {
                "--host", "dbhost", "--port", "7100", "--database", "mydb", "--user", "alice",
                "--bogus", "value"
        }));
    }

    @Test
    void helpFlagShortCircuitsRequiredFlagValidation() {
        assertTrue(CliArgs.parse(new String[] { "--help" }).isHelp());
        assertTrue(CliArgs.parse(new String[] { "-h" }).isHelp());
    }
}
