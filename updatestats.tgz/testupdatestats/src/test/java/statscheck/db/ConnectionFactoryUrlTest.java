package statscheck.db;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConnectionFactoryUrlTest {

    @Test
    void includesRequiredSybaseProtocolAndPrepareSqlSettings() {
        String url = ConnectionFactory.buildJdbcUrl("dbhost", 7100, "mydb", null);

        assertTrue(url.startsWith("jdbc:jtds:sybase://dbhost:7100/mydb"));
        assertTrue(url.contains("TDS=5.0"));
        assertTrue(url.contains("prepareSQL=0"));
        assertFalse(url.contains("charset="));
    }

    @Test
    void appendsCharsetWhenProvided() {
        String url = ConnectionFactory.buildJdbcUrl("dbhost", 7100, "mydb", "iso_1");

        assertTrue(url.contains("charset=iso_1"));
    }
}
