package statscheck.db;

import statscheck.model.ColumnStats;
import statscheck.model.IndexInfo;
import statscheck.model.StatsRow;

import java.io.PrintStream;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Orchestrates the DAO calls needed to turn raw catalog data into classified,
 * sorted report rows. Per-column failures to resolve a name, a last-updated
 * date, or a datachange() percentage are non-fatal: they're logged to
 * {@code warnings} and the run continues with that piece recorded as unknown
 * (which folds into NO_STATS/STALE via StatsRow.classify -- unknown never
 * silently reads as "fine").
 */
public final class StatsReportBuilder {

    private final StatsCatalogDao dao;
    private final PrintStream warnings;

    public StatsReportBuilder(StatsCatalogDao dao, PrintStream warnings) {
        this.dao = dao;
        this.warnings = warnings;
    }

    public List<StatsRow> build(String tableNameLikePattern, int staleDays, double stalePct) throws SQLException {
        LocalDate today = LocalDate.now();
        List<StatsRow> rows = new ArrayList<>();

        for (IndexInfo idx : dao.listIndexes(tableNameLikePattern)) {
            List<ColumnStats> columns = new ArrayList<>();

            for (int keyPos = 1; keyPos <= idx.getKeyCount(); keyPos++) {
                columns.add(observeColumn(idx, keyPos));
            }

            rows.add(StatsRow.classify(idx, columns, staleDays, stalePct, today));
        }

        rows.sort(Comparator.comparingInt((StatsRow r) -> r.getStatus().sortRank())
                .thenComparing(r -> r.getOldestColumn().getLastUpdated(), Comparator.nullsFirst(Comparator.naturalOrder()))
                .thenComparing(r -> r.getIndex().getTableName())
                .thenComparing(r -> r.getIndex().getIndexName()));
        return rows;
    }

    private ColumnStats observeColumn(IndexInfo idx, int keyPos) throws SQLException {
        String columnName;
        try {
            columnName = dao.resolveColumnName(idx.getTableName(), idx.getIndexId(), keyPos);
        } catch (SQLException e) {
            warnings.println("warning: could not resolve column name for " + idx.getTableName()
                    + "." + idx.getIndexName() + " key position " + keyPos
                    + " (" + e.getMessage() + ") -- treating as never-computed");
            return new ColumnStats(keyPos, null, null, null);
        }

        if (columnName == null) {
            warnings.println("warning: index_col() returned no column for " + idx.getTableName()
                    + "." + idx.getIndexName() + " key position " + keyPos + " -- treating as never-computed");
            return new ColumnStats(keyPos, null, null, null);
        }

        LocalDateTime lastUpdated = null;
        try {
            lastUpdated = dao.findLastUpdated(idx.getTableId(), columnName);
        } catch (SQLException e) {
            warnings.println("warning: last-updated lookup failed for " + idx.getTableName()
                    + "." + columnName + " (" + e.getMessage() + ") -- treating as never-computed");
        }

        Double pctChanged = null;
        try {
            pctChanged = dao.getPercentChanged(idx.getTableName(), columnName);
        } catch (SQLException e) {
            warnings.println("warning: pct-changed unavailable for " + idx.getTableName()
                    + "." + columnName + " (" + e.getMessage() + ") -- recorded as N/A");
        }

        return new ColumnStats(keyPos, columnName, lastUpdated, pctChanged);
    }
}
