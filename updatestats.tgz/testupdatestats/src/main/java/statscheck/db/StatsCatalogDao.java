package statscheck.db;

import statscheck.model.IndexInfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Direct catalog access, one method per query. Each method executes exactly
 * one statement and throws SQLException on any failure -- deciding whether a
 * given failure is fatal or best-effort is StatsReportBuilder's job, not this
 * class's. No query here nests a function call inside another query's WHERE
 * clause (e.g. "WHERE c.name = index_col(...)"): ASE's support for that shape
 * was never independently verified, so every function result (index_col(),
 * datachange()) is fetched as its own scalar value and passed back in as a
 * plain bind parameter instead.
 */
public final class StatsCatalogDao {

    private final Connection connection;

    public StatsCatalogDao(Connection connection) {
        this.connection = connection;
    }

    /** Every real index (indid 1-254) on every user table, optionally filtered by table name. */
    public List<IndexInfo> listIndexes(String tableNameLikePattern) throws SQLException {
        String sql = "SELECT o.id AS table_id, o.name AS table_name, i.name AS index_name, "
                + "i.indid AS index_id, i.keycnt AS key_count "
                + "FROM sysindexes i JOIN sysobjects o ON o.id = i.id "
                + "WHERE o.type = 'U' AND i.indid BETWEEN 1 AND 254"
                + (tableNameLikePattern != null ? " AND o.name LIKE ?" : "")
                + " ORDER BY o.name, i.indid";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            if (tableNameLikePattern != null) {
                ps.setString(1, tableNameLikePattern);
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<IndexInfo> result = new ArrayList<>();
                while (rs.next()) {
                    result.add(new IndexInfo(
                            rs.getInt("table_id"), rs.getString("table_name"),
                            rs.getString("index_name"), rs.getInt("index_id"),
                            rs.getInt("key_count")));
                }
                return result;
            }
        }
    }

    /** Column name at a given 1-based key position of an index, via the official index_col() builtin. */
    public String resolveColumnName(String tableName, int indexId, int keyPosition) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT index_col(?, ?, ?) AS column_name")) {
            ps.setString(1, tableName);
            ps.setInt(2, indexId);
            ps.setInt(3, keyPosition);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next(); // SELECT of a scalar expression always returns exactly one row
                return rs.getString("column_name");
            }
        }
    }

    /** Last time sysstatistics recorded a refresh for this column's histogram/density row(s), or null if never. */
    public LocalDateTime findLastUpdated(int tableId, String columnName) throws SQLException {
        String sql = "SELECT (SELECT MAX(s.moddate) FROM sysstatistics s "
                + "WHERE s.id = c.id AND convert(smallint, substring(s.colidarray,1,2)) = c.colid) AS last_updated "
                + "FROM syscolumns c WHERE c.id = ? AND c.name = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, tableId);
            ps.setString(2, columnName);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                // getTimestamp(...).toLocalDateTime(), never getObject(.., LocalDateTime.class):
                // jTDS 1.3.1 predates reliable JSR-310 driver support.
                Timestamp ts = rs.getTimestamp("last_updated");
                return ts == null ? null : ts.toLocalDateTime();
            }
        }
    }

    /**
     * Percentage of inserts/updates/deletes on this column since its last update statistics.
     * datachange() can return SQL NULL without throwing; ResultSet.getDouble on a NULL silently
     * reads as 0.0, which would misclassify unknown staleness as "0% changed" -- so a NULL result
     * is turned into a thrown SQLException here, same failure path as a genuine driver error.
     */
    public double getPercentChanged(String tableName, String columnName) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT datachange(?, NULL, ?) AS pct_changed")) {
            ps.setString(1, tableName);
            ps.setString(2, columnName);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                double pct = rs.getDouble("pct_changed");
                if (rs.wasNull()) {
                    throw new SQLException("datachange() returned NULL for " + tableName + "." + columnName);
                }
                return pct;
            }
        }
    }
}
