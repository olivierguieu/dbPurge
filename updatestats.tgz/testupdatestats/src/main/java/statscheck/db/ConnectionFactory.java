package statscheck.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConnectionFactory {

    private static final String DRIVER_CLASS = "net.sourceforge.jtds.jdbc.Driver";

    static {
        try {
            Class.forName(DRIVER_CLASS);
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("jTDS driver not found on classpath: " + DRIVER_CLASS, e);
        }
    }

    private ConnectionFactory() {
    }

    public static Connection connect(String host, int port, String database, String user,
                                      String password, String charset) throws SQLException {
        return DriverManager.getConnection(buildJdbcUrl(host, port, database, charset), user, password);
    }

    /**
     * prepareSQL=0 forces literal-substitution parameter binding instead of jTDS's default
     * (for Sybase) temp-stored-procedure-based PreparedStatement implementation, which needs
     * CREATE PROC/tempdb rights a restricted non-DBA login may not have.
     */
    static String buildJdbcUrl(String host, int port, String database, String charset) {
        StringBuilder url = new StringBuilder("jdbc:jtds:sybase://")
                .append(host).append(':').append(port).append('/').append(database)
                .append(";TDS=5.0;prepareSQL=0");
        if (charset != null && !charset.isEmpty()) {
            url.append(";charset=").append(charset);
        }
        return url.toString();
    }
}
