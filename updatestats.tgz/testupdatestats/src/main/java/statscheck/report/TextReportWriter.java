package statscheck.report;

import statscheck.model.ColumnStats;
import statscheck.model.StatsRow;

import java.io.PrintStream;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public final class TextReportWriter implements ReportWriter {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.ROOT);
    private static final String[] HEADERS = {
            "TABLE", "INDEX", "OLDEST STATS COLUMN", "LAST UPDATED", "DAYS AGO",
            "MOST CHANGED COLUMN", "PCT CHANGED", "STATUS"
    };

    @Override
    public void write(List<StatsRow> rows, PrintStream out) {
        if (rows.isEmpty()) {
            out.println("No matching indexes found.");
            return;
        }

        String[][] cells = new String[rows.size()][];
        for (int i = 0; i < rows.size(); i++) {
            cells[i] = toCells(rows.get(i));
        }

        int[] widths = new int[HEADERS.length];
        for (int col = 0; col < HEADERS.length; col++) {
            widths[col] = HEADERS[col].length();
            for (String[] row : cells) {
                widths[col] = Math.max(widths[col], row[col].length());
            }
        }

        printRow(out, HEADERS, widths);
        printSeparator(out, widths);
        for (String[] row : cells) {
            printRow(out, row, widths);
        }
    }

    private String[] toCells(StatsRow row) {
        ColumnStats oldest = row.getOldestColumn();
        ColumnStats mostChanged = row.getMostChangedColumn();
        return new String[] {
                row.getIndex().getTableName(),
                row.getIndex().getIndexName(),
                oldest.getColumnName() == null ? "?" : oldest.getColumnName(),
                oldest.getLastUpdated() == null ? "NEVER" : DATE_FORMAT.format(oldest.getLastUpdated()),
                row.getOldestColumnDaysAgo() == null ? "-" : String.valueOf(row.getOldestColumnDaysAgo()),
                mostChanged.getColumnName() == null ? "?" : mostChanged.getColumnName(),
                mostChanged.getPctChanged() == null ? "N/A" : String.format(Locale.ROOT, "%.1f%%", mostChanged.getPctChanged()),
                row.getStatus().name()
        };
    }

    private void printRow(PrintStream out, String[] values, int[] widths) {
        StringBuilder line = new StringBuilder();
        for (int col = 0; col < values.length; col++) {
            if (col > 0) {
                line.append("  ");
            }
            line.append(pad(values[col], widths[col]));
        }
        out.println(line.toString());
    }

    private void printSeparator(PrintStream out, int[] widths) {
        StringBuilder line = new StringBuilder();
        for (int col = 0; col < widths.length; col++) {
            if (col > 0) {
                line.append("  ");
            }
            for (int i = 0; i < widths[col]; i++) {
                line.append('-');
            }
        }
        out.println(line.toString());
    }

    private String pad(String value, int width) {
        StringBuilder sb = new StringBuilder(value);
        while (sb.length() < width) {
            sb.append(' ');
        }
        return sb.toString();
    }
}
