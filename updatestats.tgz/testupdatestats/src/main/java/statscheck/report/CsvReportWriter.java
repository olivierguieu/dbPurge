package statscheck.report;

import statscheck.model.ColumnStats;
import statscheck.model.StatsRow;

import java.io.PrintStream;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public final class CsvReportWriter implements ReportWriter {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.ROOT);
    private static final String[] HEADERS = {
            "table", "index", "oldest_stats_column", "last_updated", "days_ago",
            "most_changed_column", "pct_changed", "status"
    };

    @Override
    public void write(List<StatsRow> rows, PrintStream out) {
        out.println(String.join(",", HEADERS));
        for (StatsRow row : rows) {
            out.println(String.join(",", toCells(row)));
        }
    }

    private String[] toCells(StatsRow row) {
        ColumnStats oldest = row.getOldestColumn();
        ColumnStats mostChanged = row.getMostChangedColumn();
        return new String[] {
                escape(row.getIndex().getTableName()),
                escape(row.getIndex().getIndexName()),
                escape(oldest.getColumnName()),
                oldest.getLastUpdated() == null ? "" : DATE_FORMAT.format(oldest.getLastUpdated()),
                row.getOldestColumnDaysAgo() == null ? "" : String.valueOf(row.getOldestColumnDaysAgo()),
                escape(mostChanged.getColumnName()),
                mostChanged.getPctChanged() == null ? "" : String.format(Locale.ROOT, "%.1f", mostChanged.getPctChanged()),
                row.getStatus().name()
        };
    }

    private String escape(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
