package statscheck.report;

import statscheck.model.StatsRow;

import java.io.PrintStream;
import java.util.List;

public interface ReportWriter {
    void write(List<StatsRow> rows, PrintStream out);
}
