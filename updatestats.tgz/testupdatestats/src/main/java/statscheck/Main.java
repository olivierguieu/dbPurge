package statscheck;

import statscheck.cli.CliArgs;
import statscheck.cli.ConfigException;
import statscheck.cli.PasswordResolver;
import statscheck.db.ConnectionFactory;
import statscheck.db.StatsCatalogDao;
import statscheck.db.StatsReportBuilder;
import statscheck.model.StatsRow;
import statscheck.report.CsvReportWriter;
import statscheck.report.ReportWriter;
import statscheck.report.TextReportWriter;

import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public final class Main {

    private static final String USAGE =
            "Usage: statscheck --host <host> --port <port> --database <db> --user <user>\n"
          + "                   [--password <pwd> | env STATSCHECK_PASSWORD]\n"
          + "                   [--table <like-pattern>] [--stale-days <n>] [--stale-pct <n>]\n"
          + "                   [--csv] [--charset <name>] [--verbose]\n\n"
          + "Reports the last time column statistics were refreshed for every index in the\n"
          + "target database, to help find statistics that need `update statistics`.\n\n"
          + "  --host <hostname>       Sybase ASE server host (required)\n"
          + "  --port <port>           Sybase ASE server port (required, no default)\n"
          + "  --database <name>       Target database -- single database per run (required)\n"
          + "  --user <login>          Login name (required)\n"
          + "  --password <value>      Password. Falls back to STATSCHECK_PASSWORD env var if omitted.\n"
          + "                          Visible in shell history / process listing -- use the env var\n"
          + "                          instead if that matters for your environment.\n"
          + "  --table <pattern>       Only check tables matching this SQL LIKE pattern (default: all)\n"
          + "  --stale-days <n>        Flag STALE if any key column's stats are older than n days\n"
          + "                          (default 7 -- a heuristic starting point, not an ASE constant)\n"
          + "  --stale-pct <n>         Flag STALE if any key column's datachange() exceeds n percent\n"
          + "                          (default 20 -- a heuristic starting point, not an ASE constant)\n"
          + "  --csv                   Emit CSV instead of an aligned text table\n"
          + "  --charset <name>        JDBC charset override (e.g. iso_1), only if you hit charset errors\n"
          + "  --verbose               Print per-column lookup warnings to stderr\n"
          + "  --help, -h              Show this message\n";

    public static void main(String[] args) {
        CliArgs cliArgs;
        try {
            cliArgs = CliArgs.parse(args);
        } catch (ConfigException e) {
            System.err.println("Error: " + e.getMessage());
            System.err.println();
            System.err.println(USAGE);
            System.exit(2);
            return;
        }

        if (cliArgs.isHelp()) {
            System.out.println(USAGE);
            System.exit(0);
            return;
        }

        String password;
        try {
            password = PasswordResolver.resolve(cliArgs.getPassword(), System.getenv());
        } catch (ConfigException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(2);
            return;
        }

        int exitCode;
        try (Connection connection = ConnectionFactory.connect(
                cliArgs.getHost(), cliArgs.getPort(), cliArgs.getDatabase(),
                cliArgs.getUser(), password, cliArgs.getCharset())) {

            StatsCatalogDao dao = new StatsCatalogDao(connection);
            PrintStream warnings = cliArgs.isVerbose() ? System.err : silentPrintStream();
            StatsReportBuilder builder = new StatsReportBuilder(dao, warnings);

            List<StatsRow> rows = builder.build(cliArgs.getTablePattern(), cliArgs.getStaleDays(), cliArgs.getStalePct());

            ReportWriter writer = cliArgs.isCsv() ? new CsvReportWriter() : new TextReportWriter();
            writer.write(rows, System.out);

            exitCode = 0;
        } catch (SQLException e) {
            System.err.println(ErrorMessages.explain(e, cliArgs.getUser()));
            exitCode = 1;
        }
        // try-with-resources has already closed the connection by this point,
        // whichever branch set exitCode -- System.exit() runs after, not inside, the block.
        System.exit(exitCode);
    }

    private static PrintStream silentPrintStream() {
        return new PrintStream(new OutputStream() {
            @Override
            public void write(int b) {
                // discarded -- only used when --verbose is off
            }
        });
    }
}
