package statscheck.model;

public final class IndexInfo {

    private final int tableId;
    private final String tableName;
    private final String indexName;
    private final int indexId;
    private final int keyCount;

    public IndexInfo(int tableId, String tableName, String indexName, int indexId, int keyCount) {
        this.tableId = tableId;
        this.tableName = tableName;
        this.indexName = indexName;
        this.indexId = indexId;
        this.keyCount = keyCount;
    }

    public int getTableId() {
        return tableId;
    }

    public String getTableName() {
        return tableName;
    }

    public String getIndexName() {
        return indexName;
    }

    public int getIndexId() {
        return indexId;
    }

    public int getKeyCount() {
        return keyCount;
    }
}
