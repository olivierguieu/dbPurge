package statscheck.model;

public enum StatsStatus {
    NO_STATS(0),
    STALE(1),
    OK(2);

    private final int sortRank;

    StatsStatus(int sortRank) {
        this.sortRank = sortRank;
    }

    public int sortRank() {
        return sortRank;
    }
}
