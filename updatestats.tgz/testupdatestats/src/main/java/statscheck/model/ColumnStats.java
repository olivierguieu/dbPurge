package statscheck.model;

import java.time.LocalDateTime;

/**
 * Statistics observation for a single key column of an index: when its
 * statistics were last refreshed, and how much data has changed since.
 */
public final class ColumnStats {

    private final int keyPosition;
    private final String columnName;
    private final LocalDateTime lastUpdated;
    private final Double pctChanged;

    public ColumnStats(int keyPosition, String columnName, LocalDateTime lastUpdated, Double pctChanged) {
        this.keyPosition = keyPosition;
        this.columnName = columnName;
        this.lastUpdated = lastUpdated;
        this.pctChanged = pctChanged;
    }

    public int getKeyPosition() {
        return keyPosition;
    }

    public String getColumnName() {
        return columnName;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public Double getPctChanged() {
        return pctChanged;
    }
}
