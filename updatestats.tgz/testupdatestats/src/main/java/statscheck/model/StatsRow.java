package statscheck.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.List;

/**
 * One report row: an index, its two representative columns (oldest stats,
 * most changed), and a status derived from ALL of its key columns.
 *
 * Status is intentionally NOT derived from either representative column alone:
 * on a composite index the oldest-by-date column and the most-changed-by-percent
 * column can differ, and picking just one for status would silently hide staleness
 * on the other.
 */
public final class StatsRow {

    private final IndexInfo index;
    private final ColumnStats oldestColumn;
    private final ColumnStats mostChangedColumn;
    private final Long oldestColumnDaysAgo;
    private final StatsStatus status;

    public StatsRow(IndexInfo index, ColumnStats oldestColumn, ColumnStats mostChangedColumn,
                     Long oldestColumnDaysAgo, StatsStatus status) {
        this.index = index;
        this.oldestColumn = oldestColumn;
        this.mostChangedColumn = mostChangedColumn;
        this.oldestColumnDaysAgo = oldestColumnDaysAgo;
        this.status = status;
    }

    public static StatsRow classify(IndexInfo index, List<ColumnStats> columns,
                                     int staleDays, double stalePct, LocalDate today) {
        ColumnStats oldest = columns.stream()
                .min(Comparator.comparing(ColumnStats::getLastUpdated,
                        Comparator.nullsFirst(Comparator.naturalOrder())))
                .get();
        ColumnStats mostChanged = columns.stream()
                .max(Comparator.comparingDouble(c -> c.getPctChanged() == null ? -1.0 : c.getPctChanged()))
                .get();

        boolean noStats = columns.stream().anyMatch(c -> c.getLastUpdated() == null);
        boolean stale = !noStats && columns.stream().anyMatch(c ->
                daysBetween(c.getLastUpdated(), today) > staleDays
                        || (c.getPctChanged() != null && c.getPctChanged() > stalePct));

        StatsStatus status = noStats ? StatsStatus.NO_STATS : stale ? StatsStatus.STALE : StatsStatus.OK;
        // Computed once here, against the same `today` used for status, rather than letting
        // display code call LocalDate.now() again later -- keeps DAYS AGO and STATUS from a
        // long-running scan ever disagreeing if the run straddles local midnight.
        Long oldestColumnDaysAgo = oldest.getLastUpdated() == null ? null : daysBetween(oldest.getLastUpdated(), today);
        return new StatsRow(index, oldest, mostChanged, oldestColumnDaysAgo, status);
    }

    private static long daysBetween(LocalDateTime lastUpdated, LocalDate today) {
        return ChronoUnit.DAYS.between(lastUpdated.toLocalDate(), today);
    }

    public IndexInfo getIndex() {
        return index;
    }

    public ColumnStats getOldestColumn() {
        return oldestColumn;
    }

    public ColumnStats getMostChangedColumn() {
        return mostChangedColumn;
    }

    /** Days between oldestColumn's last-updated and the `today` used at classification time; null if never computed. */
    public Long getOldestColumnDaysAgo() {
        return oldestColumnDaysAgo;
    }

    public StatsStatus getStatus() {
        return status;
    }
}
