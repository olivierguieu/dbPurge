package statscheck.cli;

/** Bad CLI input or an unresolvable password -- a usage error, not a runtime failure. */
public final class ConfigException extends RuntimeException {

    public ConfigException(String message) {
        super(message);
    }
}
