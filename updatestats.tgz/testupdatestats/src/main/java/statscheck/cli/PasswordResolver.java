package statscheck.cli;

import java.util.Map;

/**
 * Password precedence: --password flag first, then the STATSCHECK_PASSWORD
 * env var (for scripted/cron use without putting it on the command line).
 */
public final class PasswordResolver {

    public static final String ENV_VAR = "STATSCHECK_PASSWORD";

    private PasswordResolver() {
    }

    public static String resolve(String cliValue, Map<String, String> env) {
        if (cliValue != null) {
            return cliValue;
        }
        String fromEnv = env.get(ENV_VAR);
        if (fromEnv != null) {
            return fromEnv;
        }
        throw new ConfigException("No --password given and " + ENV_VAR + " is not set.");
    }
}
