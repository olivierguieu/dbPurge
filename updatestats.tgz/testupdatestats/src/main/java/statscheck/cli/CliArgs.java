package statscheck.cli;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Pure CLI flag parser: String[] in, immutable config out. No I/O, no env/console access. */
public final class CliArgs {

    private static final Set<String> KNOWN_VALUE_FLAGS = new HashSet<>(Arrays.asList(
            "--host", "--port", "--database", "--user", "--password",
            "--table", "--stale-days", "--stale-pct", "--charset"));
    private static final Set<String> KNOWN_BOOLEAN_FLAGS = new HashSet<>(Arrays.asList(
            "--csv", "--verbose", "--help", "-h"));

    private final String host;
    private final int port;
    private final String database;
    private final String user;
    private final String password;
    private final String tablePattern;
    private final int staleDays;
    private final double stalePct;
    private final boolean csv;
    private final String charset;
    private final boolean verbose;
    private final boolean help;

    private CliArgs(String host, int port, String database, String user, String password,
                     String tablePattern, int staleDays, double stalePct, boolean csv,
                     String charset, boolean verbose, boolean help) {
        this.host = host;
        this.port = port;
        this.database = database;
        this.user = user;
        this.password = password;
        this.tablePattern = tablePattern;
        this.staleDays = staleDays;
        this.stalePct = stalePct;
        this.csv = csv;
        this.charset = charset;
        this.verbose = verbose;
        this.help = help;
    }

    public static CliArgs parse(String[] args) {
        Map<String, String> values = new HashMap<>();
        Set<String> flagsSeen = new HashSet<>();

        int i = 0;
        while (i < args.length) {
            String token = args[i];
            if (!token.startsWith("-")) {
                throw new ConfigException("Unexpected argument: " + token);
            }

            String flag = token;
            String inlineValue = null;
            int eq = token.indexOf('=');
            if (eq >= 0) {
                flag = token.substring(0, eq);
                inlineValue = token.substring(eq + 1);
            }

            if (KNOWN_BOOLEAN_FLAGS.contains(flag)) {
                flagsSeen.add(flag);
                i++;
                continue;
            }
            if (!KNOWN_VALUE_FLAGS.contains(flag)) {
                throw new ConfigException("Unknown flag: " + flag);
            }

            String value = inlineValue;
            if (value == null) {
                if (i + 1 >= args.length) {
                    throw new ConfigException("Missing value for " + flag);
                }
                value = args[i + 1];
                i += 2;
            } else {
                i++;
            }
            values.put(flag, value);
        }

        boolean help = flagsSeen.contains("--help") || flagsSeen.contains("-h");
        if (help) {
            return new CliArgs(null, 0, null, null, null, null, 7, 20.0, false, null, false, true);
        }

        String host = require(values, "--host");
        int port = requireInt(values, "--port");
        String database = require(values, "--database");
        String user = require(values, "--user");
        String password = values.get("--password");
        String tablePattern = values.get("--table");
        int staleDays = optionalInt(values, "--stale-days", 7);
        double stalePct = optionalDouble(values, "--stale-pct", 20.0);
        String charset = values.get("--charset");
        boolean csv = flagsSeen.contains("--csv");
        boolean verbose = flagsSeen.contains("--verbose");

        return new CliArgs(host, port, database, user, password, tablePattern,
                staleDays, stalePct, csv, charset, verbose, false);
    }

    private static String require(Map<String, String> values, String flag) {
        String value = values.get(flag);
        if (value == null) {
            throw new ConfigException(flag + " is required");
        }
        return value;
    }

    private static int requireInt(Map<String, String> values, String flag) {
        return parseInt(flag, require(values, flag));
    }

    private static int optionalInt(Map<String, String> values, String flag, int defaultValue) {
        String value = values.get(flag);
        return value == null ? defaultValue : parseInt(flag, value);
    }

    private static double optionalDouble(Map<String, String> values, String flag, double defaultValue) {
        String value = values.get(flag);
        return value == null ? defaultValue : parseDouble(flag, value);
    }

    private static int parseInt(String flag, String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new ConfigException(flag + " must be an integer, got: " + value);
        }
    }

    private static double parseDouble(String flag, String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            throw new ConfigException(flag + " must be a number, got: " + value);
        }
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    public String getDatabase() {
        return database;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getTablePattern() {
        return tablePattern;
    }

    public int getStaleDays() {
        return staleDays;
    }

    public double getStalePct() {
        return stalePct;
    }

    public boolean isCsv() {
        return csv;
    }

    public String getCharset() {
        return charset;
    }

    public boolean isVerbose() {
        return verbose;
    }

    public boolean isHelp() {
        return help;
    }
}
