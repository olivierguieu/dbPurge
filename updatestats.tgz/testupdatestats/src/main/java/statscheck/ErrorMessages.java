package statscheck;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Best-effort translation of a SQLException into an actionable hint.
 * Substring/regex heuristics -- not verified against actual ASE error
 * codes/SQLStates (no live ASE instance was available while building this).
 * Always shows the raw driver message alongside the hint.
 */
public final class ErrorMessages {

    private static final Pattern PERMISSION_OBJECT = Pattern.compile(
            "(?i)permission.*denied.*\\bon\\b.*?\\b(sysobjects|sysindexes|syscolumns|sysstatistics)\\b");
    private static final String[] CATALOG_TABLES = {
            "sysobjects", "sysindexes", "syscolumns", "sysstatistics"
    };

    private ErrorMessages() {
    }

    public static String explain(SQLException e, String user) {
        String message = e.getMessage() == null ? "" : e.getMessage();
        String lower = message.toLowerCase();
        StringBuilder hint = new StringBuilder();

        if (lower.contains("permission") && lower.contains("denied")) {
            Matcher matcher = PERMISSION_OBJECT.matcher(message);
            if (matcher.find()) {
                hint.append("Missing permission. Ask a DBA to run:\n  grant select on ")
                        .append(matcher.group(1)).append(" to ").append(user).append(";");
            } else {
                hint.append("Missing permission on a system catalog table. Ask a DBA to run:\n");
                for (String table : CATALOG_TABLES) {
                    hint.append("  grant select on ").append(table).append(" to ").append(user).append(";\n");
                }
            }
        } else if (lower.contains("unknown host") || lower.contains("unknown server host")
                || lower.contains("connection refused") || lower.contains("timed out")) {
            hint.append("Could not reach the server. Check --host/--port and firewall/network connectivity.");
        } else if (lower.contains("login failed") || lower.contains("login incorrect")) {
            hint.append("Login failed. Check --user/--password (or STATSCHECK_PASSWORD) and --database.");
        } else {
            hint.append("Check --host/--port/--user/--password/--database and permissions on system catalog tables.");
        }

        return "Error: " + message + "\n" + hint;
    }
}
