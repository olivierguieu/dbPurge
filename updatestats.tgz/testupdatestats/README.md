# statscheck

Reports the last time column statistics were refreshed for every index in a
Sybase ASE 16.x database, to help find statistics that need `update statistics`
/ `update index statistics`. Built for a login **without** `sa_role`/`dbo`
rights -- everything it does relies only on `SELECT` access to system catalog
tables, which is granted to `public` by default in ASE.

## How it decides "stale"

For each index, every key column (not just the leading one) is checked:

- **`sysstatistics.moddate`** -- the authoritative last-refreshed timestamp for
  that column's statistics (what `optdiag` shows as "Date of Update").
- **`datachange()`** -- ASE's built-in estimate of the percentage of rows
  changed since the last `update statistics` on that column.

An index is `NO_STATS` if any key column has never had statistics computed,
`STALE` if any key column's stats are older than `--stale-days` or its
`datachange()` exceeds `--stale-pct`, else `OK`. Status is computed by
scanning **all** key columns, not just one -- on a composite index the oldest
column and the most-changed column can be different columns, and checking
only one would hide the other. The report displays both, side by side, per
index (`OLDEST STATS COLUMN` / `MOST CHANGED COLUMN`).

Both thresholds are heuristics you tune for your environment, not ASE
constants -- there's no single official "stale" cutoff.

## Prerequisites

- **JDK 8** and **Maven**.
- A Sybase ASE 16.x login with default `public`-role `SELECT` access to
  `sysobjects`, `sysindexes`, `syscolumns`, and `sysstatistics` in the target
  database. If that's been locked down, the tool's error output will print
  the exact `grant select on <table> to <user>;` to hand your DBA.

## Build

```
mvn -q package
```

Produces `target/statscheck.jar`, a single self-contained runnable jar
(jTDS is bundled in).

## Run

```
java -jar target/statscheck.jar \
  --host dbhost --port 5000 --database mydb --user myuser --password 'mypassword'
```

Or keep the password off the command line (out of shell history / `ps`):

```
export STATSCHECK_PASSWORD='mypassword'
java -jar target/statscheck.jar --host dbhost --port 5000 --database mydb --user myuser
```

Run `java -jar target/statscheck.jar --help` for the full flag list
(`--table` to filter to one area of the schema, `--stale-days`/`--stale-pct`
to tune thresholds, `--csv` for spreadsheet-friendly output, `--verbose` to
see per-column lookup warnings).

## First run: smoke-test before trusting full output

This tool was built and reviewed without access to a live Sybase ASE
instance -- the SQL and jTDS connection settings are verified against
official documentation, but not run end-to-end against a real server. Before
relying on a full scan:

1. Run with `--table` pointed at one or two small, known tables and
   `--verbose`. This alone validates connectivity, credentials, permissions,
   and that the queries execute cleanly against your actual server.
2. Cross-check one result: run `optdiag statistics <db>.<owner>.<table>` (or
   your usual method) on a table with a composite index, and compare its
   "Date of Update" against this tool's `LAST UPDATED` column -- but compare
   against the column named in `OLDEST STATS COLUMN`, since on a composite
   index that may not be the leading key column.
3. Once that checks out, run a full unfiltered pass.

## Known limitations / notes

- **One database per run** -- whichever database is passed via `--database`.
  Re-run with a different value to check another database; there's no
  cross-database sweep of `sysdatabases`.
- **jTDS + ASE 16.0**: there's a documented jTDS issue affecting client tools
  that use `java.sql.DatabaseMetaData` to decide which queries to run against
  ASE 16.0 (e.g. some GUI catalog browsers). This tool never calls
  `DatabaseMetaData` -- it only issues plain hand-written SQL -- so that
  specific issue is not expected to apply, but it wasn't independently
  re-verified against a live ASE 16.0 server in this session either, which is
  exactly what step 1 above is for.
- **Round trips**: roughly `1 + 3 x (total key columns across all indexes)`
  queries per run. Fine for typical schemas (seconds to low tens of seconds);
  a very large schema with thousands of wide composite indexes could take a
  few minutes -- use `--table` to narrow scope if needed.
- `datachange()` counters are flushed to disk periodically by ASE's
  housekeeper task (or `sp_flushstats`), so it can lag reality slightly
  right after a burst of DML.
